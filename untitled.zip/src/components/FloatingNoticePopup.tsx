import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Bell, X, Calendar, ArrowRight, Megaphone } from "lucide-react";
import { useRealtimeCollection } from "../hooks/useRealtime";
import { Link } from "react-router-dom";

const FloatingNoticePopup = () => {
  const { data: notices } = useRealtimeCollection("notices");
  const [isVisible, setIsVisible] = useState(false);
  const [latestNotice, setLatestNotice] = useState<any>(null);

  useEffect(() => {
    if (notices && notices.length > 0) {
      // Sort to get the most recent notice
      const sortedNotices = [...notices].sort((a: any, b: any) => {
        const timeA = a.created_at ? new Date(a.created_at).getTime() : 0;
        const timeB = b.created_at ? new Date(b.created_at).getTime() : 0;
        return timeB - timeA;
      });

      const topNotice = sortedNotices[0];
      if (!topNotice) return;

      // Check if this particular notice has already been dismissed this session
      const dismissedNoticeId = sessionStorage.getItem("dismissed_notice_id");
      if (dismissedNoticeId === topNotice.id) {
        return; // Stay hidden as the user closed it in this session
      }

      setLatestNotice(topNotice);
      // Wait slightly after page load so it transitions in gracefully
      const timer = setTimeout(() => setIsVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, [notices]);

  useEffect(() => {
    if (isVisible) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "auto";
    }
    return () => {
      document.body.style.overflow = "auto";
    };
  }, [isVisible]);

  const handleClose = () => {
    setIsVisible(false);
    if (latestNotice) {
      sessionStorage.setItem("dismissed_notice_id", latestNotice.id);
    }
  };

  if (!latestNotice) return null;

  return (
    <AnimatePresence>
      {isVisible && (
        <div 
          id="floating-notice-panel"
          className="fixed inset-0 z-[9999] flex items-end justify-center sm:items-center sm:p-6 lg:items-end lg:justify-end lg:p-10"
        >
          {/* Backdrop - intentionally not blurred to keep the background somewhat clear, but scroll is locked */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-slate-900/60"
            onClick={handleClose}
          />

          {/* Modal Content - Beautiful Card attached to bottom on mobile */}
          <motion.div
            initial={{ opacity: 0, y: "100%" }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: "100%" }}
            transition={{ type: "spring", stiffness: 350, damping: 30 }}
            className="relative bg-white rounded-t-3xl sm:rounded-[2rem] shadow-[0_-10px_40px_-15px_rgba(0,0,0,0.3)] w-full max-w-lg md:max-w-xl max-h-[85vh] sm:max-h-[80vh] flex flex-col overflow-hidden"
          >
            {/* Header / Graphic banner */}
            <div className="bg-gradient-to-r from-orange-500 to-amber-500 p-6 flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center shadow-inner">
                  <Megaphone className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-black text-white tracking-tight leading-tight">
                    Notice
                  </h3>
                  <div className="flex items-center gap-1.5 text-orange-100 text-xs font-bold uppercase tracking-widest mt-1">
                    <Calendar className="h-3.5 w-3.5" /> 
                    {latestNotice.created_at ? new Date(latestNotice.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : ''}
                  </div>
                </div>
              </div>
              <button
                onClick={handleClose}
                className="text-white hover:text-orange-900 bg-white/20 hover:bg-white/40 transition-colors rounded-full p-2"
                aria-label="Dismiss announcement"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            
            {/* Scrollable Content */}
            <div className="flex-1 p-6 sm:p-8 overflow-y-auto scrollbar-thin bg-white">
              <h4 className="text-xl sm:text-2xl font-black text-slate-800 mb-4 tracking-tight leading-snug">
                {latestNotice.title}
              </h4>
              <div className="text-slate-600 text-sm sm:text-base whitespace-pre-wrap leading-relaxed prose prose-slate max-w-none">
                {latestNotice.content}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="p-4 sm:p-6 border-t border-slate-100 flex items-center justify-end gap-3 bg-slate-50/80 backdrop-blur-sm">
              <button
                onClick={handleClose}
                className="flex-1 sm:flex-none px-6 py-3.5 bg-slate-200 text-slate-700 hover:bg-slate-300 font-bold rounded-xl transition-colors text-sm"
              >
                Close
              </button>
              <Link
                to="/notices"
                onClick={handleClose}
                className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-6 py-3.5 bg-slate-900 text-white font-bold rounded-xl hover:bg-slate-800 transition-colors text-sm shadow-md"
              >
                View More <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default FloatingNoticePopup;
