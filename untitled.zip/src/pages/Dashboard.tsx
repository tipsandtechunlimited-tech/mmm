import LoadingSpinner from '../components/LoadingSpinner';
import DashboardLoading from '../components/DashboardLoading';
import React, { useEffect, useState, useMemo } from 'react';
import { useAuth } from '../context/AuthContext';
import { motion } from 'motion/react';
import { Link, useNavigate } from 'react-router-dom';
import { showAlert } from '../utils/alert';
import { 
  Bell, Calendar, CheckCircle, Award, BookOpen, FileText, PlayCircle, ArrowRight, ExternalLink, Video, Download, GraduationCap, Tag, Phone, User, Image, Clock, Users
} from 'lucide-react';
import { db } from '../firebase';
import { collection, onSnapshot, query, where, doc, getDoc } from 'firebase/firestore';
import { format } from 'date-fns';

interface DashboardData {
  user: any;
  attendance: any[];
  payments: any[];
  results: any[];
  batch: any;
  slides: any[];
}

const checkIsClassDay = (date: Date, batchDays: any, studentType?: string, hasLiveClass?: boolean) => {
  if (studentType === 'online') return !!hasLiveClass;
  if (!batchDays) return false;
  
  const batchDaysStr = Array.isArray(batchDays) ? batchDays.join(',') : String(batchDays);
  
  // Handle "Everyday"
  if (batchDaysStr.toLowerCase().includes('everyday')) {
    // 5 is Friday
    return date.getDay() !== 5;
  }

  const dayName = date.toLocaleDateString('en-US', { weekday: 'long' });
  const dayMapping: Record<string, string> = {
    'Saturday': 'Sat', 'Sunday': 'Sun', 'Monday': 'Mon',
    'Tuesday': 'Tue', 'Wednesday': 'Wed', 'Thursday': 'Thu', 'Friday': 'Fri'
  };
  return batchDaysStr.includes(dayMapping[dayName] || '') || batchDaysStr.includes(dayName);
};

const Dashboard = () => {
  const { token, user: authUser } = useAuth();
  const navigate = useNavigate();
  const [data, setData] = useState<DashboardData>({
    user: null,
    attendance: [],
    payments: [],
    results: [],
    batch: null,
    slides: []
  });
  const [notices, setNotices] = useState<any[]>([]);
  const [chapters, setChapters] = useState<any[]>([]);
  const [exams, setExams] = useState<any[]>([]);
  const [enrollments, setEnrollments] = useState<any[]>([]);
  const [studyMaterials, setStudyMaterials] = useState<any[]>([]);
  const [liveClasses, setLiveClasses] = useState<any[]>([]);
  const [routines, setRoutines] = useState<any[]>([]);
  const [reviewStatus, setReviewStatus] = useState<{type: 'success' | 'error', message: string} | null>(null);

  const filteredStudyMaterials = useMemo(() => {
    if (!data.user) return [];
    return studyMaterials.filter((m) => {
      // Hide video recorded classes from the "Study Materials" (PDF/Link) section
      if (m.type === "video") return false;
      
      // General Materials (no specific target) - visible to all
      if (!m.program_id && !m.batch_id && !m.course_id) return true;

      if (data.user?.student_type !== "online") {
        let isEligible = false;
        
        if (m.program_id) {
          const matchProgram = String(m.program_id) === String(data.user?.program_id);
          const matchBatch = !m.batch_id || String(m.batch_id).toUpperCase() === 'ALL' || 
                             String(m.batch_id) === String(data.user?.batch_id) || 
                             String(m.batch_id) === String(data.user?.batch_id_2);
          if (matchProgram && matchBatch) isEligible = true;
        }

        const userCourses = data.user?.enrolled_courses || [];
        const isEnrolledViaPrimary = String(data.user?.course_id) === String(m.course_id);
        const isEnrolledViaProfile = userCourses.some((c: any) => 
          typeof c === 'string' ? String(c) === String(m.course_id) : String(c.id) === String(m.course_id)
        );
        const isEnrolledViaEnrollments = enrollments.some(e => 
          (e.status === "approved" || e.status === "contacted") && String(e.course_id) === String(m.course_id)
        );

        if (m.course_id && (isEnrolledViaPrimary || isEnrolledViaProfile || isEnrolledViaEnrollments)) {
          isEligible = true;
        }

        return isEligible;
      } else {
        // Online filtering - match by course_id in enrollments or student profile
        const userCourses = data.user?.enrolled_courses || [];
        const isEnrolledViaProfile = userCourses.some((c: any) => 
          typeof c === 'string' ? String(c) === String(m.course_id) : String(c.id) === String(m.course_id)
        );
        const isEnrolledViaEnrollments = enrollments.some(e => 
          (e.status === "approved" || e.status === "contacted") && String(e.course_id) === String(m.course_id)
        );
        return isEnrolledViaProfile || isEnrolledViaEnrollments;
      }
    });
  }, [studyMaterials, data.user, enrollments]);

  const filteredChapters = useMemo(() => {
    if (!data.user) return [];
    return chapters.filter((c) => {
      if (!c.program_id && !c.batch_id && !c.course_id) return true;

      if (data.user?.student_type !== "online") {
        let isEligible = false;
        
        if (c.program_id) {
          const matchProgram = String(c.program_id) === String(data.user?.program_id);
          const matchBatch = !c.batch_id || String(c.batch_id).toUpperCase() === 'ALL' || 
                             String(c.batch_id) === String(data.user?.batch_id) || 
                             String(c.batch_id) === String(data.user?.batch_id_2);
          if (matchProgram && matchBatch) isEligible = true;
        }

        const userCourses = data.user?.enrolled_courses || [];
        const isEnrolledViaPrimary = String(data.user?.course_id) === String(c.course_id);
        const isEnrolledViaProfile = userCourses.some((course: any) => 
          typeof course === 'string' ? String(course) === String(c.course_id) : String(course.id) === String(c.course_id)
        );
        const isEnrolledViaEnrollments = enrollments.some(e => 
          (e.status === "approved" || e.status === "contacted") && String(e.course_id) === String(c.course_id)
        );

        if (c.course_id && (isEnrolledViaPrimary || isEnrolledViaProfile || isEnrolledViaEnrollments)) {
          isEligible = true;
        }

        return isEligible;
      } else {
        const userCourses = data.user?.enrolled_courses || [];
        const isEnrolledViaProfile = userCourses.some((course: any) => 
          typeof course === 'string' ? String(course) === String(c.course_id) : String(course.id) === String(c.course_id)
        );
        const isEnrolledViaEnrollments = enrollments.some(e => 
          (e.status === "approved" || e.status === "contacted") && String(e.course_id) === String(c.course_id)
        );
        return isEnrolledViaProfile || isEnrolledViaEnrollments || (!c.course_id && !c.program_id);
      }
    });
  }, [chapters, data.user, enrollments]);

  const filteredExams = useMemo(() => {
    if (!data.user || !exams) return [];
    if (data.user.role !== 'student') return exams;
    
    return exams.filter((e: any) => {
      if (data.user?.student_type !== "online") {
        let isEligible = false;
        
        if (e.program_id) {
          const userBatchIds = [String(data.user?.batch_id), String(data.user?.batch_id_2)].filter(Boolean);
          const examBatchId = String(e.batch_id).toUpperCase();
          const batchMatch = !e.batch_id || examBatchId === 'ALL' || userBatchIds.includes(String(e.batch_id));
          const programMatch = String(e.program_id) === String(data.user?.program_id);
          if (batchMatch && programMatch) isEligible = true;
        }

        const userCourses = data.user?.enrolled_courses || [];
        const isEnrolledViaPrimary = String(data.user?.course_id) === String(e.course_id);
        const isEnrolledViaProfile = userCourses.some((course: any) => 
          typeof course === 'string' ? String(course) === String(e.course_id) : String(course.id) === String(e.course_id)
        );
        const isEnrolledViaEnrollments = enrollments.some(enroll => 
          (enroll.status === "approved" || enroll.status === "contacted") && String(enroll.course_id) === String(e.course_id)
        );

        if (e.course_id && (isEnrolledViaPrimary || isEnrolledViaProfile || isEnrolledViaEnrollments)) {
          isEligible = true;
        }

        return isEligible;
      } else {
        // Online students filter exams by course
        if (!e.course_id) return false;
        const userCourses = data.user?.enrolled_courses || [];
        const isEnrolledViaProfile = userCourses.some((course: any) => 
          typeof course === 'string' ? String(course) === String(e.course_id) : String(course.id) === String(e.course_id)
        );
        const isEnrolledViaEnrollments = enrollments.some(enroll => 
          (enroll.status === "approved" || enroll.status === "contacted") && String(enroll.course_id) === String(e.course_id)
        );
        return isEnrolledViaProfile || isEnrolledViaEnrollments;
      }
    });
  }, [exams, data.user, enrollments]);

  const filteredRoutines = useMemo(() => {
    if (!data.user) return [];
    return routines.filter((r: any) => {
      // General visibility (no specific target, or explicitly all)
      const isGeneral = (!r.program_id || r.program_id === 'all') && (!r.course_id || r.course_id === 'all');
      if (isGeneral) return true;

      if (data.user?.student_type !== "online") {
        let isEligible = false;
        
        if (r.program_id && String(r.program_id).toUpperCase() !== 'ALL') {
          const matchProgram = String(r.program_id) === String(data.user?.program_id);
          const matchBatch = !r.batch_id || String(r.batch_id).toUpperCase() === 'ALL' || 
                             String(r.batch_id) === String(data.user?.batch_id) || 
                             String(r.batch_id) === String(data.user?.batch_id_2);
          if (matchProgram && matchBatch) isEligible = true;
        }

        const userCourses = data.user?.enrolled_courses || [];
        const isEnrolledViaPrimary = String(data.user?.course_id) === String(r.course_id);
        const isEnrolledViaProfile = userCourses.some((course: any) => 
          typeof course === 'string' ? String(course) === String(r.course_id) : String(course.id) === String(r.course_id)
        );
        const isEnrolledViaEnrollments = enrollments.some(e => 
          (e.status === "approved" || e.status === "contacted") && String(e.course_id) === String(r.course_id)
        );

        if (r.course_id && String(r.course_id).toUpperCase() !== 'ALL' && (isEnrolledViaPrimary || isEnrolledViaProfile || isEnrolledViaEnrollments)) {
          isEligible = true;
        }

        return isEligible;
      } else {
        // Online user
        if (!r.course_id && !r.program_id) return true;
        if (r.course_id && r.course_id.toLowerCase() === 'all') return true;

        const userCourses = data.user?.enrolled_courses || [];
        const isEnrolledViaPrimary = String(data.user?.course_id) === String(r.course_id);
        const isEnrolledViaProfile = userCourses.some((c: any) => 
          typeof c === 'string' ? String(c) === String(r.course_id) : String(c.id) === String(r.course_id)
        );
        const isEnrolledViaEnrollments = enrollments.some((e: any) => 
          (e.status === 'contacted' || e.status === 'approved') && String(e.course_id) === String(r.course_id)
        );
        return isEnrolledViaPrimary || isEnrolledViaProfile || isEnrolledViaEnrollments;
      }
    });
  }, [routines, data.user, enrollments]);

  const calculateUnpaidMonths = (student: any, payments: any[]): string[] => {
    if (!student || student.student_type === "online") return [];

    const startDateRaw = student.date_of_admission || student.created_at;
    if (!startDateRaw) return [];

    const startDate = new Date(startDateRaw);
    
    // If admission_month is provided, adjust the starting month
    if (student.admission_month) {
      const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
      const monthIndex = MONTHS.indexOf(student.admission_month);
      if (monthIndex !== -1) {
        startDate.setMonth(monthIndex);
        startDate.setDate(1);
      }
    }

    const now = new Date();

    const unpaid: string[] = [];

    // Start from the month of admission
    let current = new Date(startDate.getFullYear(), startDate.getMonth(), 1);
    const end = new Date(now.getFullYear(), now.getMonth(), 1);

    while (current <= end) {
      const monthName = format(current, "MMMM");
      const monthYear = format(current, "MMM yy");

      const hasApprovedPayment = payments?.some((p: any) => {
        const pYearStr = p.year || (p.date ? format(new Date(p.date), "yyyy") : "");
        const currentYearStr = format(current, "yyyy");
        const isCorrectYear = !pYearStr || String(pYearStr) === currentYearStr;
        return (
          (p.type === "monthly" || p.type === "admission") &&
          p.month && String(p.month).toLowerCase() === String(monthName).toLowerCase() &&
          isCorrectYear &&
          (!p.status || p.status === "approved" || p.status === "Completed" || p.status === "approved_manual")
        );
      });

      const hasPendingPayment = payments?.some((p: any) => {
        const pYearStr = p.year || (p.date ? format(new Date(p.date), "yyyy") : "");
        const currentYearStr = format(current, "yyyy");
        const isCorrectYear = !pYearStr || String(pYearStr) === currentYearStr;
        return (
          (p.type === "monthly" || p.type === "admission") &&
          p.month && String(p.month).toLowerCase() === String(monthName).toLowerCase() &&
          isCorrectYear &&
          p.status === "pending"
        );
      });

      // If the month is the admission_month and they have some paid_amount, consider it paid
      const isAdmissionMonth = student.admission_month === monthName;
      const hasPaidAmount = parseInt(student.paid_amount || "0") > 0;

      if (!hasApprovedPayment && !hasPendingPayment && !(isAdmissionMonth && hasPaidAmount)) {
        unpaid.push(
          current.getFullYear() === now.getFullYear() ? monthName : monthYear,
        );
      }

      current.setMonth(current.getMonth() + 1);
    }

    return [...new Set(unpaid)];
  };
  
  useEffect(() => {
    if (!token || !authUser) return;

    const unsubscribes: (() => void)[] = [];

    // Listen to user profile
    const userRef = doc(db, 'users', authUser.id);
    const unsubUser = onSnapshot(userRef, async (userDoc) => {
      if (userDoc.exists()) {
        const userData = userDoc.data();
        const batchId = userData.batch_id;
        
        let batchData = null;
        if (batchId) {
          const batchDoc = await getDoc(doc(db, 'batches', String(batchId)));
          if (batchDoc.exists()) batchData = batchDoc.data();
        }

        // Listen to attendance
        const qAttendance = query(collection(db, 'attendance'), where('student_id', 'in', [authUser.id, userData.roll_number || '']));
        const unsubAttendance = onSnapshot(qAttendance, (snapshot) => {
          let attendance: any[] = snapshot.docs.map(d => ({ ...d.data(), id: d.id } as any));
          
          const batchDays = userData.batch_days || batchData?.batch_days;
          if (batchDays) {
            const enrollmentDate = new Date(userData.created_at || userData.date_of_admission || new Date());
            const today = new Date();
            
            for (let i = 0; i < 14; i++) {
              const d = new Date();
              d.setDate(today.getDate() - i);
              const dateStr = d.toLocaleDateString('en-CA');
              
              if (d < enrollmentDate) break;
              
              const hasRecord = attendance.find(a => a.date === dateStr && a.type !== 'exam');
              if (!hasRecord && checkIsClassDay(d, batchDays, userData.student_type, i === 0 ? liveClasses.length > 0 : false)) {
                attendance.push({
                  date: dateStr,
                  status: 'absent',
                  type: 'class',
                  id: `auto-absent-${dateStr}`
                });
              }
            }
          }
          
          setData(prev => ({
            ...prev,
            user: userData,
            batch: batchData,
            attendance: attendance.sort((a: any, b: any) => new Date(b.date).getTime() - new Date(a.date).getTime())
          }));
        });
        unsubscribes.push(unsubAttendance);

        // Listen to payments
        const qPayments = query(collection(db, 'payments'), where('student_id', 'in', [authUser.id, userData.roll_number || '']));
        const unsubPayments = onSnapshot(qPayments, (snapshot) => {
          setData(prev => ({
            ...prev,
            payments: snapshot.docs.map(d => ({ ...d.data(), id: d.id }))
          }));
        });
        unsubscribes.push(unsubPayments);

        // Listen to results
        const qResults = query(collection(db, 'results'), where('student_id', 'in', [authUser.id, userData.roll_number || '']));
        const unsubResults = onSnapshot(qResults, (snapshot) => {
          setData(prev => ({
            ...prev,
            results: snapshot.docs.map(d => ({ ...d.data(), id: d.id }))
          }));
        });
        unsubscribes.push(unsubResults);
      } else {
        setData(prev => ({
          ...prev,
          user: authUser,
          batch: null,
          attendance: [],
          payments: [],
          results: []
        }));
      }
    });
    unsubscribes.push(unsubUser);

    // Listen to notices
    unsubscribes.push(onSnapshot(collection(db, 'notices'), (snapshot) => {
      setNotices(snapshot.docs.map(d => ({ ...d.data(), id: d.id })));
    }));

    // Listen to chapters
    unsubscribes.push(onSnapshot(collection(db, 'chapters'), (snapshot) => {
      setChapters(snapshot.docs.map(d => ({ ...d.data(), id: d.id })));
    }));

    // Listen to exams
    unsubscribes.push(onSnapshot(collection(db, 'exams'), (snapshot) => {
      setExams(snapshot.docs.map(d => ({ ...d.data(), id: d.id })));
    }));

    // Listen to routines
    unsubscribes.push(onSnapshot(collection(db, 'routines'), (snapshot) => {
      setRoutines(snapshot.docs.map(d => ({ ...d.data(), id: d.id })));
    }));

    // Fetch enrollments via API since it synthesizes virtual enrollments and alternative phone/email linkages
    fetch(`/api/my-enrollments?t=${Date.now()}`, {
      headers: { Authorization: `Bearer ${token}` }
    })
      .then(res => res.json())
      .then(data => {
        if (!data.error) {
          setEnrollments(Array.isArray(data) ? data : []);
        }
      })
      .catch(console.error);

    // Listen to live classes
    unsubscribes.push(onSnapshot(collection(db, 'live_classes'), (snapshot) => {
      setLiveClasses(snapshot.docs.map(d => ({ ...d.data(), id: d.id })));
    }));

    // Listen to class slides
    unsubscribes.push(onSnapshot(collection(db, 'class_slides'), (snapshot) => {
      setData(prev => ({
        ...prev,
        slides: snapshot.docs.map(d => ({ ...d.data(), id: d.id }))
      }));
    }));

    // Listen to study materials
    unsubscribes.push(onSnapshot(collection(db, 'study_materials'), (snapshot) => {
      setStudyMaterials(snapshot.docs.map(d => ({ ...d.data(), id: d.id })));
    }));

    return () => unsubscribes.forEach(unsub => unsub());
  }, [token, authUser]);

  const handleJoinClass = (lc: any, method: 'app' | 'web' = 'app') => {
    // Mark attendance in background only for online students
    if (data?.user?.student_type === 'online') {
      fetch(`/api/attendance/mark-present?t=${Date.now()}`, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}` 
        },
        body: JSON.stringify({
          batch_id: lc.batch_id,
          date: new Date().toLocaleDateString('en-CA'),
          type: 'class'
        })
      }).catch(e => console.error('Error marking attendance:', e));
    }

    if (method === 'web') {
      navigate(`/dashboard/zoom/${lc.id}`);
    } else {
      const link = lc.url || lc.zoom_link;
      if (link) {
        const win = window.open(link, '_blank');
        if (!win) {
          showAlert('Popup blocked! Please allow popups for this site to join the class.', 'error');
        }
      } else {
        showAlert('No link provided for this class.');
      }
    }
  };

  const handleMarkAttendance = async () => {
    if (!data?.user?.batch_id || data?.user?.student_type !== 'online') return;
    try {
      const res = await fetch(`/api/attendance/mark-present?t=${Date.now()}`, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}` 
        },
        body: JSON.stringify({
          batch_id: data.user.batch_id,
          date: new Date().toLocaleDateString('en-CA'),
          type: 'class'
        })
      });
      if (!res.ok) {
        const errorData = await res.json();
        console.error('Error marking attendance:', errorData);
      }
    } catch (e) {
      console.error('Error marking attendance:', e);
    }
  };

  if (!data.user) {
    return null; // Don't block screen with splashing DashboardLoading to give a snappy feel
  }

  return (
    <div className="space-y-6">
      {/* Dynamic Pending Approval Alert for Online Students */}
      {data.user?.role === 'student' && enrollments.some(e => e.status === 'pending') && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-r from-amber-50 to-orange-50/50 border border-amber-200/80 rounded-[2.5rem] p-6 sm:p-8 shadow-[0_20px_50px_-12px_rgba(245,158,11,0.12)] flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full blur-2xl" />
          <div className="flex gap-4.5 items-start">
            <div className="p-3.5 bg-amber-500 rounded-2xl text-white shadow-lg shadow-amber-500/20 mt-1 flex-shrink-0 animate-pulse">
              <Clock className="h-6 w-6" />
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-black text-slate-800 tracking-tight">
                Admission / Enrollment Pending Approval
              </h3>
              <p className="text-sm font-semibold text-slate-600 leading-relaxed mt-2 max-w-xl">
                Dear <span className="text-amber-600 font-bold">{data.user.name}</span>, your online course enrollment is currently being audited. Once approved by the administrator, your class schedule, mock exams, routines, live lecture streams, and study files will immediately become active.
              </p>
              <div className="flex flex-wrap items-center gap-x-5 gap-y-2 mt-4 text-[10px] font-black text-slate-400 uppercase tracking-wider">
                <span className="flex items-center gap-1.5"><Tag className="h-3.5 w-3.5 text-amber-500" /> MODE: ONLINE</span>
                <span className="flex items-center gap-1.5"><CheckCircle className="h-3.5 w-3.5 text-slate-300" /> STATUS: AUDIT IN PROGRESS</span>
              </div>
            </div>
          </div>
          <Link
            to="/dashboard/enrollments"
            className="w-full md:w-auto px-6 py-3.5 bg-slate-800 hover:bg-slate-900 text-white text-xs font-black uppercase tracking-widest rounded-xl shadow-lg transition-all text-center flex-shrink-0"
          >
            Check Status
          </Link>
        </motion.div>
      )}

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-8"
      >
        {/* Welcome Section Card */}
        <div className="bg-white rounded-[3rem] p-10 text-slate-900 shadow-2xl shadow-orange-100/50 border border-orange-100 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-96 h-96 bg-orange-500/5 rounded-full -mr-48 -mt-48 blur-3xl" />
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-orange-600/5 rounded-full -ml-32 -mb-32 blur-3xl" />
          
          <div className="relative z-10 flex flex-col lg:flex-row justify-between items-start lg:items-center gap-8">
            <div className="flex-1 w-full">
              {/* Prominent Payment Status for Students */}
              {data.user?.role === 'student' && (
                <motion.div
                  initial={{ x: -20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  className="mb-8 inline-block"
                >
                  <div className={`flex items-center gap-4 p-4 pr-8 rounded-[2rem] border shadow-2xl transition-all ${
                    calculateUnpaidMonths(data.user, data.payments).length > 0 ||
                    enrollments.some(e => e.payment_status === 'due')
                      ? 'bg-rose-50 border-rose-100 text-rose-600 shadow-rose-200/20'
                      : data.payments?.some(p => p.status === 'pending') || enrollments.some(e => e.status === 'pending')
                        ? 'bg-amber-50 border-amber-100 text-amber-600 shadow-amber-200/20'
                        : 'bg-emerald-50 border-emerald-100 text-emerald-600 shadow-emerald-200/20'
                  }`}>
                    <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg ${
                      calculateUnpaidMonths(data.user, data.payments).length > 0 ||
                      enrollments.some(e => e.payment_status === 'due')
                        ? 'bg-rose-500 text-white'
                        : data.payments?.some(p => p.status === 'pending') || enrollments.some(e => e.status === 'pending')
                          ? 'bg-amber-500 text-white'
                          : 'bg-emerald-500 text-white'
                    }`}>
                      {calculateUnpaidMonths(data.user, data.payments).length > 0 || 
                       enrollments.some(e => e.payment_status === 'due') ? (
                        <Tag className="h-6 w-6" />
                      ) : data.payments?.some(p => p.status === 'pending') || enrollments.some(e => e.status === 'pending') ? (
                        <Clock className="h-6 w-6" />
                      ) : (
                        <CheckCircle className="h-6 w-6" />
                      )}
                    </div>
                    <div>
                      <p className="text-[10px] font-black uppercase tracking-[0.2em] opacity-60">Account Status</p>
                      <h4 className="text-xl font-black tracking-tight flex items-center gap-2">
                        {calculateUnpaidMonths(data.user, data.payments).length > 0 || 
                         enrollments.some(e => e.payment_status === 'due')
                           ? <span className="text-rose-600">Due</span> 
                           : <span className="text-emerald-600">Paid</span>
                        }
                        {(calculateUnpaidMonths(data.user, data.payments).length > 0 || 
                        enrollments.some(e => e.payment_status === 'due')) && (
                          <div className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
                        )}
                      </h4>
                      {calculateUnpaidMonths(data.user, data.payments).length > 0 && (
                        <p className="text-[9px] font-bold opacity-60">Pending: {calculateUnpaidMonths(data.user, data.payments).join(', ')}</p>
                      )}
                      {enrollments.some(e => e.payment_status === 'due') && (
                        <p className="text-[9px] font-bold opacity-60">Course Enrollment Payment Due</p>
                      )}
                      {enrollments.some(e => e.status === 'pending') && (
                        <p className="text-[9px] font-bold opacity-60">Application pending review</p>
                      )}
                    </div>
                  </div>
                </motion.div>
              )}

              <div className="flex flex-col md:flex-row md:items-center gap-4 mb-4">
                <h1 className="text-4xl md:text-5xl font-black tracking-tight">
                  Welcome, <span className="text-orange-600">{data.user?.name?.split(' ')[0] || 'Student'}!</span>
                </h1>
              </div>
              <div className="flex flex-wrap items-center gap-4 text-slate-500">
                <div className="flex flex-col bg-slate-50 px-5 py-3 rounded-2xl border border-slate-100 min-w-[120px]">
                  <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1 flex items-center gap-1.5"><GraduationCap className="h-3 w-3" /> Current Class</p>
                  <span className="font-black text-slate-800 text-lg">
                    {data.user?.current_class || '-'}
                  </span>
                </div>
                <div className="flex flex-col bg-blue-50 px-5 py-3 rounded-2xl border border-blue-100 min-w-[120px]">
                  <p className="text-[10px] font-black uppercase tracking-widest text-blue-400 mb-1 flex items-center gap-1.5"><User className="h-3 w-3" /> Status</p>
                  <span className="font-black text-blue-700 text-lg capitalize">
                    {data.user?.student_type || 'Offline'}
                  </span>
                </div>
                <div className="flex flex-col bg-orange-50 px-5 py-3 rounded-2xl border border-orange-100 min-w-[120px]">
                  <p className="text-[10px] font-black uppercase tracking-widest text-orange-400 mb-1 flex items-center gap-1.5"><Calendar className="h-3 w-3" /> Batch</p>
                  <span className="font-black text-orange-700 text-lg">
                    {data.user?.student_type === 'online' 
                      ? (enrollments.find(e => e.course_title)?.course_title || data.user?.course_title || 'Online Course') 
                      : (data.batch?.name || data.user?.program_title || 'No Batch')}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-4">
              {data.batch?.live_class_link && (
                <motion.a 
                  whileHover={{ scale: 1.05, y: -5 }}
                  whileTap={{ scale: 0.95 }}
                  href={data.batch.live_class_link} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="bg-orange-600 text-white px-8 py-4 rounded-2xl font-black text-sm uppercase tracking-widest flex items-center gap-3 shadow-xl shadow-orange-600/20 transition-all"
                >
                  <PlayCircle className="h-6 w-6" />
                  JOIN LIVE CLASS
                </motion.a>
              )}
              <div className="bg-orange-50 px-8 py-4 rounded-2xl border border-orange-100 flex items-center gap-6 shadow-sm">
                <div>
                  <p className="text-slate-400 text-[10px] font-black uppercase tracking-[0.2em] mb-1">Today's Status</p>
                  {(() => {
                    const today = new Date().toLocaleDateString('en-CA');
                    const todayRecord = (data.attendance || []).find(a => a.date === today && a.type !== 'exam');
                    
                    const isClassDay = checkIsClassDay(new Date(), data.user?.batch_days, data.user?.student_type, liveClasses.length > 0);

                    if (todayRecord) {
                      const isPresent = todayRecord.status === 'present';
                      return (
                        <div className="flex items-center gap-3">
                          <div className={`w-3.5 h-3.5 rounded-full ${isPresent ? 'bg-green-500 shadow-[0_0_15px_rgba(34,197,94,0.4)]' : 'bg-red-500 shadow-[0_0_15px_rgba(239,68,68,0.4)]'}`} />
                          <span className={`text-2xl font-black tracking-tight ${isPresent ? 'text-green-600' : 'text-red-600'}`}>
                            {todayRecord.status.toUpperCase()}
                          </span>
                        </div>
                      );
                    } else if (isClassDay) {
                      return (
                        <button 
                          onClick={handleMarkAttendance}
                          className="flex items-center gap-3 group cursor-pointer hover:opacity-80 transition-all"
                        >
                          <div className="w-3.5 h-3.5 rounded-full bg-red-500 shadow-[0_0_15px_rgba(239,68,68,0.4)] animate-pulse group-hover:scale-125 transition-transform" />
                          <span className="text-2xl font-black text-red-600 uppercase tracking-tight">ABSENT</span>
                        </button>
                      );
                    } else {
                      return (
                        <div className="flex items-center gap-3">
                          <div className="w-3.5 h-3.5 rounded-full bg-slate-300" />
                          <span className="text-2xl font-black text-slate-400 tracking-tight">No Class</span>
                        </div>
                      );
                    }
                  })()}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Live Classes Section */}
        {liveClasses.filter(lc => {
          const lcStatus = String(lc.status || '').toLowerCase();
          if (lcStatus !== 'active' && lcStatus !== 'scheduled') return false;

          const isEnrolledInCourse = lc.course_id && (
            String(data.user?.course_id) === String(lc.course_id) ||
            enrollments.some((e: any) => String(e.course_id) === String(lc.course_id) && (e.status === 'approved' || e.status === 'contacted')) || 
            data.user?.enrolled_courses?.some((c: any) => typeof c === 'string' ? String(c) === String(lc.course_id) : String(c.id) === String(lc.course_id))
          );

          const isEnrolledInProgram = lc.program_id && (
            String(data.user?.program_id) === String(lc.program_id) ||
            enrollments.some((e: any) => String(e.program_id) === String(lc.program_id) && (e.status === 'approved' || e.status === 'contacted'))
          );

          const isEnrolledInBatch = lc.batch_id && lc.batch_id !== 'ALL' && (
            String(data.user?.batch_id) === String(lc.batch_id) || 
            String(data.user?.batch_id_2) === String(lc.batch_id) ||
            enrollments.some((e: any) => String(e.batch_id) === String(lc.batch_id) && (e.status === 'approved' || e.status === 'contacted'))
          );

          // 1. If no restrictions are placed
          if ((!lc.course_id || lc.course_id === 'ALL') && (!lc.program_id || lc.program_id === 'ALL') && (!lc.batch_id || lc.batch_id === 'ALL')) {
            return true;
          }

          // 2. If a specific batch matches directly
          if (lc.batch_id && lc.batch_id !== 'ALL' && isEnrolledInBatch) {
            return true;
          }

          // 3. If a specific course matches
          if (lc.course_id && lc.course_id !== 'ALL' && isEnrolledInCourse) {
            if (lc.batch_id && lc.batch_id !== 'ALL') {
              return isEnrolledInBatch;
            }
            return true;
          }

          // 4. If a specific program matches
          if (lc.program_id && lc.program_id !== 'ALL' && isEnrolledInProgram) {
            if (lc.batch_id && lc.batch_id !== 'ALL') {
              return isEnrolledInBatch;
            }
            return true;
          }

          return false;
        }).length > 0 && (
          <div className="bg-gradient-to-r from-orange-600 to-orange-500 rounded-3xl p-6 text-white shadow-xl shadow-orange-200">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="bg-white/20 p-2 rounded-xl backdrop-blur-sm animate-pulse">
                  <PlayCircle className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="text-xl font-bold">Live Classes Active</h3>
                  <p className="text-orange-100 text-sm">Join your ongoing live session now</p>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {liveClasses.filter(lc => {
                const lcStatus = String(lc.status || '').toLowerCase();
                if (lcStatus !== 'active' && lcStatus !== 'scheduled') return false;

                const isEnrolledInCourse = lc.course_id && (
                  String(data.user?.course_id) === String(lc.course_id) ||
                  enrollments.some((e: any) => String(e.course_id) === String(lc.course_id) && (e.status === 'approved' || e.status === 'contacted')) || 
                  data.user?.enrolled_courses?.some((c: any) => typeof c === 'string' ? String(c) === String(lc.course_id) : String(c.id) === String(lc.course_id))
                );

                const isEnrolledInProgram = lc.program_id && (
                  String(data.user?.program_id) === String(lc.program_id) ||
                  enrollments.some((e: any) => String(e.program_id) === String(lc.program_id) && (e.status === 'approved' || e.status === 'contacted'))
                );

                const isEnrolledInBatch = lc.batch_id && lc.batch_id !== 'ALL' && (
                  String(data.user?.batch_id) === String(lc.batch_id) || 
                  String(data.user?.batch_id_2) === String(lc.batch_id) ||
                  enrollments.some((e: any) => String(e.batch_id) === String(lc.batch_id) && (e.status === 'approved' || e.status === 'contacted'))
                );

                // 1. If no restrictions are placed
                if ((!lc.course_id || lc.course_id === 'ALL') && (!lc.program_id || lc.program_id === 'ALL') && (!lc.batch_id || lc.batch_id === 'ALL')) {
                  return true;
                }

                // 2. If a specific batch matches directly
                if (lc.batch_id && lc.batch_id !== 'ALL' && isEnrolledInBatch) {
                  return true;
                }

                // 3. If a specific course matches
                if (lc.course_id && lc.course_id !== 'ALL' && isEnrolledInCourse) {
                  if (lc.batch_id && lc.batch_id !== 'ALL') {
                    return isEnrolledInBatch;
                  }
                  return true;
                }

                // 4. If a specific program matches
                if (lc.program_id && lc.program_id !== 'ALL' && isEnrolledInProgram) {
                  if (lc.batch_id && lc.batch_id !== 'ALL') {
                    return isEnrolledInBatch;
                  }
                  return true;
                }

                return false;
              }).map((lc) => (
                <div key={lc.id} className="bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/20 flex flex-col gap-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-bold text-lg">{lc.title}</h4>
                      <p className="text-xs text-orange-100 uppercase tracking-wider font-bold">
                        {lc.zoom_link?.includes('meet.jit.si') || lc.zoom_link?.includes('8x8.vc') ? 'Custom Live Portal' : lc.zoom_link?.includes('meet.google.com') ? 'Google Meet Session' : 'Zoom Live Session'}
                      </p>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <button 
                        onClick={() => handleJoinClass(lc, 'app')}
                        className="bg-orange-600 text-white border border-white/30 px-8 py-3 rounded-2xl font-bold hover:bg-orange-500 transition-colors shadow-lg text-sm flex items-center gap-2"
                      >
                        <Video className="h-5 w-5" />
                        Join Live Class
                      </button>
                      {(lc.zoom_link?.includes('zoom.us') || lc.zoom_link?.includes('8x8.vc')) && (
                        <button 
                          onClick={() => handleJoinClass(lc, 'web')}
                          className="bg-white/10 text-white border border-white/30 px-6 py-3 rounded-2xl font-bold hover:bg-white/20 transition-colors text-sm flex items-center gap-2"
                        >
                          Join via Web
                        </button>
                      )}
                    </div>
                  </div>
                  
                  {(lc.zoom_id || lc.zoom_password) && (
                    <div className="grid grid-cols-2 gap-2 pt-2 border-t border-white/10">
                      {lc.zoom_id && (
                        <div className="bg-white/5 p-2 rounded-lg">
                          <p className="text-[10px] text-orange-100 uppercase font-bold">Meeting ID</p>
                          <p className="font-mono text-sm">{lc.zoom_id}</p>
                        </div>
                      )}
                      {lc.zoom_password && (
                        <div className="bg-white/5 p-2 rounded-lg">
                          <p className="text-[10px] text-orange-100 uppercase font-bold">Passcode</p>
                          <p className="font-mono text-sm">{lc.zoom_password}</p>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Results Section */}
        {data.results && data.results.length > 0 && (
          <div className="space-y-6">
            <h3 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-3">
              <Award className="h-7 w-7 text-orange-600" /> Results History
            </h3>
            <div className="glass p-8 rounded-3xl border border-white/60 shadow-xl bg-white/50">
              <div className="space-y-4">
                {data.results.map((result: any) => (
                  <div key={result.id} className="flex justify-between items-center p-4 border-b border-slate-100 last:border-none">
                    <div>
                      <h4 className="font-bold text-slate-900">{result.exam_name}</h4>
                      <p className="text-xs text-slate-500">{result.batch_name}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-black text-orange-600">{result.marks} / {result.highest_marks}</p>
                      <p className="text-[10px] text-slate-400 uppercase tracking-widest">{new Date(result.date).toLocaleDateString()}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Quick Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6">
          {(data.user?.student_type === 'online' 
            ? [
                { label: 'Courses', value: enrollments.filter(e => e.status === 'approved').length, color: 'blue' },
                { label: 'Exams', value: filteredExams.length, color: 'orange' },
                { label: 'Chapters', value: filteredChapters.length, color: 'slate' },
                { label: 'Materials', value: filteredStudyMaterials.length, color: 'green' },
                { label: 'Routine', value: filteredRoutines.length, color: 'orange' }
              ]
            : [
                { label: 'Attendance', value: `${Math.round(((data.attendance || []).filter(a => a.status === 'present').length / ((data.attendance || []).length || 1)) * 100)}%`, color: 'orange' },
                { label: 'Total Paid', value: `৳${data.user.paid_amount || 0}`, color: 'green' },
                { label: 'Monthly Fee', value: `৳${data.user.monthly_fee || 0}`, color: 'orange' },
                { label: 'Exams', value: filteredExams.length, color: 'orange' },
                { label: 'Chapters', value: filteredChapters.length, color: 'slate' }
              ]
          ).map((stat, i) => (
            <motion.div 
              key={i}
              whileHover={{ y: -10, backgroundColor: 'rgba(255, 255, 255, 0.9)' }}
              className="glass p-6 rounded-[2rem] border border-white/60 shadow-xl transition-all bg-white/40"
            >
              <div className="text-slate-400 text-[10px] font-black uppercase tracking-widest mb-2">{stat.label}</div>
              <div className={`text-3xl font-black text-${stat.color}-600 tracking-tight`}>{stat.value}</div>
            </motion.div>
          ))}
        </div>

        {/* Recent Class Slides Section */}
        {data.slides && data.slides.filter((slide: any) => {
          // Check if slide is for everyone
          if (!slide.course_id && !slide.program_id && (!slide.batch_id || slide.batch_id === 'ALL')) return true;
          
          // Check if slide matches student's course
          if (slide.course_id && slide.course_id !== 'ALL') {
            return String(data.user?.course_id) === String(slide.course_id) || 
                   data.user?.enrolled_courses?.some((c: any) => typeof c === 'string' ? String(c) === String(slide.course_id) : String(c.id) === String(slide.course_id)) ||
                   enrollments.some((e: any) => String(e.course_id) === String(slide.course_id) && (e.status === 'approved' || e.status === 'contacted'));
          }

          // Check if slide matches student's program
          if (slide.program_id && slide.program_id !== 'ALL') {
            const isEnrolledInProgram = String(data.user?.program_id) === String(slide.program_id) || 
                                        enrollments.some((e: any) => String(e.program_id) === String(slide.program_id) && (e.status === 'approved' || e.status === 'contacted'));
            if (!isEnrolledInProgram) return false;
            
            if (slide.batch_id && slide.batch_id !== 'ALL') {
              return String(data.user?.batch_id) === String(slide.batch_id) || 
                     String(data.user?.batch_id_2) === String(slide.batch_id) ||
                     enrollments.some((e: any) => String(e.batch_id) === String(slide.batch_id) && (e.status === 'approved' || e.status === 'contacted'));
            }
            return true;
          }
          
          return false;
        }).length > 0 && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-3">
                <Image className="h-7 w-7 text-orange-600" /> Recent Class Slides
              </h3>
              <button onClick={() => navigate('/dashboard/class-slides')} className="text-sm font-bold text-orange-600 hover:text-orange-700">View All</button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {data.slides.filter((slide: any) => {
                if (!slide.course_id && !slide.program_id && (!slide.batch_id || slide.batch_id === 'ALL')) return true;
                
                if (slide.course_id && slide.course_id !== 'ALL') {
                  return String(data.user?.course_id) === String(slide.course_id) || 
                         data.user?.enrolled_courses?.some((c: any) => typeof c === 'string' ? String(c) === String(slide.course_id) : String(c.id) === String(slide.course_id)) ||
                         enrollments.some((e: any) => String(e.course_id) === String(slide.course_id) && (e.status === 'approved' || e.status === 'contacted'));
                }

                if (slide.program_id && slide.program_id !== 'ALL') {
                  const isEnrolledInProgram = String(data.user?.program_id) === String(slide.program_id) || 
                                              enrollments.some((e: any) => String(e.program_id) === String(slide.program_id) && (e.status === 'approved' || e.status === 'contacted'));
                  if (!isEnrolledInProgram) return false;
                  
                  if (slide.batch_id && slide.batch_id !== 'ALL') {
                    return String(data.user?.batch_id) === String(slide.batch_id) || 
                           String(data.user?.batch_id_2) === String(slide.batch_id) ||
                           enrollments.some((e: any) => String(e.batch_id) === String(slide.batch_id) && (e.status === 'approved' || e.status === 'contacted'));
                  }
                  return true;
                }
                
                return false;
              }).slice(0, 3).map((slide: any) => (
                <div key={slide.id} onClick={() => navigate('/dashboard/class-slides')} className="glass p-6 rounded-3xl border border-white/60 shadow-xl bg-white/50 flex flex-col gap-4 cursor-pointer hover:scale-[1.02] transition-transform">
                  <img src={slide.image_url} alt="Slide" className="w-full h-48 object-cover rounded-2xl" referrerPolicy="no-referrer" />
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                      {new Date(slide.created_at).toLocaleString()}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Enrolled Programs & Courses */}
          <motion.div 
            whileHover={{ y: -5 }}
            className="bg-white/80 backdrop-blur-xl rounded-[2.5rem] border border-white shadow-xl p-8"
          >
            <h3 className="text-xl font-black text-slate-900 mb-6 flex items-center gap-3">
              <div className="bg-orange-100 p-2 rounded-xl text-orange-600">
                <Award className="h-6 w-6" />
              </div>
              My Enrollments
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {enrollments.map((enroll, i) => (
                <motion.div 
                  key={`enroll-${i}`} 
                  whileHover={{ y: -5, backgroundColor: '#fff' }}
                  className="p-8 bg-white/50 backdrop-blur-md rounded-[2.5rem] border border-white/60 flex flex-col gap-6 transition-all shadow-xl shadow-orange-600/5 group"
                >
                  <div className="flex justify-between items-start">
                    <div className="flex items-center gap-5">
                      <div className="bg-orange-600 p-4 rounded-2xl text-white shadow-2xl shadow-orange-600/30 group-hover:scale-110 transition-transform">
                        {enroll.course_title ? <BookOpen className="h-6 w-6" /> : <GraduationCap className="h-6 w-6" />}
                      </div>
                      <div>
                        <h4 className="font-black text-2xl text-slate-900 tracking-tight leading-tight">
                          {enroll.course_title || enroll.program_title || 'Academic Program'}
                        </h4>
                        <div className="flex flex-wrap gap-2 mt-1">
                          <p className="text-[10px] font-black uppercase tracking-widest text-orange-600">
                            {enroll.student_type === 'online' ? 'Online Course' : (enroll.program_title || 'Registration')}
                          </p>
                          {(enroll.current_class || enroll.class) && (
                            <span className="text-[10px] font-black uppercase tracking-widest bg-slate-100 px-2 py-0.5 rounded text-slate-600">
                              Class: {enroll.current_class || enroll.class}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className={`p-3 rounded-2xl shadow-lg ${enroll.status === 'approved' || enroll.status === 'contacted' ? 'bg-green-100 text-green-600 shadow-green-100' : 'bg-orange-100 text-orange-600 shadow-orange-100'}`}>
                      <CheckCircle className="h-6 w-6" />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-white/60 backdrop-blur-md p-4 rounded-2xl border border-white/60 shadow-sm">
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Fee Status</p>
                      <p className="text-xl font-black text-slate-900 tracking-tight">৳{enroll.admission_fee || enroll.fee || 0}</p>
                    </div>
                    <div className="bg-white/60 backdrop-blur-md p-4 rounded-2xl border border-white/60 shadow-sm">
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Monthly</p>
                      <p className="text-xl font-black text-slate-900 tracking-tight">৳{enroll.monthly_fee || 0}</p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                      <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">{enroll.status || 'Active'}</span>
                    </div>
                    <Link to="/dashboard/enrollments" className="text-[10px] font-black text-orange-600 uppercase tracking-widest flex items-center gap-1 hover:gap-2 transition-all">
                      Details <ArrowRight className="h-3 w-3" />
                    </Link>
                  </div>
                </motion.div>
              ))}
              {enrollments.length === 0 && (
                <div className="col-span-full text-center py-16 bg-slate-50/50 rounded-[2.5rem] border border-dashed border-slate-200">
                  <BookOpen className="h-16 w-16 text-slate-200 mx-auto mb-4" />
                  <h4 className="text-xl font-black text-slate-400">No active enrollments</h4>
                  <p className="text-slate-400 text-sm mt-2">Contact admin if you think this is an error</p>
                  <Link to="/dashboard/enrollments" className="mt-6 inline-flex items-center gap-2 bg-white px-6 py-3 rounded-xl border border-slate-200 text-sm font-bold text-slate-600 hover:bg-slate-50 transition-colors">
                    Check Enrollment Status <ArrowRight className="h-4 w-4" />
                  </Link>
                </div>
              )}
            </div>
          </motion.div>

          {/* Quick Actions */}
          <motion.div 
            whileHover={{ y: -5 }}
            className="bg-white/80 backdrop-blur-xl rounded-[2.5rem] border border-white shadow-xl p-8"
          >
            <h3 className="text-xl font-black text-slate-900 mb-6 flex items-center gap-3">
              <div className="bg-orange-100 p-2 rounded-xl text-orange-600">
                <PlayCircle className="h-6 w-6" />
              </div>
              Quick Actions
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 h-[calc(100%-4rem)]">
              <Link to="/dashboard/classes" className="p-6 bg-slate-50/50 rounded-2xl border border-slate-100 flex flex-col items-center justify-center gap-3 hover:bg-orange-50 hover:border-orange-100 transition-all group shadow-sm hover:shadow-md">
                <PlayCircle className="h-8 w-8 text-orange-600 group-hover:scale-110 transition-transform" />
                <span className="font-bold text-slate-700 text-sm">Recorded Classes</span>
              </Link>
              <Link to="/dashboard/materials" className="p-6 bg-slate-50/50 rounded-2xl border border-slate-100 flex flex-col items-center justify-center gap-3 hover:bg-orange-50 hover:border-orange-100 transition-all group shadow-sm hover:shadow-md">
                <BookOpen className="h-8 w-8 text-orange-600 group-hover:scale-110 transition-transform" />
                <span className="font-bold text-slate-700 text-sm">Study Materials</span>
              </Link>
              <Link to="/dashboard/routines" className="p-6 bg-slate-50/50 rounded-2xl border border-slate-100 flex flex-col items-center justify-center gap-3 hover:bg-orange-50 hover:border-orange-100 transition-all group shadow-sm hover:shadow-md">
                <Calendar className="h-8 w-8 text-orange-600 group-hover:scale-110 transition-transform" />
                <span className="font-bold text-slate-700 text-sm">Class Routine</span>
              </Link>
              <Link to="/dashboard/notices" className="p-6 bg-slate-50/50 rounded-2xl border border-slate-100 flex flex-col items-center justify-center gap-3 hover:bg-orange-50 hover:border-orange-100 transition-all group shadow-sm hover:shadow-md">
                <Bell className="h-8 w-8 text-orange-600 group-hover:scale-110 transition-transform" />
                <span className="font-bold text-slate-700 text-sm">Notices</span>
              </Link>
              <Link to="/dashboard/profile" className="p-6 bg-slate-50/50 rounded-2xl border border-slate-100 flex flex-col items-center justify-center gap-3 hover:bg-orange-50 hover:border-orange-100 transition-all group shadow-sm hover:shadow-md">
                <User className="h-8 w-8 text-orange-600 group-hover:scale-110 transition-transform" />
                <span className="font-bold text-slate-700 text-sm">My Profile</span>
              </Link>
              <Link to="/dashboard/enrollments" className="p-6 bg-slate-50/50 rounded-2xl border border-slate-100 flex flex-col items-center justify-center gap-3 hover:bg-orange-50 hover:border-orange-100 transition-all group shadow-sm hover:shadow-md">
                <GraduationCap className="h-8 w-8 text-orange-600 group-hover:scale-110 transition-transform" />
                <span className="font-bold text-slate-700 text-sm">Enrollments</span>
              </Link>
            </div>
          </motion.div>
        </div>
          <div className="glass rounded-[2.5rem] border border-white/60 shadow-xl p-8 lg:col-span-2 bg-white/40">
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-3">
                <div className="bg-orange-100 p-2 rounded-xl text-orange-600 shadow-lg shadow-orange-100">
                  <Bell className="h-6 w-6" />
                </div>
                Recent Notices
              </h3>
              <Link to="/notices" className="text-xs font-black text-orange-600 hover:underline uppercase tracking-widest bg-orange-50 px-4 py-2 rounded-xl border border-orange-100">
                View All
              </Link>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {notices
                .filter((n: any) => {
                  const audienceMatch = n.target_audience === 'all' || !n.target_audience || n.target_audience === data.user.student_type;
                  const hasSelection = n.batch_id || n.program_id || n.course_id;
                  
                  if (!hasSelection) return false;
                  
                  const matchesBatch = n.batch_id ? String(n.batch_id) === String(data.user.batch_id) : false;
                  const matchesProgram = n.program_id ? String(n.program_id) === String(data.user.program_id) : false;
                  const matchesCourse = n.course_id ? (data.user.enrolled_courses || []).includes(n.course_id) : false;
                  
                  return audienceMatch && (matchesBatch || matchesProgram || matchesCourse);
                })
                .slice(0, 3)
                .map((notice, i) => (
                <Link 
                  key={i} 
                  to="/notices"
                  className="glass rounded-[2rem] shadow-lg overflow-hidden border border-white/60 group hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 flex flex-col bg-white/60"
                >
                  <div className="relative h-32 bg-gradient-to-br from-orange-500 to-orange-600 overflow-hidden">
                    <div className="absolute inset-0 flex items-center justify-center opacity-20 group-hover:scale-110 transition-transform duration-700">
                      <Bell className="h-20 w-20 text-white" />
                    </div>
                    <div className="absolute inset-0 bg-orange-900/10 group-hover:bg-transparent transition-colors" />
                    <div className="absolute bottom-3 left-3 right-3 flex justify-between items-end">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-1 bg-white/20 backdrop-blur-md text-white text-[10px] font-black rounded-lg shadow-lg border border-white/30 uppercase tracking-widest">
                          Notice
                        </span>
                      </div>
                      <div className="flex items-center gap-1 text-white/90 text-[10px] font-black bg-orange-900/20 px-2 py-1 rounded-lg backdrop-blur-sm uppercase tracking-widest">
                        <Calendar className="h-3 w-3" />
                        {new Date(notice.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                      </div>
                    </div>
                  </div>
                  
                  <div className="p-6 flex-1 flex flex-col">
                    <h3 className="text-lg font-black text-slate-900 leading-tight mb-3 group-hover:text-orange-600 transition-colors line-clamp-2 tracking-tight">
                      {notice.title}
                    </h3>

                    <p className="text-slate-500 text-sm line-clamp-2 leading-relaxed flex-1 font-medium">
                      {notice.content}
                    </p>

                    <div className="pt-5 mt-4 flex items-center justify-between border-t border-white/60">
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Read Full</span>
                      <div className="flex items-center gap-1 text-orange-600 font-black text-[10px] uppercase tracking-widest group-hover:translate-x-1 transition-transform">
                        Details <ArrowRight className="h-3 w-3" />
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
              {notices.length === 0 && (
                <div className="col-span-full text-center py-10 bg-white/20 rounded-3xl border border-dashed border-slate-200">
                  <Bell className="h-10 w-10 text-slate-200 mx-auto mb-3" />
                  <p className="text-slate-400 font-black text-xs uppercase tracking-widest">No notices yet</p>
                </div>
              )}
            </div>
          </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
          {/* Recent Attendance */}
          <motion.div 
            whileHover={{ y: -5 }}
            className="bg-white/80 backdrop-blur-xl rounded-[2.5rem] border border-white shadow-xl p-8"
          >
            <h3 className="text-xl font-black text-slate-900 mb-6 flex items-center gap-3">
              <div className="bg-orange-100 p-2 rounded-xl text-orange-600">
                <CheckCircle className="h-6 w-6" />
              </div>
              Recent Attendance
            </h3>
            <div className="space-y-4">
              {(data.attendance || []).slice(0, 5).map((record: any, i: number) => (
                <motion.div 
                  key={i} 
                  whileHover={{ x: 10, backgroundColor: '#fff' }}
                  className="p-5 bg-slate-50/50 rounded-2xl border border-slate-100 flex justify-between items-center transition-all"
                >
                  <div className="flex items-center gap-4">
                    <div className={`w-3 h-3 rounded-full ${record.status === 'present' ? 'bg-green-500 shadow-[0_0_10px_rgba(34,197,94,0.4)]' : 'bg-red-500 shadow-[0_0_10px_rgba(239,68,68,0.4)]'}`} />
                    <div>
                      <h4 className="font-black text-slate-800">{new Date(record.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</h4>
                      <p className="text-[10px] text-slate-400 uppercase font-black tracking-widest">{new Date(record.date).toLocaleDateString('en-US', { weekday: 'long' })}</p>
                    </div>
                  </div>
                  <span className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest ${
                    record.status === 'present' ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'
                  }`}>
                    {record.status}
                  </span>
                </motion.div>
              ))}
              {(data.attendance || []).length === 0 && (
                <div className="text-center py-10">
                  <Calendar className="h-12 w-12 text-slate-200 mx-auto mb-4" />
                  <p className="text-slate-400 font-bold">No records found</p>
                </div>
              )}
              <Link to="/dashboard/attendance" className="block text-center text-sm font-black text-orange-600 hover:underline mt-4 uppercase tracking-widest">
                View Full History
              </Link>
            </div>
          </motion.div>

          {/* Recent Results */}
          <motion.div 
            whileHover={{ y: -5 }}
            className="bg-white/80 backdrop-blur-xl rounded-[2.5rem] border border-white shadow-xl p-8"
          >
            <h3 className="text-xl font-black text-slate-900 mb-6 flex items-center gap-3">
              <div className="bg-orange-100 p-2 rounded-xl text-orange-600">
                <FileText className="h-6 w-6" />
              </div>
              Recent Results
            </h3>
            <div className="space-y-4">
              {data.results.slice(0, 5).map((result, i) => (
                <motion.div 
                  key={i} 
                  whileHover={{ x: 10, backgroundColor: '#fff' }}
                  className="p-5 bg-slate-50/50 rounded-2xl border border-slate-100 flex justify-between items-center transition-all"
                >
                  <div>
                    <h4 className="font-black text-slate-800">{result.exam_name}</h4>
                    <p className="text-sm font-medium text-slate-500 mt-1">
                      Marks: <span className="font-black text-orange-600">{result.marks}</span> / {result.total_marks}
                    </p>
                  </div>
                  <div className="text-right bg-white p-3 rounded-2xl border border-slate-100 shadow-sm">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Merit Position</p>
                    <p className="text-xl font-black text-orange-600">{result.merit_position ? `#${result.merit_position}` : '-'}</p>
                  </div>
                </motion.div>
              ))}
              {data.results.length === 0 && (
                <div className="text-center py-10">
                  <Award className="h-12 w-12 text-slate-200 mx-auto mb-4" />
                  <p className="text-slate-400 font-bold">No results found</p>
                </div>
              )}
            </div>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
          {/* Study Materials */}
          <motion.div 
            whileHover={{ y: -5 }}
            className="bg-white/80 backdrop-blur-xl rounded-[2.5rem] border border-white shadow-xl p-8"
          >
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-black text-slate-900 flex items-center gap-3">
                <div className="bg-orange-100 p-2 rounded-xl text-orange-600">
                  <BookOpen className="h-6 w-6" />
                </div>
                Study Materials
              </h3>
              <button onClick={() => navigate('/dashboard/materials')} className="text-sm font-bold text-orange-600 hover:text-orange-700">View All</button>
            </div>
            <div className="space-y-4">
              {filteredStudyMaterials.slice(0, 3).map((mat, i) => (
                <motion.div 
                  key={i} 
                  whileHover={{ x: 10, backgroundColor: '#fff' }}
                  className="p-5 bg-slate-50/50 rounded-2xl border border-slate-100 flex justify-between items-center transition-all"
                >
                  <div className="flex items-center gap-4">
                    <div className="bg-white p-3 rounded-xl shadow-sm border border-slate-100">
                      <FileText className="h-5 w-5 text-orange-600" />
                    </div>
                    <div>
                      <h4 className="font-black text-slate-800">{mat.title}</h4>
                      <p className="text-[10px] text-slate-400 uppercase font-black tracking-widest">{mat.type === 'link' ? 'Link' : 'PDF Document'}</p>
                    </div>
                  </div>
                  <a 
                    href={mat.url} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="p-3 bg-orange-600 text-white rounded-xl shadow-lg shadow-orange-200 hover:bg-orange-700 transition-all hover:scale-110"
                  >
                    <Download className="h-4 w-4" />
                  </a>
                </motion.div>
              ))}
              {filteredStudyMaterials.length === 0 && (
                <div className="text-center py-10">
                  <BookOpen className="h-12 w-12 text-slate-200 mx-auto mb-4" />
                  <p className="text-slate-400 font-bold">No materials found</p>
                </div>
              )}
            </div>
          </motion.div>

          {/* Support / Help */}
          <motion.div 
            whileHover={{ y: -5 }}
            className="bg-white/80 backdrop-blur-xl rounded-[2.5rem] border border-white shadow-xl p-8"
          >
            <h3 className="text-xl font-black text-slate-900 mb-6 flex items-center gap-3">
              <div className="bg-orange-100 p-2 rounded-xl text-orange-600">
                <ExternalLink className="h-6 w-6" />
              </div>
              Need Help?
            </h3>
            <div className="p-6 bg-orange-50 rounded-2xl border border-orange-100 flex flex-col items-center justify-center text-center gap-4 h-[calc(100%-4rem)]">
              <div className="bg-white p-4 rounded-full shadow-md">
                <Phone className="h-8 w-8 text-orange-600" />
              </div>
              <div>
                <h4 className="font-black text-slate-900 text-lg">Contact Support</h4>
                <p className="text-slate-500 text-sm mt-1">Having trouble? Reach out to our support team for assistance.</p>
              </div>
              <Link to="/contact" className="mt-2 px-6 py-3 bg-orange-600 text-white font-bold rounded-xl shadow-md hover:bg-orange-700 transition-colors">
                Contact Us
              </Link>
            </div>
          </motion.div>
        </div>

        {data.user?.student_type !== 'online' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-8">
          {/* Upcoming Exams */}
          <div className="glass rounded-[2.5rem] border border-white/60 shadow-xl p-8 bg-white/40">
            <h3 className="text-2xl font-black text-slate-900 mb-8 flex items-center gap-3 tracking-tight">
              <div className="bg-orange-100 p-2 rounded-xl text-orange-600 shadow-lg shadow-orange-100">
                <Calendar className="h-6 w-6" />
              </div>
              Upcoming Exams
            </h3>
            <div className="space-y-4">
              {exams.filter(e => {
                if (e.published) return false;
                if (!e.course_id && !e.program_id && (!e.batch_id || e.batch_id === 'all')) return true;
                
                if (e.course_id && e.course_id !== 'all') {
                  const hasCourse = String(data.user?.course_id) === String(e.course_id) || 
                         data.user?.enrolled_courses?.some((c: any) => typeof c === 'string' ? String(c) === String(e.course_id) : String(c.id) === String(e.course_id)) ||
                         enrollments.some((en: any) => String(en.course_id) === String(e.course_id) && (en.status === 'approved' || en.status === 'contacted'));
                  if (hasCourse) return true;
                }

                if (e.program_id && e.program_id !== 'all') {
                  const isEnrolledInProgram = String(data.user?.program_id) === String(e.program_id) || 
                                              enrollments.some((en: any) => String(en.program_id) === String(e.program_id) && (en.status === 'approved' || en.status === 'contacted'));
                  if (!isEnrolledInProgram) return false;
                  
                  if (e.batch_id && e.batch_id !== 'all') {
                    return String(data.user?.batch_id) === String(e.batch_id) || 
                           String(data.user?.batch_id_2) === String(e.batch_id) ||
                           enrollments.some((en: any) => String(en.batch_id) === String(e.batch_id) && (en.status === 'approved' || en.status === 'contacted'));
                  }
                  return true;
                }
                
                return false;
              }).slice(0, 3).map((exam, i) => (
                <div key={i} className="p-6 bg-white/60 rounded-2xl border border-white/60 flex justify-between items-center shadow-lg hover:bg-white transition-all group">
                  <div className="flex items-center gap-5">
                    <div className="bg-orange-600 p-3 rounded-xl text-white shadow-lg shadow-orange-100 group-hover:scale-110 transition-transform">
                      <FileText className="h-5 w-5" />
                    </div>
                    <div>
                      <h4 className="font-black text-slate-900 tracking-tight">{exam.exam_name}</h4>
                      <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mt-1">{new Date(exam.exam_date).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}</p>
                    </div>
                  </div>
                  <div className="px-4 py-1.5 bg-orange-50 text-orange-600 rounded-xl text-[10px] font-black uppercase tracking-widest border border-orange-100">
                    Exam
                  </div>
                </div>
              ))}
              {exams.length === 0 && (
                <div className="text-center py-10 bg-white/20 rounded-3xl border border-dashed border-slate-200">
                  <Calendar className="h-10 w-10 text-slate-200 mx-auto mb-3" />
                  <p className="text-slate-400 font-black text-xs uppercase tracking-widest">No exams scheduled</p>
                </div>
              )}
            </div>
          </div>
        </div>
        )}

        {/* Submit Review Section */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="glass rounded-[2.5rem] border border-white/60 shadow-xl p-10 mt-8 bg-white/40"
        >
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-10">
            <div>
              <h3 className="text-3xl font-black text-slate-900 tracking-tight flex items-center gap-3">
                <div className="bg-orange-100 p-2 rounded-xl text-orange-600 shadow-lg shadow-orange-100">
                  <Award className="h-6 w-6" />
                </div>
                Submit a Review
              </h3>
              <p className="text-slate-500 mt-2 font-medium">We value your feedback! Share your learning experience with us.</p>
            </div>
          </div>

          <form 
            onSubmit={async (e) => {
              e.preventDefault();
              const form = e.target as HTMLFormElement;
              const rating = parseInt((form.elements.namedItem('rating') as HTMLSelectElement).value);
              const comment = (form.elements.namedItem('comment') as HTMLTextAreaElement).value;
              
              try {
                const res = await fetch('/api/reviews', {
                  method: 'POST',
                  headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${token}`
                  },
                  body: JSON.stringify({
                    student_id: data.user.id,
                    student_name: data.user.name,
                    student_image: data.user.profile_pic || "",
                    rating,
                    comment,
                    created_at: new Date().toISOString(),
                    status: "pending",
                  }),
                });
                
                if (res.ok) {
                  setReviewStatus({ type: 'success', message: 'Review submitted successfully!' });
                  form.reset();
                  setTimeout(() => setReviewStatus(null), 5000);
                } else {
                  setReviewStatus({ type: 'error', message: 'Failed to submit review.' });
                  setTimeout(() => setReviewStatus(null), 5000);
                }
              } catch (error) {
                console.error('Error submitting review:', error);
                setReviewStatus({ type: 'error', message: 'An error occurred.' });
                setTimeout(() => setReviewStatus(null), 5000);
              }
            }}
            className="grid grid-cols-1 md:grid-cols-2 gap-8"
          >
            <div className="space-y-6">
              {reviewStatus && (
                <div className={`p-4 rounded-2xl text-sm font-bold ${reviewStatus.type === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                  {reviewStatus.message}
                </div>
              )}
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">Your Rating</label>
                <div className="relative">
                  <select name="rating" required className="w-full p-5 rounded-2xl bg-white/60 border border-white/60 focus:outline-none focus:ring-4 focus:ring-orange-500/10 transition-all font-black text-slate-900 appearance-none shadow-inner">
                    <option value="5">5 Stars - Excellent</option>
                    <option value="4">4 Stars - Very Good</option>
                    <option value="3">3 Stars - Good</option>
                    <option value="2">2 Stars - Fair</option>
                    <option value="1">1 Star - Poor</option>
                  </select>
                  <div className="absolute right-5 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
                    <ArrowRight className="h-5 w-5 rotate-90" />
                  </div>
                </div>
              </div>
              <button 
                type="submit" 
                className="w-full bg-orange-600 text-white px-8 py-5 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-orange-700 transition-all shadow-xl shadow-orange-200 active:scale-95 flex items-center justify-center gap-3"
              >
                Submit Review
                <ArrowRight className="h-5 w-5" />
              </button>
            </div>
            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">Your Experience</label>
              <textarea 
                name="comment" 
                required 
                rows={5} 
                className="w-full p-6 rounded-2xl bg-white/60 border border-white/60 focus:outline-none focus:ring-4 focus:ring-orange-500/10 transition-all font-medium text-slate-700 placeholder:text-slate-300 shadow-inner resize-none"
                placeholder="Tell us what you liked or how we can improve..."
              ></textarea>
            </div>
          </form>
        </motion.div>
      </motion.div>
    </div>
  );
};

export default Dashboard;
