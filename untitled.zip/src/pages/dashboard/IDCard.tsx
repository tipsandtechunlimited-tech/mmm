import React, { useRef, useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useSettings } from '../../context/SettingsContext';
import { QRCodeSVG } from 'qrcode.react';
import { Download, CreditCard, CheckCircle, ShieldCheck, Mail, Phone, Calendar, School, Printer, Image as ImageIcon } from 'lucide-react';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';
import { motion } from 'motion/react';

const IDCard = () => {
  const { user } = useAuth();
  const { settings } = useSettings();
  const cardRef = useRef<HTMLDivElement>(null);
  const [downloading, setDownloading] = useState(false);

  const handleDownloadPDF = async () => {
    if (cardRef.current) {
      setDownloading(true);
      try {
        // Prepare element for capture (slight delay for rendering)
        await new Promise(resolve => setTimeout(resolve, 200));
        
        const canvas = await html2canvas(cardRef.current, {
          useCORS: true,
          scale: 3,
          backgroundColor: '#ffffff',
          logging: false,
          allowTaint: true,
          onclone: (clonedDoc) => {
            // Ensure any cloned images are also CORS capable if possible
            const images = clonedDoc.getElementsByTagName('img');
            for (let i = 0; i < images.length; i++) {
              images[i].crossOrigin = "anonymous";
            }
          }
        });
        
        const imgData = canvas.toDataURL('image/png', 1.0);
        const pdf = new jsPDF({
          orientation: 'portrait',
          unit: 'px',
          format: [canvas.width / 3, canvas.height / 3]
        });
        
        pdf.addImage(imgData, 'PNG', 0, 0, canvas.width / 3, canvas.height / 3);
        pdf.save(`ID_${user?.roll_number || 'STUDENT'}_${Date.now()}.pdf`);
      } catch (err) {
        console.error("PDF download failed", err);
      } finally {
        setDownloading(false);
      }
    }
  };

  const handleDownloadImage = async () => {
    if (cardRef.current) {
      setDownloading(true);
      try {
        await new Promise(resolve => setTimeout(resolve, 200));

        const canvas = await html2canvas(cardRef.current, {
          useCORS: true,
          scale: 4,
          backgroundColor: '#ffffff',
          logging: false,
          allowTaint: true
        });
        
        const link = document.createElement('a');
        link.download = `ID_${user?.roll_number || 'STUDENT'}_${Date.now()}.png`;
        link.href = canvas.toDataURL('image/png', 1.0);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      } catch (err) {
        console.error("Image download failed", err);
      } finally {
        setDownloading(false);
      }
    }
  };

  if (!user) return null;

  const getBatchName = () => {
    if (!user.batch_id) return 'Not Assigned';
    if (user.batch_name) return user.batch_name;
    return String(user.batch_id).length > 10 ? 'Assigned Batch' : user.batch_id;
  };

  return (
    <div className="space-y-10 animate-fade-in pb-20">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
        <div>
          <h1 className="text-3xl lg:text-4xl font-black text-slate-900 tracking-tight flex items-center gap-3">
            <CreditCard className="h-10 w-10 text-orange-600" />
            Student ID Card
          </h1>
          <p className="text-slate-500 mt-2 font-semibold tracker-tight">Official Identity documentation for {(settings.site_name || "Jaber Math Care")}</p>
        </div>
        
        <div className="flex flex-wrap gap-4 w-full lg:w-auto">
          <button
            onClick={handleDownloadPDF}
            disabled={downloading}
            className="flex-1 lg:flex-none bg-slate-900 text-white px-6 py-4 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-slate-950/20 hover:bg-slate-800 hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-2.5 disabled:opacity-50 disabled:cursor-not-allowed group"
          >
            <Printer className="h-4 w-4 group-hover:rotate-12 transition-transform" />
            {downloading ? "Processing..." : "Download PDF"}
          </button>
          <button
            onClick={handleDownloadImage}
            disabled={downloading}
            className="flex-1 lg:flex-none bg-orange-600 text-white px-6 py-4 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-orange-600/20 hover:bg-orange-700 hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-2.5 disabled:opacity-50 disabled:cursor-not-allowed group"
          >
            <ImageIcon className="h-4 w-4 group-hover:-translate-y-0.5 transition-transform" />
            {downloading ? "Processing..." : "Save Image"}
          </button>
        </div>
      </div>

      <div className="flex justify-center pt-4 lg:pt-8">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          ref={cardRef}
          className="relative bg-white shadow-[0_20px_50px_-10px_rgba(0,0,0,0.15)] overflow-hidden border border-slate-300 flex flex-col group p-0 select-none text-left"
          style={{ width: '320px', height: '480px' }}
        >
          {/* Top Logo & Title Section */}
          <div className="relative pt-4 px-4 flex items-start justify-between z-20">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 flex items-center justify-center">
                {settings.logo_url ? (
                  <img src={settings.logo_url} alt="Logo" className="w-full h-full object-contain" crossOrigin="anonymous" referrerPolicy="no-referrer" />
                ) : (
                  <div className="bg-orange-700 p-1.5 rounded-lg">
                    <School className="h-6 w-6 text-white" />
                  </div>
                )}
              </div>
              <div className="flex flex-col">
                <h2 className="text-orange-950 text-base font-black tracking-tighter leading-none">{(settings.site_name || "Jaber Math Care")}</h2>
                <p className="text-[7px] text-orange-900 font-bold uppercase tracking-wider mt-0.5 opacity-80">Engineers are born here</p>
              </div>
            </div>
          </div>

          {/* Decorative Curves - Matches Screenshot Style */}
          <div className="absolute top-0 right-0 w-24 h-[250px] bg-orange-700 rounded-bl-[100%] z-10 opacity-95" />
          <div className="absolute bottom-0 left-0 w-16 h-[300px] bg-orange-700 rounded-tr-[100%] z-10 opacity-90 translate-y-1/2 -translate-x-1/4 rotate-12" />

          {/* Profile Picture */}
          <div className="relative mt-2 flex justify-center z-20">
            <div className="w-28 h-28 bg-orange-900 rounded-full border-2 border-white shadow-lg overflow-hidden p-0.5">
               <div className="w-full h-full rounded-full overflow-hidden bg-slate-50 flex items-center justify-center">
                  {user.profile_pic ? (
                    <img src={user.profile_pic} alt={user.name} className="w-full h-full object-cover" crossOrigin="anonymous" referrerPolicy="no-referrer" />
                  ) : (
                    <div className="text-3xl font-black text-slate-200 uppercase">
                      {user.name?.charAt(0)}
                    </div>
                  )}
               </div>
            </div>
          </div>

          {/* Student Name Box */}
          <div className="relative mt-4 px-6 z-20">
             <div className="border-[1.5px] border-orange-900 rounded-xl py-1 px-3 bg-white shadow-sm flex items-center justify-center">
                <h3 className="text-lg font-black text-orange-950 uppercase tracking-tight truncate">{user.name}</h3>
             </div>
          </div>

          {/* Info Rows */}
          <div className="relative mt-3 px-6 space-y-1 z-20 flex-1">
            {[
              { label: 'Class', value: user.current_class || user.class || 'HSC 27' },
              { label: 'Batch', value: getBatchName() },
              { label: 'Roll', value: user.roll_number || '---' },
              { label: 'Phone', value: user.phone || '01XXXXXXXXX' },
              { label: 'Blood', value: user.blood_group || 'N/A' }
            ].map((item, idx) => (
              <div key={idx} className="flex items-center gap-2">
                 <span className="text-[10px] font-bold text-slate-800 w-8 shrink-0">{item.label}</span>
                 <span className="text-[10px] font-bold text-slate-400 w-3 text-center">:</span>
                 <div className="flex-1 bg-slate-50 border border-slate-100 rounded px-2 py-0.5 text-[10px] font-black text-slate-900 uppercase truncate">
                   {item.value}
                 </div>
              </div>
            ))}
          </div>

          {/* QR Code Section */}
          <div className="relative pb-3 flex flex-col items-center z-20">
             <div className="bg-white p-1 borderRadius-lg border-2 border-slate-50 shadow-sm mb-1.5 transform hover:scale-110 transition-transform">
                <QRCodeSVG 
                   value={`JABER-MATH-${user.roll_number || user.id}`}
                   size={80}
                   level="H"
                   includeMargin={false}
                />
             </div>
             <p className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">www.jabermathcare.com</p>
          </div>

          {/* Sideways Text */}
          <div className="absolute right-2 bottom-12 select-none pointer-events-none origin-bottom-right rotate-[-90deg] translate-y-full opacity-10">
             <span className="text-3xl font-black text-orange-950 uppercase whitespace-nowrap tracking-[0.2em] leading-none">{(settings.site_name || "Jaber Math Care")}</span>
          </div>

          <div className="h-0.5 bg-orange-700 w-full z-30" />
        </motion.div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
        <div className="glass p-6 rounded-3xl border border-white/60 shadow-lg group hover:bg-white transition-colors">
          <div className="flex gap-4">
            <div className="bg-orange-100 p-3 rounded-2xl shrink-0">
               <ShieldCheck className="h-6 w-6 text-orange-600" />
            </div>
            <div>
               <h4 className="text-base font-black text-slate-900 mb-1">Official ID Security</h4>
               <p className="text-xs text-slate-500 font-medium leading-relaxed">
                 এটি আপনার ডিজিটাল পরিচয়। আপনার বারকোডটি স্ক্যান করে যেকোনো সময় আপনার উপস্থিতি নিশ্চিত করা যাবে।
               </p>
            </div>
          </div>
        </div>
        <div className="glass p-6 rounded-3xl border border-white/60 shadow-lg group hover:bg-white transition-colors">
          <div className="flex gap-4">
            <div className="bg-slate-100 p-3 rounded-2xl shrink-0">
               <Printer className="h-6 w-6 text-slate-600" />
            </div>
            <div>
               <h4 className="text-base font-black text-slate-900 mb-1">Printing Support</h4>
               <p className="text-xs text-slate-500 font-medium leading-relaxed">
                 কার্ডটি পিডিএফ অথবা ইমেজ হিসেবে ডাউনলোড করে প্রিন্ট করে আপনার সাথে সংরক্ষণ করতে পারেন।
               </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default IDCard;
