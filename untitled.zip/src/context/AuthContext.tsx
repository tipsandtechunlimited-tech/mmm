import React, { createContext, useContext, useState, useEffect } from 'react';
import { onIdTokenChanged, signOut, User as FirebaseUser } from 'firebase/auth';
import { doc, getDoc, onSnapshot as onSnapshotFirestore, setDoc, query, collection, limit, getDocs } from 'firebase/firestore';
import { auth, db } from '../firebase';

interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'student' | 'moderator';
  roll_number?: string;
  batch_id?: string | number;
  batch_id_2?: string | number;
  program_id?: string;
  program_title?: string;
  course_id?: string;
  course_title?: string;
  student_type?: string;
  profile_pic?: string;
  blood_group?: string;
  phone?: string;
  address?: string;
  school_name?: string;
  college_name?: string;
  class?: string;
  current_class?: string;
  paid_amount?: number;
  monthly_fee?: number;
  batch_name?: string;
  enrolled_courses?: any[];
}

interface AuthContextType {
  user: User | null;
  token: string | null;
  login: (token: string, user: User) => void;
  refreshUser: () => Promise<void>;
  logout: () => void;
  isAuthenticated: boolean;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let isTimeoutGrounded = false;
    const fallbackTimeout = setTimeout(() => {
       isTimeoutGrounded = true;
       setLoading(false);
       console.warn("AuthContext loading timeout reached (5s). Forcing load complete.");
    }, 5000);

    const unsubscribe = onIdTokenChanged(auth, async (firebaseUser) => {
          clearTimeout(fallbackTimeout);
      if (firebaseUser) {
        
        // Safety timeout for getDoc/setDoc operations
        const innerTimeout = setTimeout(() => {
           setLoading(false);
           console.warn("Firestore blocked the auth check for 5s. Continuing anyway.");
        }, 5000);

        try {
          const idToken = await firebaseUser.getIdToken();
          setToken(idToken);
          
          const adminEmails = ['jabermathcare@gmail.com', 'contact.jabermathcare@gmail.com', 'mdabudarda2012@gmail.com', 'tipsandtechunlimited@gmail.com'].map(e => e.toLowerCase());
          
          // Also check localStorage for temporary admins
          const tempAdmins = JSON.parse(localStorage.getItem('temp_admin_emails') || '[]');
          const allAdminEmails = [...adminEmails, ...tempAdmins].map(e => e.toLowerCase());
          
          const userEmail = (firebaseUser.email || '').toLowerCase();
          const isAdminEmail = allAdminEmails.includes(userEmail);

          if (isAdminEmail) {
            // Set initial admin state instantly
            setUser({
              id: firebaseUser.uid,
              name: firebaseUser.displayName || 'Admin',
              email: firebaseUser.email || '',
              role: 'admin'
            });
          }

          try {
            const userDoc = await getDoc(doc(db, 'users', firebaseUser.uid));
            
            // Bootstrap logic: if no users exist in the system, the first person to log in becomes an admin
            // This is useful for new Firebase setups.
            if (!userDoc.exists()) {
              const usersSnapshot = await getDocs(query(collection(db, 'users'), limit(1)));
              if (usersSnapshot.empty) {
                console.log("Bootstrap: First user detected, granting admin role.");
                await setDoc(doc(db, 'users', firebaseUser.uid), {
                  name: firebaseUser.displayName || 'Super Admin',
                  email: firebaseUser.email || '',
                  role: 'admin',
                  created_at: new Date().toISOString()
                });
                setUser({
                  id: firebaseUser.uid,
                  name: firebaseUser.displayName || 'Super Admin',
                  email: firebaseUser.email || '',
                  role: 'admin'
                });
                return;
              }
            }

            if (userDoc.exists()) {
              const userData = userDoc.data() as User;
              
              // Force admin role if email is in whitelist
              if (isAdminEmail && userData.role !== 'admin') {
                userData.role = 'admin';
                await setDoc(doc(db, 'users', firebaseUser.uid), { ...userData, role: 'admin' }, { merge: true });
              }

              // Check if student is approved, but bypass for admin emails
              if (userData.role === 'student' && (userData as any).status === 'pending' && !isAdminEmail) {
                console.warn('Student account is pending approval');
              }
              setUser({ ...userData, id: firebaseUser.uid, email: firebaseUser.email || '' });
            } else if (isAdminEmail) {
              // Auto-create admin doc if missing
              await setDoc(doc(db, 'users', firebaseUser.uid), {
                name: firebaseUser.displayName || 'Admin',
                email: firebaseUser.email || '',
                role: 'admin',
                created_at: new Date().toISOString()
              });
            } else {
              setUser(null);
            }
          } catch (error) {
            console.error("Auth context fetch error:", error);
            // Detect if offline to avoid infinite loading
            if (error instanceof Error && error.message.includes('offline')) {
              window.dispatchEvent(new CustomEvent('firebase-offline', { detail: "Authentication failed because the database is offline." }));
            }
            // If we are an admin email, keep the user state set above
            if (!isAdminEmail) {
              setUser(null);
              setToken(null);
            }
          }
        } catch (error) {
          console.error("Outer auth context error:", error);
          setUser(null);
          setToken(null);
        }
      } else {
        setUser(null);
        setToken(null);
      }
      setLoading(false);
    });

    // Periodic refresh to catch admin updates
    const interval = setInterval(async () => {
      if (auth.currentUser) {
        try {
          const userDoc = await getDoc(doc(db, 'users', auth.currentUser.uid));
          if (userDoc.exists()) {
            const userData = userDoc.data() as User;
            setUser(prev => prev ? ({ ...prev, ...userData, id: auth.currentUser!.uid, email: auth.currentUser!.email || '' }) : null);
          }
        } catch (e) {
          console.error('Failed to periodic refresh user:', e);
        }
      }
    }, 30000); // Every 30 seconds

    // Periodically fetch fresh token
    const tokenRefreshInterval = setInterval(async () => {
      if (auth.currentUser) {
        try {
          const newToken = await auth.currentUser.getIdToken(true);
          setToken(newToken);
        } catch (e) {
          console.error('Failed to refresh token:', e);
        }
      }
    }, 10 * 60 * 1000); // Every 10 minutes

    return () => {
      unsubscribe();
      clearInterval(interval);
      clearInterval(tokenRefreshInterval);
    };
  }, []);

  const login = (newToken: string, newUser: User) => {
    setToken(newToken);
    setUser(newUser);
  };

  const refreshUser = async () => {
    if (!auth.currentUser) return;
    try {
      const userDoc = await getDoc(doc(db, 'users', auth.currentUser.uid));
      if (userDoc.exists()) {
        const userData = userDoc.data() as User;
        setUser({ ...userData, id: auth.currentUser.uid, email: auth.currentUser.email || '' });
      }
    } catch (error) {
      console.error("Error refreshing user data:", error);
    }
  };

  const logout = async () => {
    try {
      await signOut(auth);
      setToken(null);
      setUser(null);
      window.location.replace('/');
    } catch (error) {
      console.error("Logout error:", error);
    }
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      token, 
      login, 
      refreshUser,
      logout, 
      isAuthenticated: !!user && !!token, 
      loading 
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
