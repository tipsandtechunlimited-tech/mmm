import admin from "firebase-admin";
import { getFirestore } from "firebase-admin/firestore";
import fs from "fs";

const firebaseConfig = JSON.parse(fs.readFileSync("firebase-applet-config.json", "utf-8"));
admin.initializeApp({
  credential: admin.credential.applicationDefault(),
  projectId: firebaseConfig.projectId
});

const db = getFirestore(admin.app()); // DEFAULT DATABASE
async function run() {
  try {
    const list = await db.listCollections();
    console.log("SUCCESS ADMIN DEFAULT", list.map(c => c.id));
  } catch (e) {
    console.log("FAIL ADMIN DEFAULT", e.message);
  }
}
run();
