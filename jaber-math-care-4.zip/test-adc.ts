import admin from "firebase-admin";

async function run() {
  try {
    const cred = admin.credential.applicationDefault();
    const token = await cred.getAccessToken();
    console.log("ADC Token:", token.access_token ? "Exists" : "No token");
  } catch (e) {
    console.log("ADC fail:", e.message);
  }
}
run();
