import admin from "firebase-admin";
import { getFirestore } from "firebase-admin/firestore";
import fs from "fs";

const firebaseConfig = JSON.parse(fs.readFileSync("firebase-applet-config.json", "utf-8"));
admin.initializeApp({
  projectId: firebaseConfig.projectId
});

const dbId = firebaseConfig.firestoreDatabaseId !== "(default)" ? firebaseConfig.firestoreDatabaseId : undefined;
const db = getFirestore(admin.app(), dbId);

async function run() {
  try {
    await db.collection("settings").doc("test").set({ hello: "world" });
    console.log("SUCCESS ADMIN");
  } catch (e) {
    console.log("FAIL ADMIN", e.message);
  }
}
run();
