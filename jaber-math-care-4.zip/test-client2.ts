import { initializeApp } from "firebase/app";
import { getFirestore, doc, getDoc } from "firebase/firestore";
import fs from "fs";

const firebaseConfig = JSON.parse(fs.readFileSync("firebase-applet-config.json", "utf-8"));
const app = initializeApp(firebaseConfig);
const dbId = firebaseConfig.firestoreDatabaseId !== "(default)" ? firebaseConfig.firestoreDatabaseId : undefined;
const db = getFirestore(app, dbId as any);

async function run() {
  try {
    const d = await getDoc(doc(db, "programs", "123"));
    console.log("SUCCESS CLIENT", d.exists());
    process.exit(0);
  } catch (e) {
    console.log("FAIL CLIENT", e.message);
  }
}
run();
