import { initializeApp } from "firebase/app";
import { getFirestore, doc, setDoc } from "firebase/firestore";
import fs from "fs";

const firebaseConfig = JSON.parse(fs.readFileSync("firebase-applet-config.json", "utf-8"));
const app = initializeApp(firebaseConfig);
const dbId = firebaseConfig.firestoreDatabaseId !== "(default)" ? firebaseConfig.firestoreDatabaseId : undefined;
const db = getFirestore(app, dbId as any);

async function run() {
  try {
    await setDoc(doc(db, "test", "connection2"), { hello: "world" });
    console.log("SUCCESS CLIENT");
  } catch (e) {
    console.log("FAIL CLIENT", e.message);
  }
}
run();
