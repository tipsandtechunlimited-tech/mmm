const fs = require('fs');
let code = fs.readFileSync('src/pages/Login.tsx', 'utf8');

if (code.includes('setForgotEmail(email);')) {
  code = code.replace('setForgotEmail(email);', 'setForgotEmail(data.email || email);');
  fs.writeFileSync('src/pages/Login.tsx', code);
  console.log("Updated Login.tsx");
} else if (code.includes('setForgotEmail(identifier);')) {
  code = code.replace('setForgotEmail(identifier);', 'setForgotEmail(data.email || identifier);');
  fs.writeFileSync('src/pages/Login.tsx', code);
}
