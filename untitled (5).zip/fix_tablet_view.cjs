const fs = require('fs');

const path = 'src/pages/AdminDashboard.tsx';
let content = fs.readFileSync(path, 'utf8');

// Target these lines
const lines = content.split('\n');
const linesToUpdate = [7331, 7429, 7976, 8062, 9128, 9255, 10220, 10340, 12342, 12441, 13499, 13596];

for (let i = 0; i < lines.length; i++) {
    for (let targetLineNumber of linesToUpdate) {
        if (i + 1 === targetLineNumber) {
            lines[i] = lines[i].replace('hidden md:block', 'hidden lg:block');
            lines[i] = lines[i].replace('md:hidden', 'lg:hidden');
        }
    }
}
fs.writeFileSync(path, lines.join('\n'));
