const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const regex = /app\.post\("\/api\/forgot-password\/request"[\s\S]*?\/\/ Double check using admin auth to see if user exists in Authentication/;
const match = regex.exec(code);

if (match) {
  const replaceStr = `app.post("/api/forgot-password/request", async (req, res) => {
    try {
      let { identifier, email } = req.body;
      const targetQuery = identifier || email;
      if (!targetQuery) {
        return res.status(400).json({ error: "Please provide your email, phone, or roll number." });
      }

      const cleanQuery = targetQuery.toLowerCase().trim();
      const originalQuery = targetQuery.trim();

      // Check if user exists in Firestore
      let userDoc = null;
      
      if (originalQuery.includes("@")) {
        let usersSnap = await db.collection("users").where("email", "==", cleanQuery).get();
        if (!usersSnap.empty) {
          userDoc = usersSnap.docs[0];
        } else {
          usersSnap = await db.collection("users").where("email", "==", originalQuery).get();
          if (!usersSnap.empty) userDoc = usersSnap.docs[0];
        }
      } else {
        let usersSnap = await db.collection("users").where("roll_number", "==", originalQuery).get();
        if (usersSnap.empty && !isNaN(Number(originalQuery))) {
          usersSnap = await db.collection("users").where("roll_number", "==", Number(originalQuery)).get();
        }
        if (usersSnap.empty) {
          usersSnap = await db.collection("users").where("phone", "==", originalQuery).get();
        }
        if (!usersSnap.empty) userDoc = usersSnap.docs[0];
      }

      // Check if enrolled user
      if (!userDoc) {
        return res.status(404).json({ error: "No student account found. Please ensure you are enrolled." });
      }
      
      const userData = userDoc.data();
      const targetEmail = userData.email;
      
      // We found the user, now we proceed.
      // Double check using admin auth to see if user exists in Authentication`;

  const newCode = code.substring(0, match.index) + replaceStr + code.substring(match.index + match[0].length);
  // Need to replace the reference to `cleanEmail` down below with `targetEmail` but only in the `forgot-password/request` block.
  // Actually, we can just declare `const cleanEmail = targetEmail;` right after.
  
  const finalAdd = newCode.replace(/\/\/ We found the user, now we proceed\./, 
  `// We found the user, now we proceed.
      const cleanEmail = targetEmail;`);

  fs.writeFileSync('server.ts', finalAdd);
}
