const fs = require('fs');
let code = fs.readFileSync('src/pages/AdminDashboard.tsx', 'utf8');

const targetStr = `<select
                            className="glass-select h-[48px] w-auto text-sm"
                            value={studentStatusFilter}
                            onChange={(e) => setStudentStatusFilter(e.target.value)}
                          >
                            <option value="all">All Status</option>
                            <option value="approved">Approved</option>
                            <option value="pending">Pending</option>
                            <option value="upcoming">Upcoming</option>
                            <option value="passed">Passed</option>
                          </select>`;
const replacementStr = `{activeTab !== "online_students" && (<select
                            className="glass-select h-[48px] w-auto text-sm"
                            value={studentStatusFilter}
                            onChange={(e) => setStudentStatusFilter(e.target.value)}
                          >
                            <option value="all">All Status</option>
                            <option value="approved">Approved</option>
                            <option value="pending">Pending</option>
                            <option value="upcoming">Upcoming</option>
                            <option value="passed">Passed</option>
                          </select>)}`;
                          
if(code.includes(targetStr)) {
  code = code.replace(targetStr, replacementStr);
  fs.writeFileSync('src/pages/AdminDashboard.tsx', code);
  console.log("Updated activeTab online_students");
} else {
  console.log("Not found");
}
