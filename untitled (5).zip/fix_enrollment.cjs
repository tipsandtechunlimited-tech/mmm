const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const targetStr = `      let uid = null;

      if (userEmail && password) {
        try {
          const userRecord = await admin.auth().createUser({
            email: userEmail,
            password: password,
            displayName: name,
          });
          uid = userRecord.uid;
        } catch (error: any) {
          const isAlreadyInUse =
            error.code === "auth/email-already-exists" ||
            error.code === "auth/email-already-in-use" ||
            String(error.message || "").includes("email-already-in-use") ||
            String(error.message || "").includes("email-already-exists") ||
            String(error.message || "").includes("already in use") ||
            String(error.message || "").includes("already exists");
          if (isAlreadyInUse) {
            try {
              const existingRecord =
                await admin.auth().getUserByEmail(userEmail);
              uid = existingRecord.uid;
            } catch (fallbackError) {
              return res
                .status(400)
                .json({
                  error:
                    "This email is already in use by another student account.",
                });
            }
          } else {
            return res.status(400).json({
              error:
                error.message ||
                "Failed to process enrollment with that email.",
            });
          }
        }
      }`;

const replacementStr = `      let uid = null;
      // We no longer create the auth user during enrollment submission.
      // It will be created ONLY when the admin approves the enrollment.`;

code = code.replace(targetStr, replacementStr);
fs.writeFileSync('server.ts', code);
