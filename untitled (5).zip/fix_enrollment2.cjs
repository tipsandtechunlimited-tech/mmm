const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const regex = /if \(userEmail && password\) \{[\s\S]*?\} catch \(authError: any\) \{[\s\S]*?\} else \{[\s\S]*?\}\s*\}\s*\}/;

const replacementStr = `if (userEmail && password) {
        // We no longer create the auth user or the \`users\` document immediately during enrollment submission.
        // It will be created ONLY when the admin approves the enrollment.
      }`;

if(code.match(regex)) {
  code = code.replace(regex, replacementStr);
  fs.writeFileSync('server.ts', code);
  console.log("Updated enrollment properly");
} else {
  console.log("Not matched");
}
