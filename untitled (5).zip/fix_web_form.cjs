const fs = require('fs');
let code = fs.readFileSync('src/pages/AdminDashboard.tsx', 'utf8');

const webFormRegex = /<form\s*onSubmit=\{handleAddWebRecordedClass\}[\s\S]*?<\/form>/;
const newWebForm = `<form
                    onSubmit={handleAddWebRecordedClass}
                    className="space-y-8 relative z-10"
                  >
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div className="space-y-3">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          Video Title
                        </label>
                        <input
                          type="text"
                          required
                          className="w-full pl-5 pr-5 py-4 border-2 border-slate-100 rounded-[20px] bg-white text-sm font-bold text-slate-800 focus:border-orange-500 focus:ring-4 focus:ring-orange-500/10 transition-all shadow-[0_8px_30px_rgb(0,0,0,0.04)] hover:border-slate-200"
                          placeholder="e.g. Higher Math - Limits"
                          value={newWebRecordedClass.title}
                          onChange={(e) =>
                            setNewWebRecordedClass({
                              ...newWebRecordedClass,
                              title: e.target.value,
                            })
                          }
                        />
                      </div>
                      <div className="space-y-3">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          YouTube Embedded URL
                        </label>
                        <input
                          type="text"
                          required
                          className="w-full pl-5 pr-5 py-4 border-2 border-slate-100 rounded-[20px] bg-white text-sm font-bold text-slate-800 focus:border-orange-500 focus:ring-4 focus:ring-orange-500/10 transition-all shadow-[0_8px_30px_rgb(0,0,0,0.04)] hover:border-slate-200"
                          placeholder="https://www.youtube.com/embed/..."
                          value={newWebRecordedClass.url}
                          onChange={(e) =>
                            setNewWebRecordedClass({
                              ...newWebRecordedClass,
                              url: e.target.value,
                            })
                          }
                        />
                      </div>
                      <div className="space-y-3">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          Playlist
                        </label>
                        <input
                          type="text"
                          className="w-full pl-5 pr-5 py-4 border-2 border-slate-100 rounded-[20px] bg-white text-sm font-bold text-slate-800 focus:border-orange-500 focus:ring-4 focus:ring-orange-500/10 transition-all shadow-[0_8px_30px_rgb(0,0,0,0.04)] hover:border-slate-200"
                          placeholder="e.g. HSC 24 Final Review"
                          value={newWebRecordedClass.playlist || ""}
                          onChange={(e) =>
                            setNewWebRecordedClass({
                              ...newWebRecordedClass,
                              playlist: e.target.value,
                            })
                          }
                        />
                      </div>
                    </div>
                    <div className="flex gap-4">
                      <button
                        type="button"
                        onClick={() =>
                          setNewWebRecordedClass({
                            title: "",
                            url: "",
                            description: "",
                            playlist: ""
                          })
                        }
                        className="px-8 py-4 border-2 border-slate-200 text-slate-500 hover:text-slate-800 hover:bg-slate-50 font-black rounded-[20px] transition-all text-xs tracking-widest uppercase"
                      >
                        Clear
                      </button>
                      <button
                        type="submit"
                        className="flex-1 bg-gradient-to-r from-orange-500 to-rose-500 hover:from-orange-600 hover:to-rose-600 text-white font-black py-4 px-8 rounded-[20px] transition-all transform hover:scale-[1.02] shadow-[0_10px_40px_rgba(249,115,22,0.3)] text-sm uppercase tracking-widest flex items-center justify-center gap-3"
                      >
                        <Plus className="h-5 w-5" />
                        Add Web Recorded Class
                      </button>
                    </div>
                  </form>`;

code = code.replace(webFormRegex, newWebForm);
fs.writeFileSync('src/pages/AdminDashboard.tsx', code);
