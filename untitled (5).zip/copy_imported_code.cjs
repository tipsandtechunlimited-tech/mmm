const fs = require('fs');
const path = require('path');

function copyDirStructure(src, dest) {
  if (!fs.existsSync(dest)) fs.mkdirSync(dest, { recursive: true });
  const entries = fs.readdirSync(src, { withFileTypes: true });
  for (let entry of entries) {
    const srcPath = path.join(src, entry.name);
    const destPath = path.join(dest, entry.name);
    if (entry.isDirectory()) {
      copyDirStructure(srcPath, destPath);
    } else {
      fs.copyFileSync(srcPath, destPath);
    }
  }
}

// Copy everything from temp_git_import/extracted to /
const source = 'temp_git_import/extracted';
const target = '.';

const itemsToCopy = ['src', 'public', 'server.ts', 'package.json', 'firestore.rules', 'firebase.json'];

for (let item of itemsToCopy) {
  const srcItem = path.join(source, item);
  const destItem = path.join(target, item);
  
  if (fs.existsSync(srcItem)) {
    const stat = fs.statSync(srcItem);
    if (stat.isDirectory()) {
      // Clear dest directory first
      if (fs.existsSync(destItem)) {
        fs.rmSync(destItem, { recursive: true, force: true });
      }
      copyDirStructure(srcItem, destItem);
      console.log(`Copied directory ${item}`);
    } else {
      fs.copyFileSync(srcItem, destItem);
      console.log(`Copied file ${item}`);
    }
  }
}
