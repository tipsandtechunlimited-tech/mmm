const fs = require('fs');
fs.copyFileSync('temp_git_import/extracted/src/pages/Programs.tsx', 'src/pages/Programs.tsx');
