const fs = require('fs');

// 1. Fix Programs.tsx
let progPath = 'src/pages/Programs.tsx';
if (fs.existsSync(progPath)) {
  let progContent = fs.readFileSync(progPath, 'utf8');
  
  // The Leka section starts with:
  // {/* Leka (Details) Section */}
  // <div className="space-y-6">
  //
  // And the image section:
  // {/* Program Image section moved above enroll button per user request */}
  // <div className="h-64 md:h-72 bg-slate-100 relative overflow-hidden rounded-3xl mx-[-1rem] md:mx-0 shadow-inner">
  
  const lekaStartStr = `{/* Leka (Details) Section */}`;
  const imageStrRegex = /\{\/\* Program Image section moved above enroll button per user request \*\/\}[\s\S]*?<\/div>\s*\}\)\s*<\/div>\s*<\/div>/m;
  
  // A safer manual swap logic:
  // Let's find the image block exactly.
  const lines = progContent.split('\n');
  let lekaIdx = -1;
  let imageStartIdx = -1;
  let imageEndIdx = -1;
  let imageDivLevels = 0;
  
  for(let i=0; i<lines.length; i++) {
    if(lines[i].includes('{/* Leka (Details) Section */}')) {
      lekaIdx = i;
    }
    if(lines[i].includes('{/* Program Image section moved above enroll button per user request */}')) {
      imageStartIdx = i;
      imageDivLevels = 0;
      // parse until div matched
    }
    if (imageStartIdx !== -1 && imageEndIdx === -1) {
      if (lines[i].includes('<div')) imageDivLevels += (lines[i].match(/<div/g) || []).length;
      if (lines[i].includes('</div')) imageDivLevels -= (lines[i].match(/<\/div/g) || []).length;
      
      if (i > imageStartIdx && imageDivLevels <= 0 && lines[i].includes('</div>')) {
         imageEndIdx = i;
      }
    }
  }

  if (lekaIdx !== -1 && imageStartIdx !== -1 && imageEndIdx !== -1) {
    const imageBlock = lines.splice(imageStartIdx, imageEndIdx - imageStartIdx + 1);
    
    // Recalculate lekaIdx after splicing if it was after
    let newLekaIdx = lines.findIndex(l => l.includes('{/* Leka (Details) Section */}'));
    
    // Insert image block just before the div containing Leka section, or right at the top of the card
    // The card content starts at: 
    // className="p-8 md:p-12 space-y-8 flex-1 flex flex-col justify-between">
    let insertIdx = newLekaIdx;
    while(insertIdx > 0 && !lines[insertIdx-1].includes('className="p-8 md:p-12 space-y-8 flex-1 flex flex-col justify-between"')) {
        insertIdx--;
    }
    lines.splice(insertIdx, 0, ...imageBlock);
    fs.writeFileSync(progPath, lines.join('\n'));
    console.log('Programs.tsx image block moved.');
  } else {
    console.log('Could not parse Programs.tsx structure');
  }
}

// 2. Fix AdminDashboard.tsx responsive classes
let adminPath = 'src/pages/AdminDashboard.tsx';
if (fs.existsSync(adminPath)) {
  let adminContent = fs.readFileSync(adminPath, 'utf8');
  
  // Desktop table view hiding classes -> hidden lg:block
  adminContent = adminContent.replace(/hidden xl:block/g, 'hidden lg:block');
  adminContent = adminContent.replace(/hidden md:block/g, 'hidden lg:block');
  
  // Mobile card view hiding classes -> lg:hidden
  // Need to be careful with md:grid-cols-2, we shouldn't replace md: with lg: blindly
  adminContent = adminContent.replace(/xl:hidden/g, 'lg:hidden');
  adminContent = adminContent.replace(/block md:hidden/g, 'block lg:hidden');
  adminContent = adminContent.replace(/md:hidden space-y-4/g, 'lg:hidden space-y-4');
  adminContent = adminContent.replace(/md:hidden divide-y/g, 'lg:hidden divide-y');
  adminContent = adminContent.replace(/md:hidden grid/g, 'lg:hidden grid');
  
  fs.writeFileSync(adminPath, adminContent);
  console.log('AdminDashboard.tsx responsive fixed for Tablets.');
}
