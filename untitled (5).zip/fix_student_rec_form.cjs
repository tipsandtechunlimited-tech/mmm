const fs = require('fs');
let code = fs.readFileSync('src/pages/AdminDashboard.tsx', 'utf8');

const regex = /<form\s*onSubmit=\{handleAddVideoClass\}[\s\S]*?<\/form>/;
const match = code.match(regex);
if(match) {
  let formStr = match[0];
  // add playlist field alongside title/video URL if not present.
  if(!formStr.includes('value={newVideoClass.playlist}')) {
    formStr = formStr.replace(/(<label className="text-\[10px\] font-black text-slate-400 uppercase tracking-widest ml-1">\s*YouTube Video ID\s*<\/label>[\s\S]*?<\/div>)/, 
      `$1\n<div className="space-y-3">
                              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                                Playlist
                              </label>
                              <input
                                type="text"
                                placeholder="e.g. Physics Chapter 3"
                                className="glass-input w-full border-2 border-orange-100 focus:border-orange-500"
                                value={newVideoClass.playlist || ""}
                                onChange={(e) =>
                                  setNewVideoClass({
                                    ...newVideoClass,
                                    playlist: e.target.value,
                                  })
                                }
                              />
                            </div>`);
    code = code.replace(regex, formStr);
    fs.writeFileSync('src/pages/AdminDashboard.tsx', code);
    console.log("Updated student recorded classes form");
  }

}
