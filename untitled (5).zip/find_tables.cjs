const fs = require('fs');
const content = fs.readFileSync('src/pages/AdminDashboard.tsx', 'utf8');

const regex = /<table/gi;
let match;
const lines = content.split('\n');

while ((match = regex.exec(content)) !== null) {
    const lineNumber = content.substring(0, match.index).split('\n').length;
    console.log(`Table found at line: ${lineNumber}`);
    for(let i = Math.max(0, lineNumber - 5); i < Math.min(lines.length, lineNumber + 2); i++) {
        console.log(`  ${i+1}: ${lines[i]}`);
    }
    console.log('---');
}

