import React from 'react';
import { useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import NotFound from '../pages/NotFound';

interface ProtectedRouteProps {
  children: React.ReactNode;
  role?: string | string[];
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children, role }) => {
  const { user, isAuthenticated, loading } = useAuth();
  const location = useLocation();

  // If we are loading but already have a user from localStorage, 
  // we can skip the loading screen to prevent layout jumps.
  if (loading && !user) {
    return null;
  }

  if (!isAuthenticated && !loading) {
    return (
      <NotFound 
        title="Authentication Required" 
        subtitle="401" 
      />
    );
  }

  if (role) {
    const roles = Array.isArray(role) ? role : [role];
    if (!roles.includes(user?.role as any)) {
      return (
        <NotFound 
          title="Access Restricted" 
          subtitle="403" 
        />
      );
    }
  }

  return <>{children}</>;
};

export default ProtectedRoute;
