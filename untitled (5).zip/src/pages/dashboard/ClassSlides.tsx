import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Image as ImageIcon, X, ChevronLeft, ChevronRight, Download } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { db } from '../../firebase';
import { collection, onSnapshot, query, where, doc, getDoc } from 'firebase/firestore';

import LoadingSpinner from '../../components/LoadingSpinner';

const ClassSlides = () => {
  const { token, user: authUser } = useAuth();
  const [slides, setSlides] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedSlideIndex, setSelectedSlideIndex] = useState<number | null>(null);

  useEffect(() => {
    if (!token || !authUser) return;

    const unsubscribes: (() => void)[] = [];

    // Listen to user profile
    const userRef = doc(db, 'users', authUser.id);
    const unsubUser = onSnapshot(userRef, async (userDoc) => {
      if (userDoc.exists()) {
        const userData = userDoc.data();
        
        // Listen to enrollments
        fetch(`/api/my-enrollments?t=${Date.now()}`, {
          headers: { Authorization: `Bearer ${token}` }
        })
          .then(res => res.json())
          .then(enrollData => {
            if (enrollData.error) return;
            const activeEnrollments = (Array.isArray(enrollData) ? enrollData : []).filter((e: any) => e.status === 'contacted' || e.status === 'approved');
            const userEnrolledCourseIds = userData?.enrolled_courses?.map((c: any) => typeof c === 'string' ? c : c.id) || [];

            // Listen to class slides
            const unsubSlides = onSnapshot(collection(db, 'class_slides'), (slidesSnapshot) => {
              const slidesData = slidesSnapshot.docs.map(d => ({ ...d.data(), id: d.id }));
              
              const filteredSlides = (Array.isArray(slidesData) ? slidesData : []).filter((slide: any) => {
                const cid = slide.course_id && String(slide.course_id).toLowerCase() !== 'all' ? slide.course_id : null;
                const pid = slide.program_id && String(slide.program_id).toLowerCase() !== 'all' ? slide.program_id : null;
                const bid = slide.batch_id && String(slide.batch_id).toLowerCase() !== 'all' ? slide.batch_id : null;
                
                if (!cid && !pid && !bid) return true;

                if (cid) {
                  const isEnrolledInCourse = (userData?.course_id && String(userData.course_id) === String(cid)) ||
                                             userEnrolledCourseIds.some((cId: any) => String(cId) === String(cid)) ||
                                             activeEnrollments.some((e: any) => String(e.course_id) === String(cid));
                  return isEnrolledInCourse;
                }

                if (pid) {
                  const isOfflineAndEligible = userData?.student_type !== 'online' && (
                    (userData?.program_id && String(userData.program_id) === String(pid)) ||
                    (userData?.batch_id && String(userData.batch_id) === String(bid)) ||
                    (userData?.batch_id_2 && String(userData.batch_id_2) === String(bid))
                  );
                  const isEnrolledInProgram = (userData?.program_id && String(userData.program_id) === String(pid)) ||
                                              activeEnrollments.some((e: any) => String(e.program_id) === String(pid)) || isOfflineAndEligible;
                  if (!isEnrolledInProgram) return false;
                  
                  if (bid) {
                    const isEnrolledInBatch = (userData?.batch_id && String(userData.batch_id) === String(bid)) || 
                                              (userData?.batch_id_2 && String(userData.batch_id_2) === String(bid)) ||
                                              activeEnrollments.some((e: any) => String(e.batch_id) === String(bid)) || isOfflineAndEligible;
                    return isEnrolledInBatch;
                  }
                  return true;
                }

                return false;
              });

              setSlides(filteredSlides);
              setLoading(false);
            });
            unsubscribes.push(unsubSlides);
          }).catch(console.error);
      }
    });
    unsubscribes.push(unsubUser);

    return () => unsubscribes.forEach(unsub => unsub());
  }, [token, authUser]);

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="space-y-8 pb-20">
      <h1 className="text-3xl font-black text-slate-900 tracking-tight flex items-center gap-3">
        <ImageIcon className="h-8 w-8 text-orange-600" />
        <span className="text-orange-600">Jaber Math Care</span> Class Slides
      </h1>

      {slides.length === 0 ? (
        <div className="text-center py-20 glass rounded-[3rem] border-dashed border-2 border-slate-200">
          <ImageIcon className="h-16 w-16 mx-auto text-slate-300 mb-4" />
          <p className="text-xl text-slate-500 font-bold">No slides available yet.</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {slides.map((slide, index) => (
            <motion.div
              key={slide.id}
              initial={{ opacity: 0, y: 15, scale: 0.95, rotate: -2 }}
              animate={{ opacity: 1, y: 0, scale: 1, rotate: 0 }}
              whileHover={{ scale: 1.05, y: -5, rotate: 2, boxShadow: "0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)" }}
              transition={{ duration: 0.3, delay: index * 0.05 }}
              onClick={() => setSelectedSlideIndex(index)}
              className="aspect-video rounded-2xl overflow-hidden shadow-lg cursor-pointer border border-slate-200"
            >
              <img src={slide.image_url} alt={slide.caption || 'Slide'} referrerPolicy="no-referrer" className="w-full h-full object-cover" />
            </motion.div>
          ))}
        </div>
      )}

      {/* Slide Viewer Modal */}
      <AnimatePresence>
        {selectedSlideIndex !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-xl"
            onClick={() => setSelectedSlideIndex(null)}
          >
            <button 
              onClick={() => setSelectedSlideIndex(null)}
              className="absolute top-6 right-6 text-white p-3 rounded-full bg-white/10 hover:bg-white/20"
            >
              <X className="h-8 w-8" />
            </button>
            
            <button 
              onClick={(e) => { e.stopPropagation(); setSelectedSlideIndex(prev => prev! > 0 ? prev! - 1 : slides.length - 1); }}
              className="absolute left-6 text-white p-3 rounded-full bg-white/10 hover:bg-white/20"
            >
              <ChevronLeft className="h-8 w-8" />
            </button>
            
            <button 
              onClick={(e) => { e.stopPropagation(); setSelectedSlideIndex(prev => prev! < slides.length - 1 ? prev! + 1 : 0); }}
              className="absolute right-6 text-white p-3 rounded-full bg-white/10 hover:bg-white/20"
            >
              <ChevronRight className="h-8 w-8" />
            </button>

            <div className="relative" onClick={(e) => e.stopPropagation()}>
              <img 
                src={slides[selectedSlideIndex].image_url} 
                alt="Slide" 
                referrerPolicy="no-referrer"
                className="max-w-full max-h-[80vh] rounded-2xl shadow-2xl"
              />
              <a 
                href={slides[selectedSlideIndex].image_url} 
                download 
                target="_blank" 
                rel="noopener noreferrer" 
                className="absolute bottom-4 right-4 p-3 bg-orange-600 text-white rounded-xl hover:bg-orange-700 transition-colors shadow-lg flex items-center gap-2 font-bold"
              >
                <Download className="h-5 w-5" /> Download
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default ClassSlides;
