import { useRealtimeCollection } from '../hooks/useRealtime';
import { orderBy } from 'firebase/firestore';
import React, { useState, useMemo } from 'react';
import { createPortal } from 'react-dom';
import { useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { BookOpen, Clock, Users, Check, X, Send, CheckCircle2, Calendar, UserPlus } from 'lucide-react';
import { showAlert } from '../utils/alert';
import { DebouncedInput } from '../components/DebouncedInput';
import { useSettings } from '../context/SettingsContext';

const Programs = () => {
  const location = useLocation();
  const isDashboard = location.pathname.startsWith('/dashboard');

  const { data: programs, loading: programsLoading } = useRealtimeCollection('programs', [
    orderBy('created_at', 'desc')
  ]);
  const { data: batches } = useRealtimeCollection('batches');
  const { settings } = useSettings();

  const loading = programsLoading;
  const [selectedProgram, setSelectedProgram] = useState<any>(null);
  const [selectedProgramIdForDesc, setSelectedProgramIdForDesc] = useState<string[]>([]);
  const [isEnrolling, setIsEnrolling] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    phone: '',
    guardian_phone: '',
    admission_month: '',
    current_class: '',
    school_name: '',
    college_name: '',
    batch_id: '',
    blood_group: '',
    address: '',
    profile_pic: ''
  });

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 500000) { // 500KB limit
        showAlert('Image size should be less than 500KB');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData({ ...formData, profile_pic: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  React.useEffect(() => {
    if (selectedProgram) {
      const scrollbarWidth = window.innerWidth - document.documentElement.clientWidth;
      document.body.style.paddingRight = `${scrollbarWidth}px`;
      document.body.style.overflow = 'hidden';
      
      // Auto-set class if target_audience exists
      if (selectedProgram.target_audience) {
        setFormData(prev => ({ ...prev, current_class: selectedProgram.target_audience }));
      }

      // Default admission month to current month
      const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
      const currentMonth = months[new Date().getMonth()];
      setFormData(prev => ({ ...prev, admission_month: currentMonth }));
    } else {
      document.body.style.overflow = 'unset';
      document.body.style.paddingRight = '0px';
    }
    return () => {
      document.body.style.overflow = 'unset';
      document.body.style.paddingRight = '0px';
    };
  }, [selectedProgram]);

  const handleEnroll = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (formData.password !== formData.confirmPassword) {
      showAlert('Passwords do not match');
      return;
    }

    if (!formData.batch_id) {
      showAlert('Please select a batch');
      return;
    }

    setIsEnrolling(true);
    try {
      const formattedPhone = formData.phone ? (formData.phone.startsWith("+880") ? formData.phone : `+880${formData.phone.replace(/^0+/, '')}`) : '';

      const res = await fetch('/api/enrollments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          phone: formattedPhone,
          program_id: selectedProgram.id,
          program_title: selectedProgram.title,
          admission_fee: selectedProgram.admission_fee || 0,
          monthly_fee: selectedProgram.monthly_fee || 0,
          fee: selectedProgram.admission_fee || 0 // Use admission fee as initial fee
        })
      });
      if (res.ok) {
        setIsSuccess(true);
        setTimeout(() => {
          setIsSuccess(false);
          setSelectedProgram(null);
          setFormData({ name: '', email: '', password: '', confirmPassword: '', phone: '', guardian_phone: '', admission_month: '', current_class: '', school_name: '', college_name: '', batch_id: '', blood_group: '', address: '', profile_pic: '' });
        }, 3000);
      } else {
        const err = await res.json();
        showAlert(err.error || 'Failed to submit enrollment. Please try again.');
      }
    } catch (error) {
      console.error(error);
      showAlert('An error occurred. Please try again.');
    } finally {
      setIsEnrolling(false);
    }
  };

  return (
    <div className={`min-h-screen ${isDashboard ? 'pt-0' : 'pt-8 md:pt-12 lg:pt-16'} pb-20 px-4 sm:px-6 lg:px-8 bg-slate-50`}>
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-10"
        >
          <h1 className="section-title">
            Our Program
          </h1>
          <p className="section-subtitle">
            Choose the perfect course to accelerate your math journey. Designed for excellence.
          </p>
        </motion.div>

        <div className="space-y-20">
          {/* Group programs by target audience (e.g., HSC 26) */}
          {Array.from(new Set(programs.map(p => p.target_audience || p.class || 'Other'))).map((category) => (
            <div key={category as string} className="space-y-8">
              <div className="flex items-center gap-4">
                <div className="w-1.5 h-10 bg-orange-600 rounded-full" />
                <h2 className="text-3xl font-bold text-orange-600">{category || 'General Programs'}</h2>
              </div>

              <div className="grid grid-cols-1 gap-12">
                {programs.filter(p => (p.target_audience || p.class || 'Other') === category).map((course, index) => (
                  <motion.div
                    key={course.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="bg-white rounded-[2rem] shadow-2xl overflow-hidden border border-slate-100 transition-all duration-500 hover:translate-y-[-6px] flex flex-col hover:shadow-orange-500/10"
                  >
                    {/* Header Band exactly like the user's screenshot layout but styled beautifully with brand orange */}
                    <div className="h-24 bg-gradient-to-r from-orange-600 to-orange-500 relative overflow-hidden px-8 md:px-12 flex items-center justify-between rounded-t-[2rem]">
                      {/* Translucent circle decoration on the upper right side to match the image precisely */}
                      <div className="absolute top-[-25px] right-[-25px] w-28 h-28 bg-white/10 rounded-full z-0 pointer-events-none" />
                      
                      <h3 className="text-white text-2xl md:text-3xl font-black tracking-tight relative z-10 leading-none">
                        {course.title || 'HSC 26'}
                      </h3>
                    </div>

                    <div className="p-8 md:p-12 space-y-6 flex-1 flex flex-col justify-between">
                      {/* Details Section */}
                      <div className="space-y-6">
                        <div>
                          <p className="text-slate-400 text-xs font-black uppercase tracking-widest mb-1">{course.target_audience || 'HSC 26'} MATH</p>
                          
                          {course.description && (
                            <div className="relative mt-2">
                              <div className={`text-slate-600 leading-relaxed text-sm ${!selectedProgramIdForDesc.includes(course.id) ? 'line-clamp-2' : ''}`}>
                                {course.description}
                              </div>
                              {course.description.length > 120 && (
                                <button 
                                  onClick={() => {
                                    if (selectedProgramIdForDesc.includes(course.id)) {
                                      setSelectedProgramIdForDesc(selectedProgramIdForDesc.filter(id => id !== course.id));
                                    } else {
                                      setSelectedProgramIdForDesc([...selectedProgramIdForDesc, course.id]);
                                    }
                                  }}
                                  className="text-orange-600 text-[10px] font-black uppercase tracking-widest hover:underline mt-1.5 block"
                                >
                                  {selectedProgramIdForDesc.includes(course.id) ? 'Show Less' : 'See More'}
                                </button>
                              )}
                            </div>
                          )}
                        </div>

                        {/* Fee Section - Styled exactly like the user's uploaded image */}
                        <div className="bg-slate-50/65 rounded-3xl p-6 md:p-8 space-y-4 border border-slate-100/90 shadow-inner">
                          <div className="flex items-center gap-4">
                            <div className="bg-orange-600/10 p-3 rounded-xl text-orange-600">
                              <BookOpen className="h-5 w-5" />
                            </div>
                            <div className="flex-1 flex justify-between items-center">
                              <span className="text-slate-500 font-bold text-sm">Admission Fee:</span>
                              <span className="text-orange-600 font-black text-base md:text-lg">৳{course.admission_fee || 0}</span>
                            </div>
                          </div>
                          <div className="flex items-center gap-4">
                            <div className="bg-orange-600/10 p-3 rounded-xl text-orange-600">
                              <Calendar className="h-5 w-5" />
                            </div>
                            <div className="flex-1 flex justify-between items-center">
                              <span className="text-slate-500 font-bold text-sm">Monthly Fee:</span>
                              <span className="text-orange-600 font-black text-base md:text-lg">৳{course.monthly_fee || 0}</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Footer Section - Action Button is pushed down nicely */}
                      <div className="flex flex-col sm:flex-row items-center justify-between gap-6 pt-6 border-t border-slate-100">
                        <div className="text-center sm:text-left shrink-0">
                          <span className="text-2.5xl md:text-3xl font-black text-orange-600">৳{course.admission_fee || 0}</span>
                          <span className="text-xs text-slate-400 block font-bold uppercase tracking-widest mt-1">Admission Fee</span>
                        </div>
                        
                        {settings.admission_open === "true" ? (
                          <motion.button 
                            whileHover={{ scale: 1.03 }}
                            whileTap={{ scale: 0.97 }}
                            onClick={() => setSelectedProgram(course)}
                            className="w-full sm:w-auto bg-gradient-to-r from-orange-600 to-orange-500 text-white py-3.5 px-8 rounded-2xl font-black text-sm md:text-base shadow-xl shadow-orange-600/15 hover:shadow-orange-600/30 transition-all flex items-center justify-center gap-2.5 group"
                          >
                            <UserPlus className="h-5 w-5 group-hover:scale-110 transition-transform" />
                            Enroll Now
                          </motion.button>
                        ) : (
                          <div className="w-full sm:w-auto bg-slate-100 text-slate-400 py-3.5 px-8 rounded-2xl font-bold text-sm text-center flex items-center justify-center gap-2.5">
                            Admission Closed
                          </div>
                        )}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Enrollment Modal */}
      {createPortal(
        <AnimatePresence>
          {selectedProgram && (
            <div 
              className="fixed inset-0 z-[100000] flex items-center justify-center p-4 bg-slate-950/40 backdrop-blur-[3px] overflow-y-auto scrollbar-hide"
              onClick={() => setSelectedProgram(null)}
            >
              <motion.div
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 20 }}
                className="bg-white w-full max-w-xl rounded-2xl md:rounded-[2.5rem] shadow-2xl overflow-hidden max-h-[95vh] sm:max-h-[85vh] flex flex-col"
                onClick={(e) => e.stopPropagation()}
              >
                {isSuccess ? (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="p-12 text-center space-y-6"
                  >
                    <motion.div 
                      initial={{ scale: 0, rotate: -180 }}
                      animate={{ scale: 1, rotate: 0 }}
                      transition={{ type: "spring", stiffness: 200, damping: 15, delay: 0.1 }}
                      className="w-24 h-24 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto"
                    >
                      <CheckCircle2 className="h-14 w-14" />
                    </motion.div>
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.3 }}
                    >
                      <h2 className="text-3xl font-bold text-slate-900 mb-2">Registration Successful!</h2>
                      <p className="text-slate-600 text-lg">We will contact you shortly for further details.</p>
                    </motion.div>
                  </motion.div>
                ) : (
                  <>
                    <div className="p-4 md:p-6 border-b border-slate-100 flex justify-between items-center bg-white/50 shrink-0">
                      <h2 className="text-xl font-bold text-slate-800">Enrollment Form</h2>
                      <button onClick={() => setSelectedProgram(null)} className="text-slate-400 hover:text-slate-600">
                        <X className="h-6 w-6" />
                      </button>
                    </div>
                    <form onSubmit={handleEnroll} className="p-5 md:p-6 space-y-4 overflow-y-auto scrollbar-hide flex-1">
                      <div>
                        <label className="block text-sm font-semibold text-slate-700 mb-1">Program</label>
                        <input 
                          type="text" 
                          value={selectedProgram.title} 
                          readOnly 
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-600 outline-none"
                        />
                      </div>
                      <div className="flex flex-col items-center mb-6">
                        <motion.div 
                          whileHover={{ scale: 1.05 }}
                          className="w-24 h-24 bg-slate-100 rounded-full overflow-hidden mb-3 border-4 border-white shadow-xl relative group"
                        >
                          {formData.profile_pic ? (
                            <img 
                              src={formData.profile_pic} 
                              alt="Profile" 
                              className="w-full h-full object-cover" 
                              referrerPolicy="no-referrer"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-slate-300">
                              <Users className="h-10 w-10" />
                            </div>
                          )}
                          <label className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer">
                            <span className="text-white text-[10px] font-bold uppercase">Change</span>
                            <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
                          </label>
                        </motion.div>
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Profile Picture</p>
                      </div>
                      <div>
                        <label className="block text-sm font-semibold text-slate-700 mb-1">Full Name</label>
                        <DebouncedInput 
                          type="text" 
                          required
                          placeholder="Enter your full name"
                          className="glass-input"
                          value={formData.name}
                          onChange={(val: string) => setFormData({...formData, name: val})}
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-semibold text-slate-700 mb-1">Email Address (Gmail Preferred)</label>
                        <DebouncedInput 
                          type="email" 
                          required
                          placeholder="yourname@gmail.com"
                          className="glass-input"
                          value={formData.email}
                          onChange={(val: string) => setFormData({...formData, email: val})}
                        />
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-semibold text-slate-700 mb-1">Set Password</label>
                          <DebouncedInput 
                            type="password" 
                            required
                            minLength={6}
                            placeholder="Min 6 characters"
                            className="glass-input"
                            value={formData.password}
                            onChange={(val: string) => setFormData({...formData, password: val})}
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-semibold text-slate-700 mb-1">Confirm Password</label>
                          <DebouncedInput 
                            type="password" 
                            required
                            minLength={6}
                            placeholder="Repeat password"
                            className="glass-input"
                            value={formData.confirmPassword}
                            onChange={(val: string) => setFormData({...formData, confirmPassword: val})}
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-semibold text-slate-700 mb-1">Mobile Number</label>
                          <div className="relative flex items-center">
                            <span className="absolute left-4 font-bold text-slate-500 z-10">+880</span>
                            <DebouncedInput 
                              type="tel" 
                              required
                              placeholder="1XXXXXXXX"
                              className="w-full bg-white/90 backdrop-blur-sm border border-slate-200 rounded-xl pl-[3.8rem] pr-4 py-3 text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-orange-500 focus:ring-4 focus:ring-orange-500/10 transition-all shadow-sm"
                              value={formData.phone.startsWith('+880') ? formData.phone.substring(4) : formData.phone.startsWith('880') ? formData.phone.substring(3) : formData.phone}
                              onChange={(val: string) => {
                                const numOnly = val.replace(/\D/g, '');
                                setFormData({...formData, phone: numOnly ? `+880${numOnly}` : ''});
                              }}
                            />
                          </div>
                        </div>
                        <div>
                          <label className="block text-sm font-semibold text-slate-700 mb-1">Guardian Phone</label>
                          <div className="relative flex items-center">
                            <span className="absolute left-4 font-bold text-slate-500 z-10">+880</span>
                            <DebouncedInput 
                              type="tel" 
                              required
                              placeholder="1XXXXXXXX"
                              className="w-full bg-white/90 backdrop-blur-sm border border-slate-200 rounded-xl pl-[3.8rem] pr-4 py-3 text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-orange-500 focus:ring-4 focus:ring-orange-500/10 transition-all shadow-sm"
                              value={formData.guardian_phone.startsWith('+880') ? formData.guardian_phone.substring(4) : formData.guardian_phone.startsWith('880') ? formData.guardian_phone.substring(3) : formData.guardian_phone}
                              onChange={(val: string) => {
                                const numOnly = val.replace(/\D/g, '');
                                setFormData({...formData, guardian_phone: numOnly ? `+880${numOnly}` : ''});
                              }}
                            />
                          </div>
                        </div>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-semibold text-slate-700 mb-1">Admission Month</label>
                          <select 
                            required
                            className="glass-select"
                            value={formData.admission_month}
                            onChange={(e) => setFormData({...formData, admission_month: e.target.value})}
                          >
                            <option value="">Select Month</option>
                            {['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'].map(m => (
                              <option key={m} value={m}>{m}</option>
                            ))}
                          </select>
                        </div>
                        <div>
                          <label className="block text-sm font-semibold text-slate-700 mb-1">Current Class</label>
                          <DebouncedInput 
                            type="text" 
                            required
                            placeholder="e.g. HSC 2025"
                            className="glass-input"
                            value={formData.current_class}
                            onChange={(val: string) => setFormData({...formData, current_class: val})}
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-semibold text-slate-700 mb-1">School Name</label>
                          <DebouncedInput 
                            type="text" 
                            placeholder="Your school"
                            className="glass-input"
                            value={formData.school_name}
                            onChange={(val: string) => setFormData({...formData, school_name: val})}
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-semibold text-slate-700 mb-1">College Name</label>
                          <DebouncedInput 
                            type="text" 
                            placeholder="Your college"
                            className="glass-input"
                            value={formData.college_name}
                            onChange={(val: string) => setFormData({...formData, college_name: val})}
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-semibold text-slate-700 mb-1">Blood Group</label>
                          <select 
                            className="glass-select"
                            value={formData.blood_group}
                            onChange={(e) => setFormData({...formData, blood_group: e.target.value})}
                          >
                            <option value="">Select Blood Group</option>
                            {['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map(bg => (
                              <option key={bg} value={bg}>{bg}</option>
                            ))}
                          </select>
                        </div>
                        <div>
                          <label className="block text-sm font-semibold text-slate-700 mb-1">Address</label>
                          <DebouncedInput 
                            type="text" 
                            required
                            placeholder="Town/City, District"
                            className="glass-input"
                            value={formData.address || ''}
                            onChange={(val: string) => setFormData({...formData, address: val})}
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-semibold text-slate-700 mb-1">Select Batch</label>
                          <select 
                            required
                            className="glass-select"
                            value={formData.batch_id}
                            onChange={(e) => setFormData({...formData, batch_id: e.target.value})}
                          >
                            <option value="">Select a batch...</option>
                            {batches.filter(b => String(b.program_id) === String(selectedProgram.id)).map(batch => (
                              <option key={batch.id} value={batch.id}>{batch.name} ({batch.batch_days || batch.days} - {batch.batch_time || batch.time})</option>
                            ))}
                          </select>
                        </div>
                      </div>
                      <div>
                        <label className="flex items-start gap-2 cursor-pointer">
                          <input type="checkbox" required className="mt-1 rounded text-orange-600 focus:ring-orange-500" />
                          <span className="text-sm text-slate-600">
                            I agree to the <a href="#" className="text-orange-600 hover:underline">Terms and Conditions</a>. After admin approval, I will be able to log in using the provided Gmail address.
                          </span>
                        </label>
                      </div>
                      <div className="pt-4 flex gap-3">
                        <motion.button 
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          type="button"
                          onClick={() => setSelectedProgram(null)}
                          className="flex-1 bg-slate-100 text-slate-600 font-bold py-3 rounded-xl hover:bg-slate-200 transition-colors"
                        >
                          Cancel
                        </motion.button>
                        <motion.button 
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          type="submit"
                          disabled={isEnrolling}
                          className="flex-1 bg-green-600 text-white font-bold py-3 rounded-xl hover:bg-green-700 transition-colors flex items-center justify-center gap-2"
                        >
                          {isEnrolling ? 'Submitting...' : <><Send className="h-4 w-4" /> Submit Application</>}
                        </motion.button>
                      </div>
                    </form>
                  </>
                )}
              </motion.div>
            </div>
          )}
        </AnimatePresence>,
        document.body
      )}
    </div>
  );
};

export default Programs;
