import { showAlert } from '../utils/alert';
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useSettings } from '../context/SettingsContext';
import { motion } from 'motion/react';
import { LogIn, User, Lock, Eye, EyeOff, Loader2, ArrowRight, Star, ArrowLeft, Mail, Key, CheckCircle } from 'lucide-react';
import { signInWithEmailAndPassword, signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
import { doc, getDoc, setDoc, collection, query, where, limit, getDocs } from 'firebase/firestore';
import { auth, db } from '../firebase';

const Login = () => {
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Forgot password states
  const [isForgot, setIsForgot] = useState(false);
  const [forgotStep, setForgotStep] = useState(1); // 1: Email, 2: Code, 3: New Password, 4: Success
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotCode, setForgotCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [forgotError, setForgotError] = useState('');
  const [isForgotLoading, setIsForgotLoading] = useState(false);

  const { user, isAuthenticated, login } = useAuth();
  const { settings } = useSettings();
  const navigate = useNavigate();

  const handleForgotRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    setForgotError('');
    setIsForgotLoading(true);
    try {
      let identifier = forgotEmail.trim();

      const response = await fetch('/api/forgot-password/request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ identifier }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to request password reset code.');
      }

      setForgotEmail(data.email || identifier);
      setForgotStep(2);
    } catch (err: any) {
      setForgotError(err.message || 'Failed to request password reset.');
    } finally {
      setIsForgotLoading(false);
    }
  };

  const handleForgotVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    setForgotError('');
    setIsForgotLoading(true);
    try {
      const response = await fetch('/api/forgot-password/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: forgotEmail, code: forgotCode }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Invalid or expired code.');
      }

      setForgotStep(3);
    } catch (err: any) {
      setForgotError(err.message || 'Verification failed. Please check the code.');
    } finally {
      setIsForgotLoading(false);
    }
  };

  const handleForgotReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setForgotError('');
    if (newPassword.length < 6) {
      setForgotError('Password must be at least 6 characters long.');
      return;
    }
    if (newPassword !== confirmNewPassword) {
      setForgotError('Passwords do not match.');
      return;
    }

    setIsForgotLoading(true);
    try {
      const response = await fetch('/api/forgot-password/reset', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: forgotEmail,
          code: forgotCode,
          newPassword,
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Reset failed.');
      }

      setForgotStep(4);
    } catch (err: any) {
      setForgotError(err.message || 'Password reset failed.');
    } finally {
      setIsForgotLoading(false);
    }
  };

  useEffect(() => {
    if (isAuthenticated && user) {
      if (user.role === 'admin' || user.role === 'moderator') {
        navigate('/admin');
      } else {
        navigate('/dashboard');
      }
    }
  }, [isAuthenticated, user, navigate]);

  const handleGoogleSignIn = async () => {
    try {
      // Initialize provider and call popup IMMEDIATELY to preserve user gesture
      const provider = new GoogleAuthProvider();
      const userCredential = await signInWithPopup(auth, provider);
      
      // Set loading state AFTER the popup is successfully opened/completed
      setError('');
      setIsLoading(true);
      
      const firebaseUser = userCredential.user;
      const token = await firebaseUser.getIdToken();

      // Fetch user role from Firestore
      const userDoc = await getDoc(doc(db, 'users', firebaseUser.uid));
      
      let userData: any = null;
      
      if (userDoc.exists()) {
        userData = { ...userDoc.data(), id: firebaseUser.uid, email: firebaseUser.email };
        
        // Check if student is approved
        if (userData.role === 'student' && userData.status === 'pending') {
          await auth.signOut();
          throw new Error('Your account is pending approval from the administrator. In online mode, you will be able to log in once you are approved.');
        }
      } else if (firebaseUser.email === 'jabermathcare@gmail.com' || firebaseUser.email === 'contact.jabermathcare@gmail.com' || firebaseUser.email === 'mdabudarda2012@gmail.com' || firebaseUser.email === 'tipsandtechunlimited@gmail.com') {
        // Admin fallback if document doesn't exist yet
        userData = {
          id: firebaseUser.uid,
          name: firebaseUser.displayName || 'Admin',
          email: firebaseUser.email,
          role: 'admin'
        };
        // Create the admin user document
        await setDoc(doc(db, 'users', firebaseUser.uid), userData);
      } else {
        await auth.signOut();
        // Throw an error if the user is not added by the admin
        throw new Error('User profile not found. Please contact admin to create your account.');
      }

      login(token, userData);
      
      if (userData.role === 'admin' || userData.role === 'moderator') {
        navigate('/admin');
      } else {
        navigate('/dashboard');
      }
    } catch (err: any) {
      console.error("Google Login error:", err);
      // If the popup was blocked, provide a helpful message
      if (err.code === 'auth/popup-blocked') {
        setError('Login popup was blocked by your browser. Please allow popups for this site and try again.');
      } else if (err.code !== 'auth/popup-closed-by-user') {
        setError(err.message || 'Google Login failed');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    try {
      let loginEmail = identifier.trim();

      // Check if identifier is not an email
      if (!loginEmail.includes('@')) {
        const usersRef = collection(db, 'users');
        // Try roll number first
        let querySnapshot = await getDocs(query(usersRef, where('roll_number', '==', loginEmail), limit(1)));
        
        // Try roll number as number representation
        if (querySnapshot.empty && !isNaN(Number(loginEmail))) {
          querySnapshot = await getDocs(query(usersRef, where('roll_number', '==', Number(loginEmail)), limit(1)));
        }

        // If not found, try phone number
        if (querySnapshot.empty) {
          querySnapshot = await getDocs(query(usersRef, where('phone', '==', loginEmail), limit(1)));
        }

        if (!querySnapshot.empty) {
          loginEmail = querySnapshot.docs[0].data().email;
        } else {
          throw new Error('user-not-found');
        }
      }

      // Sign in with Firebase Auth
      const userCredential = await signInWithEmailAndPassword(auth, loginEmail, password);
      const firebaseUser = userCredential.user;
      const token = await firebaseUser.getIdToken();

      // Fetch user role from Firestore
      const userDoc = await getDoc(doc(db, 'users', firebaseUser.uid));
      
      let userData: any = null;
      
      if (userDoc.exists()) {
        userData = { ...userDoc.data(), id: firebaseUser.uid, email: firebaseUser.email };
        
        // Check if student is approved
        if (userData.role === 'student' && userData.status === 'pending') {
          await auth.signOut();
          throw new Error('Your account is pending approval from the administrator. In online mode, you will be able to log in once you are approved.');
        }
      } else if (firebaseUser.email === 'jabermathcare@gmail.com' || firebaseUser.email === 'contact.jabermathcare@gmail.com' || firebaseUser.email === 'mdabudarda2012@gmail.com' || firebaseUser.email === 'tipsandtechunlimited@gmail.com') {
        // Admin fallback if document doesn't exist yet
        userData = {
          id: firebaseUser.uid,
          name: 'Admin',
          email: firebaseUser.email,
          role: 'admin'
        };
        // Create the admin user document for email/pass login too
        await setDoc(doc(db, 'users', firebaseUser.uid), {
          name: userData.name,
          email: userData.email,
          role: 'admin',
          created_at: new Date().toISOString()
        });
      } else {
        await auth.signOut();
        throw new Error('User profile not found. Please contact admin.');
      }

      login(token, userData);
      
      if (userData.role === 'admin' || userData.role === 'moderator') {
        navigate('/admin');
      } else {
        navigate('/dashboard');
      }
    } catch (err: any) {
      console.error("Login error:", err);
      // Format Firebase error messages
      const errorCode = err.code || '';
      const errorMessage = err.message || '';
      
      if (errorCode === 'auth/user-not-found' || 
          err.message === 'user-not-found' ||
          errorCode === 'auth/wrong-password' || 
          errorCode === 'auth/invalid-credential' || 
          errorCode === 'auth/invalid-login-credentials' ||
          errorMessage.includes('invalid-credential')) {
        
        setError('Invalid identifier or password. Please check your credentials.');
      } else if (errorCode === 'auth/invalid-email') {
        setError('Invalid email format. Please enter a valid email address.');
      } else if (errorCode === 'auth/operation-not-allowed') {
        setError('Email/Password login is not enabled. Please use Google Sign-In or contact the administrator.');
      } else if (errorCode === 'auth/too-many-requests') {
        setError('Too many failed login attempts. Please try again later or reset your password.');
      } else {
        setError(err.message || 'Login failed. Please try again.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex bg-slate-50/40 relative overflow-hidden font-sans">
      {/* Decorative left panel with framed image card */}
      <div className="hidden lg:flex lg:w-1/2 relative bg-gradient-to-br from-orange-50/80 via-orange-100/40 to-white items-center justify-center p-14 overflow-hidden border-r border-slate-100/80">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-1/4 -left-12 w-[480px] h-[480px] bg-orange-200/25 blur-[120px] rounded-full" />
          <div className="absolute bottom-1/4 -right-12 w-[480px] h-[480px] bg-amber-200/25 blur-[120px] rounded-full" />
        </div>

        {/* Framed Showroom Card - LARGER desktop photo layout ("sobi arektu boro") with super rounded corners ("rounded corner") */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.95, y: 30 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
          className="relative w-full max-w-[480px] bg-white p-8 rounded-[3.5rem] shadow-[0_50px_120px_-30px_rgba(249,115,22,0.14)] border border-slate-100 flex flex-col justify-between"
        >
          {/* Accent top elements */}
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3.5">
              <div className="p-2.5 bg-orange-50 rounded-2xl border border-orange-100/40 shadow-sm">
                <img 
                  src={settings.logo_url || "https://cdn-icons-png.flaticon.com/512/3135/3135715.png"} 
                  alt="Logo" 
                  className="h-9 w-9 rounded-xl object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="flex flex-col">
                <span className="text-sm font-black text-slate-950 tracking-tight leading-none">
                  {settings.site_name || "Jaber Math Care"}
                </span>
                <span className="text-[10px] text-orange-600 font-bold mt-0.5 uppercase tracking-wider">
                  Conceptual Hub
                </span>
              </div>
            </div>
            <span className="text-[10px] font-black text-orange-600 uppercase tracking-widest bg-orange-50 px-4 py-2 rounded-full border border-orange-100/50">
              Interactive Portal
            </span>
          </div>

          {/* Picture with premium ultra-rounded corners ("rounded corner sobir ar") */}
          <div className="relative aspect-[4/3] w-full rounded-[2.5rem] overflow-hidden shadow-md bg-slate-50 border border-slate-100/60 group">
            <div className="absolute inset-0 bg-gradient-to-tr from-orange-600/15 via-transparent to-transparent z-10 opacity-70 group-hover:opacity-40 transition-opacity duration-500" />
            <img 
              src={settings.login_page_image || "https://img.magnific.com/free-vector/isaac-newton-sitting-apple-tree_1308-91323.jpg?semt=ais_hybrid&w=740&q=80"}
              alt="Isaac Newton Sitting"
              className="absolute inset-0 w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
            />
          </div>

          {/* Card descriptive caption */}
          <div className="mt-8 text-center">
            <div className="inline-flex items-center justify-center gap-1.5 px-3 py-1 bg-slate-50 rounded-full border border-slate-100 text-[10px] font-bold text-slate-500 mb-3 uppercase tracking-wider">
              <Star className="w-3 h-3 text-orange-500 fill-orange-500" /> Inspired Learning
            </div>
            <h3 className="text-2xl font-black text-orange-600 tracking-tight leading-snug">
              Visualize Math
            </h3>
            <p className="text-[11px] text-slate-500 font-semibold mt-2 leading-relaxed max-w-sm mx-auto">
              Unlock elegant live lectures, step-by-step physical models, conceptual exercise sheets, and real-time live tests designed strictly for high-achievers.
            </p>
          </div>
        </motion.div>
      </div>

      {/* Right panel featuring login form, optimized beautifully for mobile, tablets and desktop */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-5 sm:p-12 md:p-16 bg-gradient-to-br from-orange-50/30 via-white to-slate-50/30 relative">
        {/* Sleek multi-layered background details with premium orange glows */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-0 right-0 w-[450px] h-[450px] bg-orange-100/30 blur-[130px] rounded-full" />
          <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-amber-100/20 blur-[120px] rounded-full" />
          <div className="absolute top-1/2 left-1/4 w-[300px] h-[300px] bg-orange-200/10 blur-[100px] rounded-full" />
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 25 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          className="w-full max-w-md relative z-10"
        >
          {/* Brand Presentation on Mobile and Tablet - Now in a dedicated Modern Card ("Jaber Math Care orange ar logulo akta card a") */}
          <div className="lg:hidden mb-10">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.1, type: "spring", stiffness: 150 }}
              className="bg-white/95 backdrop-blur-xl rounded-[2.5rem] p-6 shadow-[0_20px_60px_-15px_rgba(249,115,22,0.15)] border border-orange-100 flex flex-col items-center text-center"
            >
              <div className="p-4 bg-gradient-to-br from-orange-500 to-orange-600 rounded-3xl shadow-xl shadow-orange-500/30 mb-5 border border-orange-400/20">
                <img 
                  src={settings.logo_url || "https://cdn-icons-png.flaticon.com/512/3135/3135715.png"} 
                  alt="Logo" 
                  className="h-14 w-14 rounded-2xl object-cover bg-white p-0.5 shadow-sm"
                  referrerPolicy="no-referrer"
                />
              </div>
              <h1 className="text-3xl font-black text-orange-600 tracking-tight leading-none mb-2">
                {settings.site_name || "Jaber Math Care"}
              </h1>
              <div className="inline-flex items-center gap-1.5 px-4 py-1.5 bg-orange-50 rounded-full border border-orange-100/60 shadow-inner">
                <span className="w-2 h-2 rounded-full bg-orange-500 animate-pulse" />
                <span className="text-[11px] text-orange-700 font-extrabold uppercase tracking-widest">
                  Academic Portal
                </span>
              </div>
            </motion.div>
          </div>

          {/* Desktop Heading - Clean, Beautiful, Highly Modern with Orange Theme ("Student Login leka ta orange color") */}
          <div className="hidden lg:block text-left mb-10">
            <div className="flex items-center gap-3 mb-3">
              <span className="h-1.5 w-10 bg-orange-500 rounded-full inline-block shadow-sm shadow-orange-500/30"></span>
              <span className="text-[11px] font-black text-orange-600 uppercase tracking-widest bg-orange-50 px-3 py-1 rounded-lg border border-orange-100/50">
                Authorized Access
              </span>
            </div>
            <h1 className="text-5xl font-black text-orange-600 tracking-tight leading-tight mb-4 drop-shadow-sm">
              Student Login<span className="text-slate-900 font-extrabold animate-pulse">.</span>
            </h1>
            <p className="text-base text-slate-500 font-semibold leading-relaxed max-w-sm">
              Enter your student credentials to unlock video lectures, physical models, and live exams.
            </p>
          </div>

          {/* Majestic login card with soft shadows & orange responsive highlights */}
          <div className="bg-white/95 backdrop-blur-md rounded-[2.5rem] border border-orange-100/80 p-6 sm:p-10 shadow-[0_32px_80px_-20px_rgba(249,115,22,0.08)] hover:shadow-[0_45px_100px_-15px_rgba(249,115,22,0.12)] transition-all duration-500">
            {isForgot ? (
              <div className="space-y-6">
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => {
                      setIsForgot(false);
                      setForgotStep(1);
                      setForgotError('');
                    }}
                    className="p-2 -ml-2 rounded-xl hover:bg-slate-50 text-slate-500 hover:text-slate-800 transition-all cursor-pointer"
                  >
                    <ArrowLeft className="h-5 w-5" />
                  </button>
                  <div>
                    <h3 className="text-xl font-black text-slate-800 tracking-tight">
                      Reset Password
                    </h3>
                    <p className="text-xs text-slate-400 font-semibold uppercase tracking-wider">
                      Step {forgotStep} of 3
                    </p>
                  </div>
                </div>

                {forgotError && (
                  <motion.div 
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="bg-red-50 border border-red-100 text-red-600 p-4 rounded-2xl text-sm font-medium flex items-center gap-3 shadow-sm"
                  >
                    <div className="w-1.5 h-1.5 bg-red-600 rounded-full animate-pulse flex-shrink-0" />
                    <span className="font-semibold leading-snug">{forgotError}</span>
                  </motion.div>
                )}

                {forgotStep === 1 && (
                  <form onSubmit={handleForgotRequest} className="space-y-5">
                    <div className="space-y-2">
                      <label className="text-xs font-black text-slate-500 uppercase tracking-wider block">
                        Email Address, Roll or Phone
                      </label>
                      <div className="relative group">
                        <div className="absolute inset-y-0 left-0 pl-4.5 flex items-center pointer-events-none text-slate-400 group-focus-within:text-orange-500 transition-colors">
                          <Mail className="h-5 w-5" />
                        </div>
                        <input
                          type="text"
                          value={forgotEmail}
                          onChange={(e) => setForgotEmail(e.target.value)}
                          className="w-full pl-12.5 pr-4 py-4 bg-slate-50/50 hover:bg-slate-50 focus:bg-white border border-slate-200 group-focus-within:border-orange-300 focus:border-orange-500 rounded-2xl text-slate-800 text-sm font-semibold transition-all shadow-sm outline-none"
                          placeholder="johndoe@gmail.com, roll, or phone"
                          required
                        />
                      </div>
                    </div>

                    <motion.button
                      whileHover={{ scale: 1.01 }}
                      whileTap={{ scale: 0.99 }}
                      type="submit"
                      disabled={isForgotLoading}
                      className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white font-black uppercase tracking-widest text-xs py-4.5 rounded-2xl transition-all shadow-lg shadow-orange-500/25 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                    >
                      {isForgotLoading ? (
                        <>
                          <Loader2 className="h-4 w-4 animate-spin" /> Verifying account...
                        </>
                      ) : (
                        <>
                          Send Reset Code <ArrowRight className="h-4 w-4" />
                        </>
                      )}
                    </motion.button>
                  </form>
                )}

                {forgotStep === 2 && (
                  <form onSubmit={handleForgotVerify} className="space-y-5">
                    <div className="bg-orange-50/50 border border-orange-100/70 p-4 rounded-2xl text-slate-600 text-sm font-semibold">
                      Please check your email. We have sent a 6-digit confirmation code to your Gmail address. Leave this window open and enter it below.
                    </div>

                    <div className="space-y-2">
                      <label className="text-xs font-black text-slate-500 uppercase tracking-wider block">
                        6-Digit Verification Code
                      </label>
                      <div className="relative group">
                        <div className="absolute inset-y-0 left-0 pl-4.5 flex items-center pointer-events-none text-slate-400 group-focus-within:text-orange-500 transition-colors">
                          <Key className="h-5 w-5" />
                        </div>
                        <input
                          type="text"
                          maxLength={6}
                          value={forgotCode}
                          onChange={(e) => setForgotCode(e.target.value.replace(/\D/g, ''))}
                          className="w-full pl-12.5 pr-4 py-4 tracking-[0.3em] font-mono text-center bg-slate-50/50 hover:bg-slate-50 focus:bg-white border border-slate-200 group-focus-within:border-orange-300 focus:border-orange-500 rounded-2xl text-slate-800 text-lg font-black transition-all shadow-sm outline-none"
                          placeholder="000000"
                          required
                        />
                      </div>
                    </div>

                    <motion.button
                      whileHover={{ scale: 1.01 }}
                      whileTap={{ scale: 0.99 }}
                      type="submit"
                      disabled={isForgotLoading}
                      className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white font-black uppercase tracking-widest text-xs py-4.5 rounded-2xl transition-all shadow-lg shadow-orange-500/25 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                    >
                      {isForgotLoading ? (
                        <>
                          <Loader2 className="h-4 w-4 animate-spin" /> Verifying code...
                        </>
                      ) : (
                        <>
                          Verify Code <ArrowRight className="h-4 w-4" />
                        </>
                      )}
                    </motion.button>
                  </form>
                )}

                {forgotStep === 3 && (
                  <form onSubmit={handleForgotReset} className="space-y-5">
                    <div className="space-y-2">
                      <label className="text-xs font-black text-slate-500 uppercase tracking-wider block">
                        New Password
                      </label>
                      <div className="relative group">
                        <div className="absolute inset-y-0 left-0 pl-4.5 flex items-center pointer-events-none text-slate-400 group-focus-within:text-orange-500 transition-colors">
                          <Lock className="h-5 w-5" />
                        </div>
                        <input
                          type="password"
                          value={newPassword}
                          onChange={(e) => setNewPassword(e.target.value)}
                          className="w-full pl-12.5 pr-4 py-4 bg-slate-50/50 hover:bg-slate-50 focus:bg-white border border-slate-200 group-focus-within:border-orange-300 focus:border-orange-500 rounded-2xl text-slate-800 text-sm font-semibold transition-all shadow-sm outline-none"
                          placeholder="At least 6 characters"
                          required
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-xs font-black text-slate-500 uppercase tracking-wider block">
                        Confirm New Password
                      </label>
                      <div className="relative group">
                        <div className="absolute inset-y-0 left-0 pl-4.5 flex items-center pointer-events-none text-slate-400 group-focus-within:text-orange-500 transition-colors">
                          <Lock className="h-5 w-5" />
                        </div>
                        <input
                          type="password"
                          value={confirmNewPassword}
                          onChange={(e) => setConfirmNewPassword(e.target.value)}
                          className="w-full pl-12.5 pr-4 py-4 bg-slate-50/50 hover:bg-slate-50 focus:bg-white border border-slate-200 group-focus-within:border-orange-300 focus:border-orange-500 rounded-2xl text-slate-800 text-sm font-semibold transition-all shadow-sm outline-none"
                          placeholder="At least 6 characters"
                          required
                        />
                      </div>
                    </div>

                    <motion.button
                      whileHover={{ scale: 1.01 }}
                      whileTap={{ scale: 0.99 }}
                      type="submit"
                      disabled={isForgotLoading}
                      className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white font-black uppercase tracking-widest text-xs py-4.5 rounded-2xl transition-all shadow-lg shadow-orange-500/25 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                    >
                      {isForgotLoading ? (
                        <>
                          <Loader2 className="h-4 w-4 animate-spin" /> Saving password...
                        </>
                      ) : (
                        <>
                          Set New Password & login <ArrowRight className="h-4 w-4" />
                        </>
                      )}
                    </motion.button>
                  </form>
                )}

                {forgotStep === 4 && (
                  <div className="text-center space-y-6 py-4">
                    <div className="flex justify-center">
                      <div className="p-4 bg-emerald-50 rounded-full text-emerald-600">
                        <CheckCircle className="h-10 w-10 animate-bounce" />
                      </div>
                    </div>
                    <div>
                      <h4 className="text-lg font-bold text-slate-800">
                        Password Reset Complete
                      </h4>
                      <p className="text-sm text-slate-500 font-semibold mt-2">
                        Your password has been successfully updated via Secure SMTP verification.
                      </p>
                    </div>

                    <motion.button
                      whileHover={{ scale: 1.01 }}
                      whileTap={{ scale: 0.99 }}
                      onClick={() => {
                        setIsForgot(false);
                        setForgotStep(1);
                        setForgotEmail('');
                        setForgotCode('');
                        setNewPassword('');
                        setConfirmNewPassword('');
                        setForgotError('');
                      }}
                      className="w-full bg-slate-800 hover:bg-slate-900 text-white font-black uppercase tracking-widest text-xs py-4.5 rounded-2xl transition-all shadow-lg flex items-center justify-center gap-2 cursor-pointer"
                    >
                      Back to Secure Login
                    </motion.button>
                  </div>
                )}
              </div>
            ) : (
              // Normal Login Form
              <>
                {error && (
                  <motion.div 
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="bg-red-50 border border-red-100 text-red-600 p-4 rounded-2xl mb-6 text-sm font-medium flex items-center gap-3 shadow-sm"
                  >
                    <div className="w-1.5 h-1.5 bg-red-600 rounded-full animate-pulse flex-shrink-0" />
                    <span className="font-semibold leading-snug">{error}</span>
                  </motion.div>
                )}

                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="space-y-2">
                    <label className="text-xs font-black text-slate-500 uppercase tracking-wider ml-1 block">
                      Email, Roll or Phone Number
                    </label>
                    <div className="relative group">
                      <div className="absolute inset-y-0 left-0 pl-4.5 flex items-center pointer-events-none text-slate-400 group-focus-within:text-orange-500 transition-colors">
                        <User className="h-5 w-5" />
                      </div>
                      <input
                        id="email"
                        type="text"
                        value={identifier}
                        onChange={(e) => setIdentifier(e.target.value)}
                        className="w-full pl-12.5 pr-4 py-4 bg-slate-50/50 hover:bg-slate-50 focus:bg-white border border-slate-200 group-focus-within:border-orange-300 focus:border-orange-500 rounded-2xl text-slate-800 text-sm font-semibold transition-all shadow-sm focus:ring-4 focus:ring-orange-500/10 outline-none"
                        placeholder="Enter registration details"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between items-center px-1">
                      <label className="text-xs font-black text-slate-500 uppercase tracking-wider block">
                        Password
                      </label>
                      <button 
                        type="button" 
                        onClick={() => {
                          setIsForgot(true);
                          setForgotStep(1);
                          setForgotEmail(identifier);
                          setForgotCode('');
                          setNewPassword('');
                          setConfirmNewPassword('');
                          setForgotError('');
                        }}
                        className="text-xs font-black text-orange-600 hover:text-orange-700 transition-colors tracking-tight uppercase cursor-pointer"
                      >
                        Forgot Password?
                      </button>
                    </div>
                    <div className="relative group">
                      <div className="absolute inset-y-0 left-0 pl-4.5 flex items-center pointer-events-none text-slate-400 group-focus-within:text-orange-500 transition-colors">
                        <Lock className="h-5 w-5" />
                      </div>
                      <input
                        id="password"
                        type={showPassword ? "text" : "password"}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full pl-12.5 pr-12 py-4 bg-slate-50/50 hover:bg-slate-50 focus:bg-white border border-slate-200 group-focus-within:border-orange-300 focus:border-orange-500 rounded-2xl text-slate-800 text-sm font-semibold transition-all shadow-sm focus:ring-4 focus:ring-orange-500/10 outline-none"
                        placeholder="••••••••"
                        required
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute inset-y-0 right-0 pr-4.5 flex items-center text-slate-400 hover:text-orange-500 transition-colors focus:outline-none"
                      >
                        {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                      </button>
                    </div>
                  </div>

                  <motion.button
                    whileHover={{ scale: 1.01, y: -1 }}
                    whileTap={{ scale: 0.99 }}
                    type="submit"
                    disabled={isLoading}
                    className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white font-black uppercase tracking-widest text-xs py-4.5 rounded-2xl transition-all shadow-lg shadow-orange-500/25 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 mt-6 cursor-pointer"
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin" /> Authenticating...
                      </>
                    ) : (
                      <>
                        <LogIn className="h-4 w-4" /> Secure Sign In
                      </>
                    )}
                  </motion.button>
                </form>

                <div className="relative flex items-center py-6">
                  <div className="flex-grow border-t border-slate-100"></div>
                  <span className="flex-shrink-0 mx-4 text-slate-400 text-[10px] font-black uppercase tracking-widest">Or access with</span>
                  <div className="flex-grow border-t border-slate-100"></div>
                </div>

                <motion.button
                  whileHover={{ scale: 1.01 }}
                  whileTap={{ scale: 0.99 }}
                  onClick={handleGoogleSignIn}
                  disabled={isLoading}
                  className="w-full bg-white hover:bg-orange-50/20 border border-orange-200 hover:border-orange-300 text-slate-700 py-4 rounded-2xl text-xs font-black uppercase tracking-widest shadow-sm hover:shadow-md transition-all flex items-center justify-center gap-3 disabled:opacity-70 cursor-pointer"
                >
                  <svg className="w-4 h-4" viewBox="0 0 24 24">
                    <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
                    <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
                    <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05" />
                    <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
                  </svg>
                  Google Account
                </motion.button>
                
                <div className="mt-6 text-center text-[10px] text-slate-400 font-extrabold uppercase tracking-wider leading-relaxed">
                  Please contact the admin before signing in with Google.
                </div>
              </>
            )}
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Login;
