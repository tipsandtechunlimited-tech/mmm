import React from 'react';
import { motion } from 'motion/react';
import { useNavigate } from 'react-router-dom';
import { useSettings } from '../context/SettingsContext';
import { useAuth } from '../context/AuthContext';
import { Phone, Search, Home, LogIn } from 'lucide-react';

interface NotFoundProps {
  title?: string;
  subtitle?: string;
}

const NotFound: React.FC<NotFoundProps> = ({ title, subtitle }) => {
  const navigate = useNavigate();
  const { settings } = useSettings();
  const { user } = useAuth();

  const siteName = settings.site_name || "Jaber Math Care";
  const logoUrl = settings.logo_url || "https://cdn-icons-png.flaticon.com/512/3135/3135715.png";
  const contactPhone = settings.contact_phone || "01967703901";

  const displayTitle = title || "Look like you're lost";
  const displaySubtitle = subtitle || "404";

  // WhatsApp click handler
  const handleWhatsAppClick = () => {
    const formattedPhone = contactPhone.replace(/[^0-9]/g, '');
    const waPhone = formattedPhone.startsWith('88') ? formattedPhone : `88${formattedPhone}`;
    window.open(`https://wa.me/${waPhone}?text=Hello! I got lost on the website.`, '_blank');
  };

  return (
    <div className="min-h-screen flex flex-col bg-white text-slate-800 font-sans relative overflow-x-hidden">
      
      {/* 1. BRAND HEADER (Matching the image) */}
      <header className="w-full bg-white border-b border-slate-100 py-3 px-4 md:px-10 flex items-center justify-between z-50">
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => navigate('/')}>
          <img 
            src={logoUrl} 
            alt="Logo" 
            className="w-10 h-10 object-contain rounded-xl shadow-sm border border-slate-100" 
            onError={(e) => {
              (e.target as HTMLImageElement).src = "https://cdn-icons-png.flaticon.com/512/3135/3135715.png";
            }}
          />
          <span className="text-lg md:text-xl font-black text-slate-800 uppercase tracking-tighter">
            {siteName}
          </span>
        </div>

        {/* Header Right Segment */}
        <div className="flex items-center gap-4 md:gap-6">
          {/* Support Line */}
          <div className="hidden sm:flex flex-col items-end text-right">
            <span className="text-[10px] text-slate-400 font-black tracking-widest uppercase">any_queries</span>
            <a href={`tel:${contactPhone}`} className="text-sm font-black text-slate-800 flex items-center gap-1 hover:text-orange-600 transition-colors">
              <Phone className="h-3.5 w-3.5 text-orange-500 fill-orange-500/20" />
              {contactPhone}
            </a>
          </div>

          <div className="flex items-center gap-2">
            {/* Search Icon Indicator */}
            <div className="w-9 h-9 rounded-full hover:bg-slate-50 flex items-center justify-center cursor-pointer text-slate-400 transition-colors">
              <Search className="w-5 h-5" />
            </div>

            {/* Login / Dashboard Button */}
            {user ? (
              <button 
                onClick={() => navigate('/dashboard')}
                className="px-5 py-2 rounded-full border-[1.5px] border-orange-500 text-orange-600 font-bold text-xs uppercase tracking-widest hover:bg-orange-50 transition-all flex items-center gap-1.5"
              >
                Dashboard
              </button>
            ) : (
              <button 
                onClick={() => navigate('/login')}
                className="px-5 py-2 rounded-full border-[1.5px] border-orange-500 text-orange-600 font-bold text-xs uppercase tracking-widest hover:bg-orange-50 transition-all flex items-center gap-1.5"
              >
                <LogIn className="w-3.5 h-3.5" />
                Login
              </button>
            )}
          </div>
        </div>
      </header>

      {/* 2. CHIEFS BLOCK: LOOK LIKE YOU'RE LOST 404 & CAVEMAN ILLUSTRATION */}
      <main className="flex-1 flex flex-col items-center justify-center pt-8 pb-20 px-4 relative">
        
        {/* Background Decorative Minimalist Stones (Exactly Matching the Images!) */}
        <div className="absolute inset-x-0 bottom-16 flex justify-between px-4 sm:px-12 md:px-24 pointer-events-none z-0 opacity-15 sm:opacity-100 transition-opacity duration-300">
          
          {/* Left Rock Stack Accent */}
          <div className="flex flex-col items-center select-none pb-2">
            {/* Stacked stone shapes */}
            <div className="w-14 h-6 bg-slate-100 rounded-full border border-slate-200/50" />
            <div className="w-10 h-10 bg-slate-200/60 rounded-full border border-slate-300/40 -mt-2 shadow-sm" />
            <div className="w-14 h-14 bg-slate-100 rounded-2xl border border-slate-200/50 -mt-1 transform rotate-12 flex items-center justify-center">
              <div className="w-4 h-4 rounded-full bg-slate-200" />
            </div>
            {/* Minimalist leaf/grass */}
            <div className="flex gap-1 mt-1">
              <div className="w-3 h-4 bg-orange-400/80 rounded-tl-full transform -rotate-12" />
              <div className="w-2.5 h-5 bg-orange-500/80 rounded-tr-full transform rotate-12" />
            </div>
          </div>

          {/* Right Pillar Accent */}
          <div className="flex flex-col items-center select-none justify-end">
            {/* Tall pillar stone */}
            <div className="w-16 sm:w-20 h-40 sm:h-56 bg-gradient-to-t from-slate-100 to-slate-50/60 rounded-t-[3rem] border border-b-0 border-slate-200/40 shadow-sm flex items-start justify-center pt-6">
              <div className="w-6 h-6 rounded-full bg-slate-200/40" />
            </div>
            {/* Orange plants around base */}
            <div className="flex gap-1.5 -mt-2">
              <div className="w-4 h-6 bg-orange-400/80 rounded-tl-full transform -rotate-45" />
              <div className="w-3 h-8 bg-orange-500 rounded-t-full" />
              <div className="w-4 h-6 bg-orange-400/80 rounded-tr-full transform rotate-45" />
            </div>
          </div>
        </div>

        {/* Main Content Card Wrapper */}
        <div className="relative z-10 text-center max-w-lg w-full flex flex-col items-center">
          
          <h2 className="text-xl sm:text-2xl font-black text-slate-700 tracking-tight select-none mb-1 font-sans uppercase">
            {displayTitle}
          </h2>

          <h1 className="text-7xl sm:text-8xl font-black text-slate-800 drop-shadow-sm select-none tracking-tight leading-none mb-4">
            {displaySubtitle}
          </h1>

          {/* Interactive Caveman Swing & Radar Ring Wrapper */}
          <div className="relative w-72 h-72 flex items-center justify-center select-none my-2">
            
            {/* 3. Concentric Flashing Radar Rays (exactly like frame 1-5 in the video!) */}
            <div className="absolute inset-0 flex items-center justify-center">
              {/* Pulse 1 */}
              <motion.div 
                className="absolute w-44 h-44 rounded-full border-2 border-dashed border-orange-200"
                animate={{ scale: [0.8, 1.25], opacity: [0.6, 0] }}
                transition={{ duration: 2.2, repeat: Infinity, ease: "easeOut" }}
              />
              {/* Pulse 2 */}
              <motion.div 
                className="absolute w-56 h-56 rounded-full border-2 border-dashed border-orange-300"
                animate={{ scale: [0.8, 1.45], opacity: [0.8, 0] }}
                transition={{ duration: 2.2, repeat: Infinity, ease: "easeOut", delay: 0.7 }}
              />
              {/* Pulse 3 */}
              <motion.div 
                className="absolute w-64 h-64 rounded-full border-2 border-dashed border-orange-100"
                animate={{ scale: [0.9, 1.6], opacity: [0.5, 0] }}
                transition={{ duration: 2.2, repeat: Infinity, ease: "easeOut", delay: 1.4 }}
              />
            </div>

            {/* Caveman character dangling on a rope, swinging slowly */}
            <motion.div
              className="relative w-56 h-56 flex flex-col items-center origin-top z-10"
              animate={{ rotate: [-6, 6, -6] }}
              transition={{ duration: 4.5, repeat: Infinity, ease: "easeInOut" }}
            >
              {/* Rope hanging from ceiling to character */}
              <div className="absolute top-0 w-0.5 h-16 bg-slate-700 z-0 after:content-[''] after:absolute after:bottom-0 after:left-1/2 after:-translate-x-1/2 after:w-1.5 after:h-1.5 after:bg-slate-900 after:rounded-full" />

              {/* Character Drawing */}
              <div className="mt-16 flex flex-col items-center">
                
                {/* Caveman Body Core */}
                <div className="relative w-24 h-24 flex items-center justify-center">
                  
                  {/* Bushy Hair Background */}
                  <div className="absolute top-0 w-20 h-20 bg-[#3d2314] rounded-full shadow-md transform scale-110" />

                  {/* Caveman Head/Face */}
                  <div className="absolute top-3 w-14 h-14 bg-[#f8be91] rounded-full border-2 border-[#3d2314] flex flex-col items-center justify-center p-1 z-10">
                    
                    {/* Eyebrows & Eyes */}
                    <div className="flex gap-3 mt-1 justify-center w-full">
                      <div className="flex flex-col items-center">
                        <span className="text-[7px] text-[#3d2314] font-black -mb-1 select-none">\</span>
                        <div className="w-2.5 h-2.5 bg-white rounded-full flex items-center justify-center border border-[#3d2314]">
                          {/* Pulsing pupil looking distressed */}
                          <motion.div 
                            className="w-1.5 h-1.5 bg-slate-900 rounded-full" 
                            animate={{ x: [-0.5, 0.5, -0.5], y: [0.5, -0.5, 0.5] }}
                            transition={{ duration: 3, repeat: Infinity }}
                          />
                        </div>
                      </div>
                      <div className="flex flex-col items-center">
                        <span className="text-[7px] text-[#3d2314] font-black -mb-1 select-none">/</span>
                        <div className="w-2.5 h-2.5 bg-white rounded-full flex items-center justify-center border border-[#3d2314]">
                          <motion.div 
                            className="w-1.5 h-1.5 bg-slate-900 rounded-full" 
                            animate={{ x: [0.5, -0.5, 0.5], y: [-0.5, 0.5, -0.5] }}
                            transition={{ duration: 3, repeat: Infinity }}
                          />
                        </div>
                      </div>
                    </div>

                    {/* Cute Caveman Beard covering most of lower face */}
                    <div className="w-16 h-10 bg-[#3d2314] rounded-b-2xl border-t border-slate-700/50 mt-1 shadow-sm flex items-center justify-center">
                      {/* Distressed small mouth inside beard */}
                      <div className="w-3 h-2 bg-slate-950 rounded-full border border-amber-600/30 animate-pulse mt-0.5" />
                    </div>
                  </div>

                  {/* Caveman Outfit (Orange wrap with cheetah tiger spots) */}
                  <div className="absolute bottom-[-10px] w-16 h-14 bg-gradient-to-br from-orange-400 to-orange-500 rounded-b-2xl border-2 border-[#3d2314] overflow-hidden z-20 flex flex-wrap justify-around p-1">
                    {/* Dark spot accents */}
                    <div className="w-2 h-2 rounded-full bg-[#3d2314]/80 mt-1" />
                    <div className="w-3 h-1.5 rounded-full bg-[#3d2314]/80 mt-3" />
                    <div className="w-1.5 h-3 rounded-full bg-[#3d2314]/80 mt-2" />
                    <div className="w-2 h-2 rounded-full bg-[#3d2314]/80 mt-4" />
                  </div>

                  {/* Hanging Arms holding the rope */}
                  <div className="absolute -left-1.5 top-10 flex flex-col items-center origin-right rotate-45 z-20">
                    <div className="w-4 h-10 bg-[#f8be91] rounded-full border-2 border-[#3d2314] shadow-sm flex items-end justify-center">
                      <div className="w-5 h-5 bg-[#e2965d] rounded-full border-2 border-[#3d2314] -mb-1" />
                    </div>
                  </div>
                  <div className="absolute -right-1.5 top-10 flex flex-col items-center origin-left -rotate-45 z-20">
                    <div className="w-4 h-10 bg-[#f8be91] rounded-full border-2 border-[#3d2314] shadow-sm flex items-end justify-center">
                      <div className="w-5 h-5 bg-[#e2965d] rounded-full border-2 border-[#3d2314] -mb-1" />
                    </div>
                  </div>
                </div>

                {/* Dangling Legs */}
                <div className="flex gap-4 -mt-2 z-10">
                  <motion.div 
                    className="w-3.5 h-10 bg-[#f8be91] rounded-b-full border-2 border-t-0 border-[#3d2314] flex items-end justify-center"
                    animate={{ rotate: [-8, 8, -8] }}
                    transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
                  >
                    <div className="w-4.5 h-3 bg-[#e2965d] rounded-full border-2 border-[#3d2314] -mb-1.5" />
                  </motion.div>
                  <motion.div 
                    className="w-3.5 h-10 bg-[#f8be91] rounded-b-full border-2 border-t-0 border-[#3d2314] flex items-end justify-center"
                    animate={{ rotate: [8, -8, 8] }}
                    transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
                  >
                    <div className="w-4.5 h-3 bg-[#e2965d] rounded-full border-2 border-[#3d2314] -mb-1.5" />
                  </motion.div>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Go to Home Button (Bondi style beautiful button in brand Orange color!) */}
          <motion.button 
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => navigate('/')}
            className="mt-6 px-14 py-3 rounded-xl bg-orange-600 text-white font-black text-sm uppercase tracking-wider shadow-lg shadow-orange-600/30 hover:bg-orange-700 transition-all border-b-4 border-orange-800"
          >
            Go to Home
          </motion.button>
        </div>
      </main>

      {/* 4. FLOATING WHATSAPP CHAT ICON (Bottom Right) */}
      <div className="fixed bottom-5 right-5 z-50">
        <motion.button
          whileHover={{ scale: 1.15 }}
          whileTap={{ scale: 0.9 }}
          onClick={handleWhatsAppClick}
          className="w-14 h-14 bg-[#25d366] rounded-full shadow-[0_10px_25px_rgba(37,211,102,0.4)] hover:shadow-[0_12px_30px_rgba(37,211,102,0.6)] flex items-center justify-center cursor-pointer transition-shadow border-2 border-white focus:outline-none relative group"
        >
          {/* Pulsing indicator around WhatsApp */}
          <div className="absolute inset-0 rounded-full border-4 border-[#25d366]/30 animate-ping pointer-events-none" />
          
          <svg viewBox="0 0 24 24" className="w-8 h-8 text-white fill-white">
            <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.06 5.348 5.397.01 12.008.01c3.202.001 6.212 1.246 8.477 3.514 2.266 2.268 3.507 5.28 3.505 8.484-.004 6.657-5.34 11.997-11.953 11.997-2.005-.001-3.973-.502-5.724-1.455L0 24zm6.59-4.846c1.6.95 3.1 1.45 4.7 1.45 5.5 0 9.9-4.5 10-10 .0-2.6-1.0-5.1-2.9-7-1.9-1.9-4.4-2.9-7-2.9-5.5 0-9.9 4.5-9.9 10 0 1.7.4 3.3 1.3 4.8l-1 3.6 3.7-.95zm11.3-4.144c-.3-.15-1.8-.9-2.05-1-.25-.1-.45-.15-.65.15-.2.3-.75 1-.9 1.15-.15.15-.3.15-.6 0-1.1-.5-2.05-1.15-2.85-2-.6-.55-1.2-1.2-1.2-1.2 0-.3.3-.35.45-.5.15-.15.3-.3.45-.45.15-.15.2-.25.3-.4.1-.15.05-.3 0-.45-.05-.15-.65-1.55-.9-2.15-.25-.6-.5-.5-.65-.5-.15 0-.35-.05-.55-.05-.2 0-.55.05-.85.4-.3.35-1.15 1.15-1.15 2.8s1.2 3.25 1.35 3.45c.15.2 2.35 3.6 5.7 5.05.8.35 1.4.55 1.9.7.8.25 1.5.2 2.1.1.65-.1 1.8-.75 2.05-1.4.25-.7.25-1.3.15-1.4-.1-.15-.3-.25-.6-.4z" />
          </svg>
        </motion.button>
      </div>

    </div>
  );
};

export default NotFound;
