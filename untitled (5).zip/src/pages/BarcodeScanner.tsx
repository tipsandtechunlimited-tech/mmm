import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { useSettings } from '../context/SettingsContext';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle, AlertCircle, Scan, User, School, Calendar, ArrowLeft, ClipboardList, Camera } from 'lucide-react';
import { db } from '../firebase';
import { collection, query, where, getDocs, doc, writeBatch, setDoc, getDoc, orderBy } from 'firebase/firestore';
import { Link } from 'react-router-dom';
import { Html5QrcodeScanner } from 'html5-qrcode';

const QrReaderComponent = ({ onScan }: { onScan: (decodedText: string) => void }) => {
  const onScanRef = useRef(onScan);
  useEffect(() => {
    onScanRef.current = onScan;
  }, [onScan]);

  useEffect(() => {
    const scanner = new Html5QrcodeScanner("reader", { qrbox: { width: 250, height: 250 }, fps: 6 }, false);
    
    scanner.render((decodedText) => {
      if (onScanRef.current) onScanRef.current(decodedText);
      scanner.pause(true);
      
      // Auto resume scanners after 3.2 seconds so multiple students can swipe seamlessly!
      setTimeout(() => {
        try {
          scanner.resume();
        } catch (e) {
          console.log("Scanner resume API details ignored:", e);
        }
      }, 3200);
    }, (err) => {
      // Ignore failures
    });

    return () => {
      scanner.clear().catch(e => console.error("Scanner clear API error:", e));
    };
  }, []);

  return (
    <div className="w-full bg-white text-slate-900 rounded-[2rem] overflow-hidden shadow-inner">
      <div id="reader" className="w-full" style={{ minHeight: '280px' }} />
    </div>
  );
};

const BarcodeScanner = () => {
  const { user } = useAuth();
  const { settings } = useSettings();
  const [barcode, setBarcode] = useState('');
  const [scannedStudent, setScannedStudent] = useState<any>(null);
  const [scanStatus, setScanStatus] = useState<'idle' | 'scanning' | 'success' | 'error'>('idle');
  const [statusMessage, setStatusMessage] = useState('');
  const [mode, setMode] = useState<'class'|'exam'>('class');
  const [exams, setExams] = useState<any[]>([]);
  const [selectedExamId, setSelectedExamId] = useState<string>('');
  
  const [events, setEvents] = useState<any[]>([]);
  
  const lastScannedIdRef = useRef<string>('');
  const lastScannedTimeRef = useRef<number>(0);
  const autoResetTimerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    const fetchExams = async () => {
      try {
        const snapshot = await getDocs(query(collection(db, "exams")));
        const examsData = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as any));
        // Sort by date descending
        examsData.sort((a,b) => new Date(b.exam_date || b.date).getTime() - new Date(a.exam_date || a.date).getTime());
        setExams(examsData);
        if(examsData.length > 0) setSelectedExamId(examsData[0].id);
        
        const evtsSnap = await getDocs(collection(db, "events"));
        setEvents(evtsSnap.docs.map(d => ({ ...d.data(), id: d.id })));
      } catch (e) {
        console.error(e);
      }
    };
    fetchExams();
  }, []);

  const playSuccess = () => {
    try {
      const audio = new Audio('https://cdn.pixabay.com/download/audio/2021/08/04/audio_0625c1539c.mp3?filename=success-1-6297.mp3');
      audio.volume = 0.5;
      audio.play().catch(e => console.log(e));
    } catch(e){}
  };

  const playError = () => {
    try {
      const audio = new Audio('https://cdn.pixabay.com/download/audio/2022/03/10/audio_c8b7fafdf3.mp3?filename=error-126627.mp3');
      audio.volume = 0.5;
      audio.play().catch(e => console.log(e));
    } catch(e){}
  };

  useEffect(() => {
    let debounceTimer: NodeJS.Timeout;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (document.activeElement?.tagName === 'INPUT' || document.activeElement?.tagName === 'TEXTAREA') {
        return;
      }
      
      if (e.key === 'Enter') {
        if (barcode.trim().length > 0) {
          handleScan(barcode.trim());
          setBarcode('');
        }
      } else {
        const char = e.key;
        if (char.length === 1) {
          setBarcode(prev => prev + char);
          setScanStatus('scanning');
          
          clearTimeout(debounceTimer);
          debounceTimer = setTimeout(() => {
            if (barcode) {
              setBarcode('');
              setScanStatus('idle');
            }
          }, 2000);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      clearTimeout(debounceTimer);
    };
  }, [barcode]);

  const handleScan = async (scannedCode: string) => {
    if (!scannedCode) return;

    const today = new Date().toLocaleDateString('en-CA'); // strict local YYYY-MM-DD
    const activeEvent = events.find(evt => evt.start_date <= today && today <= evt.end_date);
    if (activeEvent && mode === 'class') {
      if (playError) playError();
      setScanStatus('error');
      setStatusMessage(`ATTENDANCE DISABLED: ${activeEvent.title}`);
      
      if (autoResetTimerRef.current) clearTimeout(autoResetTimerRef.current);
      autoResetTimerRef.current = setTimeout(() => {
        setScanStatus('idle');
      }, 4500);
      return;
    }

    let studentIdOrRoll = scannedCode;
    const parts = scannedCode.split('-');
    
    if (parts.length > 2) {
      studentIdOrRoll = parts[parts.length - 1]; // Last item e.g. Roll No or ID
    } else if (scannedCode.includes('-')) {
      studentIdOrRoll = parts[1] || parts[0];
    }

    // Debounce duplicate swiping within 5 seconds to ignore camera double trigger
    const now = Date.now();
    if (lastScannedIdRef.current === studentIdOrRoll && now - lastScannedTimeRef.current < 5000) {
      console.log("Ignored duplicate trigger card scan:", studentIdOrRoll);
      return;
    }

    lastScannedIdRef.current = studentIdOrRoll;
    lastScannedTimeRef.current = now;

    if (autoResetTimerRef.current) {
      clearTimeout(autoResetTimerRef.current);
    }

    setScanStatus('scanning');
    setStatusMessage('Searching student...');
    
    try {
      console.log("Extracted ID/Roll:", studentIdOrRoll);
      const studentsRef = collection(db, 'users');
      const q = query(studentsRef, where('role', '==', 'student'), where('roll_number', '==', studentIdOrRoll));
      const q2 = query(studentsRef, where('role', '==', 'student'), where('id', '==', studentIdOrRoll));
      
      let snapshot = await getDocs(q);
      if (snapshot.empty) {
        snapshot = await getDocs(q2);
      }
      
      if (snapshot.empty) {
        const q3 = query(studentsRef, where('roll_number', '==', scannedCode));
        snapshot = await getDocs(q3);
      }

      if (snapshot.empty) {
        if (playError) playError();
        setScanStatus('error');
        setStatusMessage('Student not found with this ID card.');
        
        autoResetTimerRef.current = setTimeout(() => {
          setScanStatus('idle');
        }, 4500);
        return;
      }

      const studentDoc = snapshot.docs[0];
      const studentData: any = { id: studentDoc.id, ...studentDoc.data() };
      
      // Fetch payment details so Admin can see fee status on scan
      try {
        const paymentSnap = await getDocs(query(collection(db, "payments"), where("student_id", "==", studentData.id)));
        studentData.payments = paymentSnap.docs.map(doc => doc.data());
      } catch (err) {
        console.warn("Could not fetch payments for scanned student", err);
      }
      
      setScannedStudent(studentData);

      await markAttendance(studentData);
      
      if (playSuccess) playSuccess();
      setScanStatus('success');
      setStatusMessage('Attendance logged successfully!');

      // Auto clear scanned overlay card after 4.5 seconds to return to "Hologram Waiting" state
      autoResetTimerRef.current = setTimeout(() => {
        setScanStatus('idle');
        setScannedStudent(null);
      }, 4500);

    } catch (err) {
      console.error(err);
      if (playError) playError();
      setScanStatus('error');
      setStatusMessage('Network Error while taking attendance.');
      
      autoResetTimerRef.current = setTimeout(() => {
        setScanStatus('idle');
      }, 4500);
    }
  };

  const markAttendance = async (student: any) => {
    const today = new Date().toISOString().split('T')[0];
    const attendanceRef = collection(db, 'attendance');
    
    let q;
    if (mode === 'class') {
      q = query(attendanceRef, 
        where('student_id', '==', student.id), 
        where('date', '==', today),
        where('type', '==', 'class')
      );
    } else {
      q = query(attendanceRef, 
        where('student_id', '==', student.id), 
        where('date', '==', today),
        where('type', '==', 'exam'),
        where('exam_id', '==', selectedExamId)
      );
    }
    
    const snap = await getDocs(q);
    if (!snap.empty) {
      return; 
    }

    const payload: any = {
      student_id: student.id,
      student_name: student.name,
      batch_id: String(student.batch_id || ""),
      type: mode,
      date: today,
      status: "present",
      roll_number: student.roll_number,
      phone: student.phone || "",
      created_at: new Date().toISOString()
    };

    if (mode === 'exam') {
      payload.exam_id = selectedExamId;
    }

    const newRecordRef = doc(attendanceRef);
    await setDoc(newRecordRef, payload);
  };

  useEffect(() => {
    return () => {
      if (autoResetTimerRef.current) {
        clearTimeout(autoResetTimerRef.current);
      }
    };
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-500 to-orange-700 flex flex-col items-center justify-start p-4 sm:p-8 text-white font-sans selection:bg-white/30">
      <div className="w-full max-w-6xl mb-6 flex justify-between items-center z-50">
        <Link to="/admin" className="flex items-center gap-2 text-orange-100 hover:text-white transition-colors bg-orange-850/20 backdrop-blur-md border border-white/20 px-4 py-2.5 rounded-xl">
          <ArrowLeft className="h-5 w-5" />
          <span className="font-bold text-sm">Exit Scanner</span>
        </Link>
        <div className="flex items-center gap-2 text-orange-200 text-xs font-black tracking-widest uppercase bg-orange-850/20 backdrop-blur-md border border-white/15 px-4 py-2.5 rounded-xl">
          <Camera className="h-4 w-4 animate-pulse text-emerald-300" />
          <span>Camera Engine Online</span>
        </div>
      </div>

      <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
         <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-white/20 blur-[120px] rounded-full mix-blend-overlay" />
         <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-amber-300/20 blur-[120px] rounded-full mix-blend-overlay" />
      </div>

      <div className="w-full max-w-6xl z-10 flex flex-col items-center space-y-8">
        
        {/* Title */}
        <div className="text-center space-y-1">
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-white tracking-tighter drop-shadow-md">
            {(settings.site_name || "JABER MATH CARE").toUpperCase()}
          </h1>
          <p className="text-orange-100 font-bold tracking-[0.25em] uppercase text-xs sm:text-sm drop-shadow-sm">Attendance Scanner Console</p>
        </div>

        {/* Dynamic Split Grid View: Camera on Left, Result Profile on Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 w-full items-start">
          
          {/* Left Side Container: Always Running Camera Feed */}
          <div className="lg:col-span-5 flex flex-col items-center space-y-6 bg-white/10 backdrop-blur-md rounded-[2.5rem] border border-white/20 p-5 shadow-2xl">
            <h3 className="text-sm font-black tracking-widest uppercase text-orange-200">Live Camera Stream</h3>
            <div className="w-full bg-slate-950 p-2.5 rounded-3xl border border-white/15 shadow-inner">
              <QrReaderComponent onScan={handleScan} />
            </div>

            {/* Controller mode toggles */}
            <div className="w-full p-2 bg-orange-950/40 rounded-2xl border border-orange-900/40 mt-2 text-left">
               <label className="text-[9px] font-black uppercase text-orange-300 tracking-wider mb-2 block text-center">Registration Tracking Mode</label>
               <div className="flex bg-orange-900/60 rounded-xl p-1 mb-4 w-full border border-orange-900/30">
                 <button onClick={() => setMode('class')} className={`flex-1 py-2 text-xs font-black tracking-widest uppercase rounded-lg transition-all ${mode === 'class' ? 'bg-white text-orange-600 shadow-md' : 'text-orange-100 hover:text-white'}`}>Class</button>
                 <button onClick={() => setMode('exam')} className={`flex-1 py-2 text-xs font-black tracking-widest uppercase rounded-lg transition-all ${mode === 'exam' ? 'bg-emerald-500 text-white shadow-md' : 'text-orange-100 hover:text-white'}`}>Exam</button>
               </div>
               {mode === 'exam' && (
                  <div className="w-full">
                     <label className="text-[10px] font-black uppercase text-emerald-300 mb-1.5 block">Select Current Exam:</label>
                     <select className="w-full bg-orange-900/60 border border-emerald-400/40 text-white text-xs font-bold p-3 rounded-xl focus:border-emerald-400 outline-none" value={selectedExamId} onChange={e => setSelectedExamId(e.target.value)}>
                       {exams.map(ex => <option key={ex.id} value={ex.id}>{ex.title || ex.exam_name}</option>)}
                     </select>
                  </div>
               )}
            </div>
          </div>

          {/* Right Side Container: Scanned Results Profile Overview */}
          <div className="lg:col-span-7 w-full">
            <AnimatePresence mode="wait">
              {scanStatus === 'success' && scannedStudent ? (
                <motion.div
                  key="success-scanned"
                  initial={{ opacity: 0, scale: 0.95, y: 30 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95, y: -30 }}
                  transition={{ type: "spring", damping: 25, stiffness: 180 }}
                  className="w-full bg-white border border-slate-100 rounded-[2.5rem] p-6 sm:p-8 shadow-2xl flex flex-col relative overflow-hidden"
                >
                  <div className="absolute top-0 left-0 w-full h-3 bg-emerald-500" />
                  
                  <div className="flex items-center justify-between mb-8">
                    <div className="flex items-center gap-2 bg-emerald-50 border border-emerald-100 px-4 py-1.5 rounded-full shadow-sm">
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping shrink-0" />
                      <span className="text-xs font-black text-emerald-600 uppercase tracking-widest">Logged successfully</span>
                    </div>
                    <span className="text-slate-400 font-mono text-[11px] font-bold">Checked in at {new Date().toLocaleTimeString()}</span>
                  </div>

                  <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6 sm:gap-8 w-full text-left">
                    <div className="shrink-0 relative">
                      {scannedStudent.profile_pic ? (
                         <img src={scannedStudent.profile_pic} alt={scannedStudent.name} className="w-28 h-28 sm:w-36 sm:h-36 rounded-2xl border-4 border-slate-50 object-cover shadow-lg" />
                      ) : (
                        <div className="w-28 h-28 sm:w-36 sm:h-36 rounded-2xl border-4 border-slate-50 bg-slate-100 flex items-center justify-center shadow-lg">
                           <User className="h-12 w-12 text-slate-400" />
                        </div>
                      )}
                    </div>
                    
                    <div className="text-center sm:text-left space-y-4 flex-1 w-full">
                      <div>
                        <h3 className="text-2xl sm:text-3xl font-black text-slate-800 tracking-tight leading-none uppercase">{scannedStudent.name}</h3>
                        <p className="text-orange-600 font-mono text-sm sm:text-base font-black uppercase mt-1">Roll No: {scannedStudent.roll_number || '---'}</p>
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 pt-4 border-t border-slate-100 font-bold uppercase tracking-wider text-[10px]">
                        <div className="bg-slate-50 p-3 rounded-xl border border-slate-100/80">
                          <span className="text-slate-400 block mb-0.5">Class / Current</span>
                          <span className="text-slate-700 text-xs font-black">{scannedStudent.current_class || 'Class N/A'}</span>
                        </div>
                        <div className="bg-slate-50 p-3 rounded-xl border border-slate-100/80">
                          <span className="text-slate-400 block mb-0.5">Batch Name</span>
                          <span className="text-slate-700 text-xs font-black">{scannedStudent.batch_id || 'N/A'}</span>
                        </div>
                        <div className="bg-slate-50 p-3 rounded-xl border border-slate-100/80 col-span-2 md:col-span-1">
                          <span className="text-slate-400 block mb-1">Fee Status</span>
                          { (() => {
                               const d = new Date();
                               const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
                               const currentMonth = monthNames[d.getMonth()];
                               const currentYear = d.getFullYear();
                               const payments = scannedStudent.payments || [];
                               const isPaid = payments.some((p: any) => (p.type === 'monthly' || p.type === 'admission') && p.month?.toLowerCase() === currentMonth.toLowerCase() && String(p.year || (p.date ? new Date(p.date).getFullYear() : "")) === String(currentYear));
                               return (
                                 <span className={`inline-block px-3 py-1.5 text-xs font-black rounded-lg w-full text-center ${isPaid ? "bg-emerald-100 text-emerald-700" : "bg-rose-100 text-rose-700 animate-pulse"}`}>
                                   {currentMonth.substring(0,3)}: {isPaid ? "PAID ✓" : "UNPAID!"}
                                 </span>
                               );
                          })()}
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-8 text-slate-300 font-bold bg-slate-900 border border-slate-800 px-4 py-3 rounded-xl uppercase text-[10px] tracking-widest flex items-center justify-center gap-2">
                     <span className="relative flex h-2 w-2 shrink-0">
                       <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                       <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                     </span>
                     <span>Attendance locked properly into Firestore index</span>
                  </div>
                </motion.div>
              ) : scanStatus === 'error' ? (
                <motion.div
                  key="error-scanned"
                  initial={{ opacity: 0, scale: 0.95, y: 30 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95, y: -30 }}
                  transition={{ type: "spring", damping: 25, stiffness: 180 }}
                  className="w-full bg-white border border-red-500/20 rounded-[2.5rem] p-8 flex flex-col items-center justify-center text-center shadow-2xl text-slate-800"
                >
                  <div className="w-20 h-20 bg-rose-50 flex items-center justify-center rounded-full mb-6 border border-rose-100 shadow-inner">
                    <AlertCircle className="h-10 w-10 text-rose-500" />
                  </div>
                  <h2 className="text-red-500 text-2xl font-black uppercase tracking-widest mb-2">Scan Failed</h2>
                  <p className="text-slate-400 font-bold text-xs max-w-sm mb-4 leading-relaxed">{statusMessage}</p>
                  <p className="text-[10px] text-slate-400 font-black uppercase tracking-wider bg-slate-50 border border-slate-100/80 px-4 py-2 rounded-full">Resuming in a few seconds...</p>
                </motion.div>
              ) : (
                <motion.div
                  key="idle-scanned"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="w-full bg-white/10 backdrop-blur-md rounded-[2.5rem] border border-white/20 p-8 flex flex-col items-center justify-center text-center min-h-[340px] shadow-lg text-white"
                >
                  <Scan className="h-16 w-16 text-orange-200 animate-pulse mb-4" />
                  <h3 className="text-2xl font-black text-white tracking-tight">WAITING FOR SWIPE</h3>
                  <p className="text-orange-100 font-bold tracking-widest uppercase text-xs mt-1.5 max-w-md leading-relaxed">Place Student ID card containing QR Code near the camera lens. The camera remains active continuously.</p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

        </div>

      </div>
    </div>
  );
};

export default BarcodeScanner;
