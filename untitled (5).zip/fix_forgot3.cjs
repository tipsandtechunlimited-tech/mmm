const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const regex = /app\.post\("\/api\/forgot-password\/request"[\s\S]*?app\.post\("\/api\/forgot-password\/verify"/;

const replacementStr = `app.post("/api/forgot-password/request", async (req, res) => {
    try {
      let { identifier, email } = req.body;
      const targetQuery = identifier || email;
      if (!targetQuery) {
        return res.status(400).json({ error: "Please provide your email, phone, or roll number." });
      }

      const cleanQuery = targetQuery.toLowerCase().trim();
      const originalQuery = targetQuery.trim();

      // Check if user exists in Firestore
      let userDoc = null;
      
      if (originalQuery.includes("@")) {
        let usersSnap = await db.collection("users").where("email", "==", cleanQuery).get();
        if (!usersSnap.empty) {
          userDoc = usersSnap.docs[0];
        } else {
          usersSnap = await db.collection("users").where("email", "==", originalQuery).get();
          if (!usersSnap.empty) userDoc = usersSnap.docs[0];
        }
      } else {
        let usersSnap = await db.collection("users").where("roll_number", "==", originalQuery).get();
        if (usersSnap.empty && !isNaN(Number(originalQuery))) {
          usersSnap = await db.collection("users").where("roll_number", "==", Number(originalQuery)).get();
        }
        if (usersSnap.empty) {
          usersSnap = await db.collection("users").where("phone", "==", originalQuery).get();
        }
        if (!usersSnap.empty) userDoc = usersSnap.docs[0];
      }

      // Check if enrolled user
      if (!userDoc) {
        return res.status(404).json({ error: "No student account found. Please ensure you are enrolled." });
      }
      
      const userData = userDoc.data();
      const targetEmail = userData.email;
      const cleanEmail = targetEmail.toLowerCase().trim();
      const uid = userDoc.id;

      // Generate a 6-digit verification code
      const verificationCode = Math.floor(100000 + Math.random() * 900000).toString();
      const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString(); // 10 minutes

      // Store reset info using lowercase email as key
      await db.collection("password_resets").doc(cleanEmail).set({
        code: verificationCode,
        expiresAt,
        uid,
      });

      // Send code via SMTP
      await sendSmtpEmail({
        to: cleanEmail,
        subject: "Password Reset Verification Code - JaberMath Care",
        db,
        html: \`
          <div style="font-family: sans-serif; padding: 25px; color: #333; line-height: 1.6; max-width: 500px; margin: 0 auto; border: 1px solid #e2e8f0; border-radius: 16px;">
            <h2 style="color: #ea580c; border-bottom: 2px solid #ffedd5; padding-bottom: 10px;">Reset Your Password</h2>
            <p>Dear Student / User,</p>
            <p>You requested a verification code to reset your password for your JaberMath Care account.</p>
            <div style="background-color: #fff7ed; border: 1px solid #ffedd5; border-radius: 12px; padding: 15px; margin: 20px 0; text-align: center;">
              <span style="font-family: monospace; font-size: 32px; font-weight: 900; color: #ea580c; letter-spacing: 0.1em;">\${verificationCode}</span>
            </div>
            <p style="color: #64748b; font-size: 13px;">This verification code is valid for <strong>10 minutes</strong>. If you did not make this request, please ignore other actions.</p>
            <p style="border-top: 1px solid #e2e8f0; padding-top: 15px; font-size: 12px; color: #94a3b8; text-align: center;">Thank you • JaberMath Care Team</p>
          </div>
        \`
      });

      res.json({ success: true, email: cleanEmail });
    } catch (error: any) {
      console.error("Forgot password request error:", error);
      res.status(500).json({ error: error.message || "Failed to process forgot password request" });
    }
  });

  app.post("/api/forgot-password/verify"`;

if(code.match(regex)) {
  code = code.replace(regex, replacementStr);
  fs.writeFileSync('server.ts', code);
  console.log("Rewrite forgot pass success");
} else {
  console.log("No match");
}
