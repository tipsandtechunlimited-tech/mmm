const fs = require('fs');

const path = 'src/pages/AdminDashboard.tsx';
let content = fs.readFileSync(path, 'utf8');

const tableSearchStr = `<div className="overflow-x-auto">
                        <table className="w-full text-left border-collapse">`;

const tableReplacementStr = `<div className="overflow-x-auto hidden lg:block">
                        <table className="w-full text-left border-collapse">`;

const mobileViewStr = `
                      <div className="block lg:hidden space-y-4 p-5">
                        {enrollments
                          .filter((enroll) => {
                            if (enrollmentStatusFilter !== "all" && enroll.status !== enrollmentStatusFilter) return false;
                            if (!enrollmentProgramFilter) return true;
                            const program = programs.find((p) => String(p.id) === String(enrollmentProgramFilter));
                            return enroll.program_title === program?.title || String(enroll.program_id) === String(enrollmentProgramFilter) || String(enroll.course_id) === String(enrollmentProgramFilter);
                          })
                          .map((enroll) => (
                            <div key={enroll.id} className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100 flex flex-col gap-4">
                              <div className="flex justify-between items-start gap-4">
                                <div>
                                  <div className="font-black text-slate-900 text-base">{enroll.name}</div>
                                  <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">Class: {enroll.current_class} • {enroll.phone}</div>
                                </div>
                                <span className={\`px-3 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest border \${enroll.status === "pending" ? "bg-amber-50 text-amber-600 border-amber-100" : "bg-emerald-50 text-emerald-600 border-emerald-100"}\`}>{enroll.status}</span>
                              </div>
                              <div className="py-3 border-y border-slate-50 flex flex-col gap-2">
                                <div className="flex justify-between items-center">
                                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Program / Course</span>
                                  <span className="text-sm font-black text-slate-800 text-right">{enroll.program_title || enroll.course_title}</span>
                                </div>
                                <div className="flex justify-between items-center">
                                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Fee</span>
                                  <span className="text-sm font-black text-orange-600">৳{enroll.fee}</span>
                                </div>
                                <div className="flex justify-between items-center">
                                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Type</span>
                                  <span className={\`px-3 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest border \${enroll.course_title ? "bg-blue-50 text-blue-600 border-blue-100" : "bg-purple-50 text-purple-600 border-purple-100"}\`}>{enroll.course_title ? "Online" : "Program"}</span>
                                </div>
                              </div>
                              <div className="flex justify-between items-center gap-2">
                                <div className="text-xs font-black text-slate-400 uppercase tracking-widest">{new Date(enroll.created_at).toLocaleDateString()}</div>
                                <div className="flex justify-end gap-2">
                                  <button onClick={() => setSelectedEnrollment(enroll)} className="p-2.5 rounded-xl bg-orange-50 text-orange-600 hover:bg-orange-600 hover:text-white transition-all shadow-sm"><Eye className="h-4 w-4" /></button>
                                  <button onClick={() => handleCancelEnrollment(enroll.id)} className="p-2.5 rounded-xl bg-red-50 text-red-600 hover:bg-red-600 hover:text-white transition-all shadow-sm"><X className="h-4 w-4" /></button>
                                </div>
                              </div>
                            </div>
                          ))}
                          {enrollments.length === 0 && (
                            <div className="p-10 text-center text-slate-400 italic font-medium bg-slate-50 rounded-2xl">
                              No enrollment applications found.
                            </div>
                          )}
                      </div>
`;

content = content.replace(tableSearchStr, mobileViewStr + tableReplacementStr);
fs.writeFileSync(path, content);
console.log('Enrollments updated');
