const fs = require('fs');

function updateDashboardNotices() {
  let file = 'src/pages/Dashboard.tsx';
  let code = fs.readFileSync(file, 'utf8');
  
  const targetRegex = /notices\s*\n\s*\.filter\(\(n: any\) => [^)]*\)\s*\n\s*\.slice\(/;
  const targetStr = code.match(/notices\s*\n\s*\.filter\(\(n: any\) => [^\n]*\n\s*\.slice\(/);
  
  const replacement = `notices
                .filter((n: any) => {
                  const audienceMatch = n.target_audience === 'all' || !n.target_audience || n.target_audience === data.user.student_type;
                  const hasSelection = n.batch_id || n.program_id || n.course_id;
                  
                  if (!hasSelection) return false;
                  
                  const matchesBatch = n.batch_id ? String(n.batch_id) === String(data.user.batch_id) : false;
                  const matchesProgram = n.program_id ? String(n.program_id) === String(data.user.program_id) : false;
                  const matchesCourse = n.course_id ? (data.user.enrolled_courses || []).includes(n.course_id) : false;
                  
                  return audienceMatch && (matchesBatch || matchesProgram || matchesCourse);
                })
                .slice(`;

  if (targetStr) {
    code = code.replace(targetStr[0], replacement);
    fs.writeFileSync(file, code);
  } else {
    // try a broader replace
    code = code.replace(/notices\s*\n\s*\.filter\(\(n: any\) => n\.target_audience === 'all' \|\| !n\.target_audience \|\| n\.target_audience === data\.user\.student_type\)\s*\n\s*\.slice\(/, replacement);
    fs.writeFileSync(file, code);
  }
}

function updatePublicNotices() {
  let file = 'src/pages/Notices.tsx';
  let code = fs.readFileSync(file, 'utf8');
  
  const replacement = `const filteredNotices = notices.filter(notice => {
    // Only show public notices (no specific batch/program/course)
    const isPublic = !notice.batch_id && !notice.program_id && !notice.course_id;
    if (!isPublic) return false;

    if (activeTab === 'all') return true;
    const audience = notice.target_audience?.toLowerCase();
    if (activeTab === 'academic') return audience === 'academic' || audience === 'offline';
    return audience === 'online';
  });`;
  
  code = code.replace(/const filteredNotices = notices\.filter\(notice => \{[\s\S]*?\}\);/, replacement);
  fs.writeFileSync(file, code);
}

try {
  updateDashboardNotices();
  updatePublicNotices();
  console.log("Updated notices filtering");
} catch(e) {
  console.log(e);
}
