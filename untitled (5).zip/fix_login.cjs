const fs = require('fs');
let code = fs.readFileSync('src/pages/Login.tsx', 'utf8');

const targetStr = `      let email = forgotEmail.trim();
      if (!email.includes('@')) {
        const usersRef = collection(db, 'users');
        let querySnapshot = await getDocs(query(usersRef, where('roll_number', '==', email), limit(1)));
        if (querySnapshot.empty && !isNaN(Number(email))) {
          querySnapshot = await getDocs(query(usersRef, where('roll_number', '==', Number(email)), limit(1)));
        }
        if (querySnapshot.empty) {
          querySnapshot = await getDocs(query(usersRef, where('phone', '==', email), limit(1)));
        }
        if (!querySnapshot.empty) {
          email = querySnapshot.docs[0].data().email;
        } else {
          throw new Error('No account found with this email, roll or phone number.');
        }
      }`;
const replaceStr = `      let identifier = forgotEmail.trim();`;

code = code.replace(targetStr, replaceStr);
code = code.replace(/body: JSON\.stringify\(\{ email \}\)/, "body: JSON.stringify({ identifier })");

fs.writeFileSync('src/pages/Login.tsx', code);
