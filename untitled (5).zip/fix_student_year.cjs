const fs = require('fs');
let code = fs.readFileSync('src/pages/AdminDashboard.tsx', 'utf8');

code = code.replace(/admission_month: \[\s*"January",\s*"February",\s*"March",\s*"April",\s*"May",\s*"June",\s*"July",\s*"August",\s*"September",\s*"October",\s*"November",\s*"December",?\s*\]\[new Date\(\)\.getMonth\(\)\],/g, 'admission_month: MONTHS[new Date().getMonth()],\n    admission_year: new Date().getFullYear().toString(),');

// Also in editStudentData let's add admission_year if not there
code = code.replace(/admission_month: "",/g, 'admission_month: "",\n    admission_year: "",');

// Add select inputs
const newStudentSelect = `                              <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                                Admission Year
                              </label>
                              <select
                                className="glass-select"
                                value={newStudent.admission_year || ""}
                                onChange={(e) =>
                                  setNewStudent((prev) => ({
                                    ...prev,
                                    admission_year: e.target.value,
                                  }))
                                }
                              >
                                {Array.from({ length: 11 }, (_, i) => new Date().getFullYear() - 5 + i).map(year => (
                                  <option key={year} value={year}>{year}</option>
                                ))}
                              </select>`;

code = code.replace(/<label className="text-\[10px\] font-black uppercase tracking-widest text-slate-400 ml-4">\s*Admission Month\s*<\/label>\s*<select\s*className="glass-select"\s*value=\{newStudent\.admission_month \|\| ""\}\s*onChange=\{\(e\) =>\s*setNewStudent\(\(prev\) => \(\{\s*\.\.\.prev,\s*admission_month: e\.target\.value,\s*\}\)\)\s*\}\s*>\s*<option value="">Select Month<\/option>\s*\{MONTHS\.map\(\(m\) => \(\s*<option key=\{m\} value=\{m\}>\s*\{m\}\s*<\/option>\s*\)\)\}\s*<\/select>/, match => match + '\n' + newStudentSelect);

const editStudentSelect = `                              <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">
                                Admission Year
                              </label>
                              <select
                                className="glass-select"
                                value={editStudentData.admission_year || ""}
                                onChange={(e) =>
                                  setEditStudentData({
                                    ...editStudentData,
                                    admission_year: e.target.value,
                                  })
                                }
                              >
                                <option value="">Select Year</option>
                                {Array.from({ length: 11 }, (_, i) => new Date().getFullYear() - 5 + i).map(year => (
                                  <option key={year} value={year}>{year}</option>
                                ))}
                              </select>`;

code = code.replace(/<label className="text-\[10px\] font-black uppercase tracking-widest text-slate-400 ml-4">\s*Admission Month\s*<\/label>\s*<select\s*className="glass-select"\s*value=\{editStudentData\.admission_month \|\| ""\}\s*onChange=\{\(e\) =>\s*setEditStudentData\(\{\s*\.\.\.editStudentData,\s*admission_month: e\.target\.value,\s*\}\)\s*\}\s*>\s*<option value="">Select Month<\/option>\s*\{MONTHS\.map\(\(m\) => \(\s*<option key=\{m\} value=\{m\}>\s*\{m\}\s*<\/option>\s*\)\)\}\s*<\/select>/, match => match + '\n' + editStudentSelect);


fs.writeFileSync('src/pages/AdminDashboard.tsx', code);
console.log('done fixing student limits');
