const fs = require('fs');

let progPath = 'src/pages/Programs.tsx';
let content = fs.readFileSync(progPath, 'utf8');

// I need to extract the entire image block:
// {/* Program Image section moved above enroll button per user request */}
// ...
// </div>

const imageStartStr = `{/* Program Image section moved above enroll button per user request */}`;
const imageBlockRegex = /\{\/\* Program Image section moved above enroll button per user request \*\/\}[\s\S]*?<\/div>(\s*<div className="flex flex-col sm:flex-row items-center)/;

const match = content.match(imageBlockRegex);
if (match) {
  // Wait, the "flex flex-col sm:flex-row" is the footer. 
  // We want to pull JUST the image block out.
  // The image block is:
  // <div className="h-64 md:h-72 ... border ... shadow-inner">
  //   {course.image_url ? ... : ... }
  // </div>
  
  // Actually, string manipulation is safer.
  const strStart = `{/* Program Image section moved above enroll button per user request */}`;
  
  // It's inside className="p-8 md:p-12 space-y-8 flex-1 flex flex-col justify-between"
  // Let's replace the whole card's JSX structure manually using Regex replacements.
  
  let newContent = content.replace(
    /<div className="p-8 md:p-12 space-y-8 flex-1 flex flex-col justify-between">([\s\S]*?)>(\s*)\{\/\* Program Image section moved above enroll button per user request \*\/\}[\s\S]*?<div className="h-64 md:h-72 bg-slate-100 relative overflow-hidden rounded-3xl mx-\[-1rem\] md:mx-0 shadow-inner">([\s\S]*?)<\/div>\s*\{\/\* Footer Section/g,
    (match, detailsPart, space, imagePart) => {
        // detailsPart contains the Leka section
        // imagePart contains the inside of the image div
        return `<div className="h-64 md:h-72 bg-slate-100 relative overflow-hidden">${imagePart}</div>\n                    <div className="p-8 md:p-12 space-y-8 flex-1 flex flex-col justify-between">${detailsPart}                  {/* Footer Section`;
    }
  );
  
  fs.writeFileSync(progPath, newContent);
  console.log("Replaced successfully using precise capture groups.");
}
