const fs = require('fs');
const readline = require('readline');
const { execSync } = require('child_process');

try {
  execSync('npm install adm-zip --no-save');
  const AdmZip = require('adm-zip');
  const zip = new AdmZip('temp_git_import/jaber-math-care-2.zip');
  zip.extractAllTo('temp_git_import/extracted', true);
  console.log('Extraction complete');
} catch (e) {
  console.error(e);
}
