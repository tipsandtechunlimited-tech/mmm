const fs = require('fs');

let code = fs.readFileSync('src/pages/AdminDashboard.tsx', 'utf8');

const selectBlock_web_recorded = `
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                      <div className="space-y-3">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          Program
                        </label>
                        <select
                          className="glass-select w-full border-2 border-orange-100 focus:border-orange-500"
                          value={newWebRecordedClass.program_id}
                          onChange={(e) =>
                            setNewWebRecordedClass((prev) => ({
                              ...prev,
                              program_id: e.target.value,
                              batch_id: "",
                              course_id: "", // Exclusive selectivity
                            }))
                          }
                        >
                          <option value="">Select Program</option>
                          {programs.map((p) => (
                            <option key={p.id} value={p.id}>
                              {p.title}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div className="space-y-3">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          Batch (Offline)
                        </label>
                        <select
                          className="glass-select w-full border-2 border-orange-100 focus:border-orange-500"
                          value={newWebRecordedClass.batch_id}
                          onChange={(e) =>
                            setNewWebRecordedClass((prev) => ({
                              ...prev,
                              batch_id: e.target.value,
                            }))
                          }
                        >
                          <option value="">Select Batch (Offline)</option>
                          {newWebRecordedClass.program_id && (
                            <option
                              value="all"
                              className="font-black text-orange-600"
                            >
                              ALL BATCHES
                            </option>
                          )}
                          {getFilteredBatches(newWebRecordedClass.program_id).map(
                            (b) => (
                              <option key={b.id} value={b.id}>
                                {b.name}
                              </option>
                            ),
                          )}
                        </select>
                      </div>
                      <div className="space-y-3">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                          Course (Online)
                        </label>
                        <select
                          className="glass-select w-full border-2 border-orange-100 focus:border-orange-500"
                          value={newWebRecordedClass.course_id}
                          onChange={(e) =>
                            setNewWebRecordedClass((prev) => ({
                              ...prev,
                              course_id: e.target.value,
                              program_id: "",
                              batch_id: "",
                            }))
                          }
                        >
                          <option value="">Select Course (Online)</option>
                          {courses.map((c) => (
                            <option key={c.id} value={c.id}>
                              {c.title}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>`;

const targetRegex = /value=\{newWebRecordedClass\.url\}\s*onChange=\{\(e\) =>\s*setNewWebRecordedClass\(\{\s*\.\.\.newWebRecordedClass,\s*url: e\.target\.value,\s*\}\)\s*\}\s*required\s*\/>\s*<\/div>\s*<\/div>/;

if (targetRegex.test(code)) {
    code = code.replace(targetRegex, match => match + '\n' + selectBlock_web_recorded);
    console.log("Successfully injected select block for Web Recorded.");
} else {
    console.log("Target not found for Web Recorded.");
}

fs.writeFileSync('src/pages/AdminDashboard.tsx', code);
