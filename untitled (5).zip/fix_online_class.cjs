const fs = require('fs');
let code = fs.readFileSync('src/pages/OnlineCourses.tsx', 'utf8');

code = code.replace(/course_title: selectedCourse\.title,\s*student_type: 'online',\s*\/\/\s*Mark as online student/,
  `course_title: selectedCourse.title,
          student_type: 'online', // Mark as online student
          current_class: selectedCourse.target_audience || selectedCourse.class || "",
          class: selectedCourse.target_audience || selectedCourse.class || "",`);
        
fs.writeFileSync('src/pages/OnlineCourses.tsx', code);
