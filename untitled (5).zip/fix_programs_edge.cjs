const fs = require('fs');
let progPath = 'src/pages/Programs.tsx';
let progContent = fs.readFileSync(progPath, 'utf8');

const lines = progContent.split('\n');

let imageStartIdx = -1;
let imageEndIdx = -1;
let imageDivLevels = 0;

for(let i=0; i<lines.length; i++) {
  if(lines[i].includes('{/* Program Image section moved above enroll button per user request */}')) {
    imageStartIdx = i;
    imageDivLevels = 0;
  }
  if (imageStartIdx !== -1 && imageEndIdx === -1) {
    if (lines[i].includes('<div')) imageDivLevels += (lines[i].match(/<div/g) || []).length;
    if (lines[i].includes('</div')) imageDivLevels -= (lines[i].match(/<\/div/g) || []).length;
    
    if (i > imageStartIdx && imageDivLevels <= 0 && lines[i].includes('</div>')) {
       imageEndIdx = i;
    }
  }
}

if (imageStartIdx !== -1 && imageEndIdx !== -1) {
  const imageBlock = lines.splice(imageStartIdx, imageEndIdx - imageStartIdx + 1);
  
  // Find className="bg-white rounded-[2rem] shadow-2xl overflow-hidden...
  // The line usually looks like:
  // className="bg-white rounded-[2rem] shadow-2xl overflow-hidden border border-slate-100 transition-all duration-500 hover:translate-y-[-6px] flex flex-col hover:shadow-orange-500/10"
  // >
  
  let targetIdx = -1;
  let flexDivIdx = -1;
  for(let i=0; i<lines.length; i++) {
    if (lines[i].includes('className="bg-white rounded-[2rem] shadow-2xl overflow-hidden')) {
      targetIdx = i;
    }
    if (targetIdx !== -1 && i > targetIdx && lines[i].trim() === '>') {
      flexDivIdx = i + 1;
      break;
    }
  }
  
  if (flexDivIdx !== -1) {
    // Remove the negative margins and rounded-3xl from the image block to make it square at the bottom and edge-to-edge
    for(let j=0; j<imageBlock.length; j++) {
       if (imageBlock[j].includes('className="h-64 md:h-72 bg-slate-100 relative overflow-hidden')) {
           imageBlock[j] = imageBlock[j].replace('rounded-3xl mx-[-1rem] md:mx-0 shadow-inner', '');
       }
    }
    lines.splice(flexDivIdx, 0, ...imageBlock);
    fs.writeFileSync(progPath, lines.join('\n'));
    console.log('Moved image to the absolute top of the card edge-to-edge');
  }
}

