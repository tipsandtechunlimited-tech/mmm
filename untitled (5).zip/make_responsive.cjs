const fs = require('fs');

const path = 'src/pages/AdminDashboard.tsx';
let content = fs.readFileSync(path, 'utf8');

// Replace all instances of 'hidden xl:block' with 'hidden lg:block' (for tables)
// Replace all instances of 'xl:hidden' with 'lg:hidden' (for mobile cards)
// Or wait, if we want tablets to see cards, we want the cards visible on tablet (md), and tables hidden on tablet (lg might mean >=1024, tablet is 768px-1023px, so md is tablet).
// Tailwind constraints:
// sm: 640px
// md: 768px (Tablet)
// lg: 1024px
// To show cards on Tablet (<1024px), we should hide table on <1024px (`hidden lg:block`) and show cards on <1024px (`block lg:hidden`).
// If we use xl (1280px), we hide table on <1280px and show cards up to laptop...
// Let's standardise the user's requested tabs to use 'hidden xl:block' for tables and 'block xl:hidden' for cards? Or 'lg:block' and 'lg:hidden'?
// "tablet a card akare dekabe" => tablet should show as card. Table should only show on desktop (lg or xl). lg (1024) is a small laptop, xl (1280) is typical desktop. 'lg' is usually sufficient to avoid scrollbars for tables, and 'md' (tablet) will see the card.

content = content.replace(/hidden xl:block/g, 'hidden lg:block');
content = content.replace(/xl:hidden/g, 'lg:hidden');

content = content.replace(/hidden md:block/g, 'hidden lg:block');
content = content.replace(/md:hidden/g, 'lg:hidden');

// We also need to check if there are sections that don't have a mobile card view at all!
fs.writeFileSync(path, content);
console.log('Responsive classes updated');
