const fs = require('fs');
let code = fs.readFileSync('src/pages/AdminDashboard.tsx', 'utf8');

code = code.replace(/const \[newWebRecordedClass, setNewWebRecordedClass\] = useState\(\{[\s\S]*?\}\);/,
`const [newWebRecordedClass, setNewWebRecordedClass] = useState({
    title: "",
    url: "",
    description: "",
    playlist: "",
  });`
);

code = code.replace(/const \[newVideoClass, setNewVideoClass\] = useState\(\{[\s\S]*?\}\);/,
`const [newVideoClass, setNewVideoClass] = useState({
    title: "",
    youtube_id: "",
    program_id: "",
    batch_id: "",
    course_id: "",
    description: "",
    playlist: "",
  });`
);

fs.writeFileSync('src/pages/AdminDashboard.tsx', code);
