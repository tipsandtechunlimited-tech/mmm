import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import admin from "firebase-admin";
import { getFirestore } from "firebase-admin/firestore";
import fs from "fs";
import { sendSmtpEmail, sendAutosms } from "./messaging";

// Initialize Firebase Admin
const configPath = path.join(process.cwd(), "firebase-applet-config.json");
const firebaseConfig = JSON.parse(fs.readFileSync(configPath, "utf-8"));

if (!admin.apps.length) {
  admin.initializeApp({
    projectId: firebaseConfig.projectId,
  });
  console.log(
    `Firebase Admin initialized for project: ${firebaseConfig.projectId}`,
  );
}

let db: admin.firestore.Firestore;
try {
  const dbId =
    firebaseConfig.firestoreDatabaseId &&
    firebaseConfig.firestoreDatabaseId !== "(default)"
      ? firebaseConfig.firestoreDatabaseId
      : undefined;

  if (dbId) {
    console.log("Using named database:", dbId);
    db = getFirestore(admin.app(), dbId);
  } else {
    console.log("Using default database");
    db = getFirestore(admin.app());
  }

  // Test connection
  db.collection("test")
    .doc("connection")
    .set(
      {
        last_verified: new Date().toISOString(),
      },
      { merge: true },
    )
    .then(async () => {
      console.log("Firestore connection verified.");
      try {
        const emailDoc = await db
          .collection("settings")
          .doc("smtp_email")
          .get();
        const passDoc = await db
          .collection("settings")
          .doc("smtp_password")
          .get();

        console.log(
          "[SMTP Boot Check] Loaded on startup - smtp_email:",
          emailDoc.exists ? emailDoc.data()?.value : "NOT SET",
        );
        console.log(
          "[SMTP Boot Check] Loaded on startup - smtp_password length:",
          passDoc.exists
            ? String(passDoc.data()?.value || "").length
            : "NOT SET",
        );

        const targetEmail = "jaberbhai69@gmail.com";
        const targetPassValue = "qkecrqatjnkmfurs";

        if (!emailDoc.exists) {
          await db
            .collection("settings")
            .doc("smtp_email")
            .set({ value: targetEmail }, { merge: true });
          console.log(
            "[SMTP Init] Auto-configured smtp_email to jaberbhai69@gmail.com",
          );
        }
        if (!passDoc.exists) {
          await db
            .collection("settings")
            .doc("smtp_password")
            .set({ value: targetPassValue }, { merge: true });
          console.log(
            "[SMTP Init] Auto-configured smtp_password key to qkecrqatjnkmfurs",
          );
        }
      } catch (e: any) {
        console.error(
          "[SMTP Init] Failed to auto-configure SMTP settings:",
          e.message,
        );
      }
    })
    .catch((err) => console.warn("Firestore test failed:", err.message));
} catch (error) {
  console.error("Critical error initializing Firestore SDK:", error);
  db = admin.firestore();
}

// Cascading delete helper functions
async function deleteStudentData(studentId: string) {
  try {
    const payments = await db
      .collection("payments")
      .where("student_id", "==", studentId)
      .get();
    for (const doc of payments.docs) {
      await doc.ref.delete().catch(() => {});
    }
  } catch (e) {
    console.error("Failed to delete payments for student:", studentId, e);
  }

  try {
    const attendance = await db
      .collection("attendance")
      .where("student_id", "==", studentId)
      .get();
    for (const doc of attendance.docs) {
      await doc.ref.delete().catch(() => {});
    }
  } catch (e) {
    console.error("Failed to delete attendance for student:", studentId, e);
  }

  try {
    const results = await db
      .collection("results")
      .where("student_id", "==", studentId)
      .get();
    for (const doc of results.docs) {
      await doc.ref.delete().catch(() => {});
    }
  } catch (e) {
    console.error("Failed to delete results for student:", studentId, e);
  }

  try {
    const enrollments = await db
      .collection("enrollments")
      .where("user_id", "==", studentId)
      .get();
    for (const doc of enrollments.docs) {
      await doc.ref.delete().catch(() => {});
    }
  } catch (e) {
    console.error("Failed to delete enrollments for student:", studentId, e);
  }
}

async function deleteBatchData(batchId: string) {
  try {
    const students = await db
      .collection("users")
      .where("batch_id", "==", batchId)
      .get();
    for (const doc of students.docs) {
      try {
        await admin
          .auth()
          .deleteUser(doc.id)
          .catch(() => {});
        await deleteStudentData(doc.id);
        await doc.ref.delete();
      } catch (e) {
        console.error(
          "Failed to recursively delete student under batch:",
          doc.id,
          e,
        );
      }
    }

    const students2 = await db
      .collection("users")
      .where("batch_id_2", "==", batchId)
      .get();
    for (const doc of students2.docs) {
      try {
        await admin
          .auth()
          .deleteUser(doc.id)
          .catch(() => {});
        await deleteStudentData(doc.id);
        await doc.ref.delete();
      } catch (e) {
        console.error(
          "Failed to recursively delete student_2 under batch:",
          doc.id,
          e,
        );
      }
    }
  } catch (e) {
    console.error(
      "Failed to process student deletion under batch:",
      batchId,
      e,
    );
  }

  try {
    const exams = await db
      .collection("exams")
      .where("batch_id", "==", batchId)
      .get();
    for (const doc of exams.docs) {
      try {
        const results = await db
          .collection("results")
          .where("exam_id", "==", doc.id)
          .get();
        for (const rDoc of results.docs) {
          await rDoc.ref.delete().catch(() => {});
        }
        await doc.ref.delete().catch(() => {});
      } catch (examErr) {
        console.error(
          "Failed to cascade delete exam results:",
          doc.id,
          examErr,
        );
      }
    }
  } catch (e) {
    console.error("Failed to process exams under batch:", batchId, e);
  }

  const batchIdColls = [
    "attendance",
    "payments",
    "live_classes",
    "notices",
    "video_classes",
    "class_slides",
    "routines",
  ];
  for (const col of batchIdColls) {
    try {
      const items = await db
        .collection(col)
        .where("batch_id", "==", batchId)
        .get();
      for (const doc of items.docs) {
        await doc.ref.delete().catch(() => {});
      }
    } catch (e) {
      console.error(
        `Failed to delete col ${col} items under batch ${batchId}:`,
        e,
      );
    }
  }
}

async function deleteProgramData(programId: string) {
  try {
    const batches = await db
      .collection("batches")
      .where("program_id", "==", programId)
      .get();
    for (const doc of batches.docs) {
      await deleteBatchData(doc.id);
      await doc.ref.delete().catch(() => {});
    }
  } catch (e) {
    console.error(
      "Failed to process batches cascading deletion under program:",
      programId,
      e,
    );
  }

  try {
    const students = await db
      .collection("users")
      .where("program_id", "==", programId)
      .get();
    for (const doc of students.docs) {
      try {
        await admin
          .auth()
          .deleteUser(doc.id)
          .catch(() => {});
        await deleteStudentData(doc.id);
        await doc.ref.delete();
      } catch (e) {
        console.error(
          "Failed to recursively delete student under program:",
          doc.id,
          e,
        );
      }
    }
  } catch (e) {
    console.error("Failed to process students under program:", programId, e);
  }
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  // Basic Security Headers to prevent hacking/inspection
  app.use((req, res, next) => {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("X-Frame-Options", "SAMEORIGIN");
    res.setHeader("X-XSS-Protection", "1; mode=block");
    res.setHeader(
      "Strict-Transport-Security",
      "max-age=31536000; includeSubDomains",
    );
    next();
  });

  // Disable caching globally for all routes
  app.use((req, res, next) => {
    res.set(
      "Cache-Control",
      "no-store, no-cache, must-revalidate, proxy-revalidate",
    );
    res.set("Pragma", "no-cache");
    res.set("Expires", "0");
    res.set("Surrogate-Control", "no-store");
    next();
  });

  // Middleware to verify Firebase ID Token
  const authenticate = async (req: any, res: any, next: any) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      console.log(
        `[AUTH] Missing or invalid Authorization header from ${req.method} ${req.url}`,
      );
      return res
        .status(401)
        .json({
          error: "Unauthorized",
          details: "Missing Authorization header",
        });
    }
    const idToken = authHeader.split("Bearer ")[1];
    try {
      // Use the default admin app for verification
      const decodedToken = await admin.auth().verifyIdToken(idToken);
      const email = (decodedToken.email || "").toLowerCase();
      console.log(`[AUTH] Authenticated: ${email}`);
      req.user = decodedToken;

      const adminEmails = [
        "jabermathcare@gmail.com",
        "contact.jabermathcare@gmail.com",
        "mdabudarda2012@gmail.com",
        "tipsandtechunlimited@gmail.com"
      ].map((e) => e.toLowerCase());

      if (adminEmails.includes(email)) {
        req.user.role = "admin";
      } else {
        const userDoc = await db.collection("users").doc(decodedToken.uid).get();
        if (userDoc.exists) {
          const role = userDoc.data()?.role;
          if (role === "admin" || role === "moderator") {
            req.user.role = role;
          } else {
            req.user.role = "student";
          }
        } else {
          req.user.role = "student";
        }
      }
      next();
    } catch (error: any) {
      console.error(`[AUTH] Error verifying token:`, error.message);
      res.status(401).json({ error: "Unauthorized", details: error.message });
    }
  };

  // API Routes

  // Diagnostic
  app.get("/api/admin/debug-auth", authenticate, (req: any, res) => {
    res.json({
      user: req.user,
      firebaseProjectId: admin.app().options.projectId,
      configProjectId: firebaseConfig.projectId,
    });
  });

  // Migration Route
  app.get("/migrate-results", async (req: any, res) => {
    try {
      const snapshot = await db.collection("results").get();
      let migrated = 0;
      for (const resultDoc of snapshot.docs) {
        const data = resultDoc.data();
        if (!data.roll_number || !data.student_name) {
          if (data.student_id) {
            const studentDoc = await db
              .collection("users")
              .doc(data.student_id)
              .get();
            if (studentDoc.exists) {
              await resultDoc.ref.update({
                roll_number: studentDoc.data()?.roll_number || "",
                student_name: studentDoc.data()?.name || "",
              });
              migrated++;
            }
          }
        }
      }
      res.json({ success: true, migrated });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.get("/api/my-enrollments", authenticate, async (req: any, res) => {
    try {
      const email = (req.user.email || "").toLowerCase();
      const phone = req.user.phone_number || "";

      // Get approved enrollments for this user
      const snapshot = await db
        .collection("enrollments")
        .where("user_id", "==", req.user.uid)
        .get();

      let enrollments: any[] = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));

      // Also search by email/phone if user_id is missing (legacy/virtual enrollments)
      if (email || phone) {
        let q: any = db.collection("enrollments");
        const legacySnapshot = await q.get();
        const extra = legacySnapshot.docs
          .map((doc: any) => ({ id: doc.id, ...doc.data() }))
          .filter(
            (e: any) =>
              !enrollments.find((existing) => existing.id === e.id) &&
              ((email && e.email?.toLowerCase() === email) ||
                (phone && e.phone === phone)),
          );
        enrollments = [...enrollments, ...extra];
      }

      // Deduplicate to show exactly one card per course/program/batch
      const uniqueEnrollments: any[] = [];
      for (const e of enrollments) {
        const isDuplicate = uniqueEnrollments.some((existing) => {
          if (e.course_id && existing.course_id && String(e.course_id) === String(existing.course_id)) {
            return true;
          }
          if (e.program_id && existing.program_id && String(e.program_id) === String(existing.program_id)) {
            if (String(e.batch_id) === String(existing.batch_id)) {
              return true;
            }
          }
          return false;
        });

        if (!isDuplicate) {
          uniqueEnrollments.push(e);
        } else {
          // Keep the one with approved/contacted status if duplicate exists
          const idx = uniqueEnrollments.findIndex((existing) => {
            if (e.course_id && existing.course_id && String(e.course_id) === String(existing.course_id)) {
              return true;
            }
            if (e.program_id && existing.program_id && String(e.program_id) === String(existing.program_id)) {
              if (String(e.batch_id) === String(existing.batch_id)) {
                return true;
              }
            }
            return false;
          });
          if (idx !== -1) {
            const existing = uniqueEnrollments[idx];
            const activeStatuses = ["approved", "contacted"];
            const existingIsActive = activeStatuses.includes(existing.status);
            const currentIsActive = activeStatuses.includes(e.status);
            if (!existingIsActive && currentIsActive) {
              uniqueEnrollments[idx] = e;
            }
          }
        }
      }

      res.json(uniqueEnrollments);
    } catch (error) {
      console.error("Error fetching my-enrollments:", error);
      res.status(500).json({ error: "Failed to fetch enrollments" });
    }
  });

  // Auth Profile
  app.get("/api/auth/profile", authenticate, async (req: any, res) => {
    try {
      const userDoc = await db.collection("users").doc(req.user.uid).get();
      if (!userDoc.exists)
        return res.status(404).json({ error: "User not found" });
      const data = userDoc.data();
      if (
        req.user.email === "mdabudarda2012@gmail.com" &&
        data.role !== "student"
      ) {
        await db
          .collection("users")
          .doc(req.user.uid)
          .update({ role: "student" });
        data.role = "student";
      }
      res.json({ id: userDoc.id, ...data });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch profile" });
    }
  });

  // Messages
  app.get("/api/messages", authenticate, async (req, res) => {
    try {
      const snapshot = await db
        .collection("messages")
        .orderBy("created_at", "desc")
        .get();
      const messages = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      res.json(messages);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch messages" });
    }
  });

  // Settings
  app.get("/api/settings", async (req, res) => {
    try {
      const snapshot = await db.collection("settings").get();
      const settings: any = {};
      snapshot.forEach((doc) => {
        settings[doc.id] = doc.data().value;
      });
      res.json(settings);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: String(error) });
    }
  });

  app.get("/api/public/settings", async (req, res) => {
    try {
      const snapshot = await db.collection("settings").get();
      const settings: any = {};
      snapshot.forEach((doc) => {
        settings[doc.id] = doc.data().value;
      });
      res.json(settings);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: String(error) });
    }
  });

  app.get("/api/smtp-debug", async (req, res) => {
    try {
      const emailDoc = await db.collection("settings").doc("smtp_email").get();
      const passDoc = await db
        .collection("settings")
        .doc("smtp_password")
        .get();
      res.json({
        smtp_email_doc_exists: emailDoc.exists,
        smtp_email_value: emailDoc.exists ? emailDoc.data()?.value : null,
        smtp_password_doc_exists: passDoc.exists,
        smtp_password_value_length: passDoc.exists
          ? String(passDoc.data()?.value || "").length
          : 0,
        smtp_password_val_preview: passDoc.exists
          ? String(passDoc.data()?.value || "").substring(0, 3) + "..."
          : null,
      });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.get("/api/proxy-image", async (req, res) => {
    try {
      const url = req.query.url as string;
      if (!url) {
        return res.status(400).send("Missing url parameter");
      }
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`Failed to fetch image: ${response.statusText}`);
      }
      const contentType = response.headers.get("content-type") || "image/png";
      const buffer = await response.arrayBuffer();
      res.setHeader("Content-Type", contentType);
      res.setHeader("Cache-Control", "public, max-age=86400");
      res.send(Buffer.from(buffer));
    } catch (e: any) {
      console.error("Proxy image error:", e);
      res.status(500).send(e.message);
    }
  });

  app.post("/api/settings", authenticate, async (req, res) => {
    try {
      const { key, value } = req.body;
      if (!key) return res.status(400).json({ error: "Key is required" });

      let cleanValue = value;
      if (key === "smtp_password" && typeof value === "string") {
        cleanValue = value.replace(/\s+/g, "");
      } else if (key === "smtp_email" && typeof value === "string") {
        cleanValue = value.trim().toLowerCase();
      }

      await db
        .collection("settings")
        .doc(key)
        .set({ value: cleanValue }, { merge: true });
      res.json({ success: true, value: cleanValue });
    } catch (error) {
      console.error("Error saving settings:", error);
      res.status(500).json({ error: "Failed to save settings" });
    }
  });

  // Special handling for enrollments (public for guests)
  app.post("/api/enrollments", async (req, res) => {
    try {
      const sanitizeUrls = (obj: any) => {
        const parsed = { ...obj };
        for (const key of ["image_url", "profile_pic", "student_image"]) {
          if (
            typeof parsed[key] === "string" &&
            parsed[key].includes("drive.google.com")
          ) {
            const match = parsed[key].match(
              /drive\.google\.com\/file\/d\/([^\/]+)/,
            );
            if (match && match[1]) {
              parsed[key] =
                `https://drive.google.com/uc?export=view&id=${match[1]}`;
            }
          }
        }
        return parsed;
      };

      req.body = sanitizeUrls(req.body);
      const {
        email: rawEmail,
        gmail: rawGmail,
        password,
        phone,
        name,
        profile_pic,
        ...rest
      } = req.body;
      const email = rawEmail ? String(rawEmail).trim().toLowerCase() : "";
      const gmail = rawGmail ? String(rawGmail).trim().toLowerCase() : "";
      const userEmail = email || gmail;

      if (userEmail) {
        // Enforce 1 course per student (one email address = at most 1 user profile)
        const usersSnap = await db
          .collection("users")
          .where("email", "==", userEmail)
          .get();
        if (!usersSnap.empty) {
          return res.status(400).json({ error: "A student with this email address is already enrolled. Each student can only register for one course with one email address." });
        }

        // Also check if they already have an enrollment request
        const enrollSnap = await db
          .collection("enrollments")
          .where("email", "==", userEmail)
          .get();
        if (!enrollSnap.empty) {
          return res.status(400).json({ error: "An enrollment application with this email has already been submitted or processed. Each student can only register for one course." });
        }
      }

      let uid = null;

      if (userEmail && password) {
        // We no longer create the auth user or the `users` document immediately during enrollment submission.
        // It will be created ONLY when the admin approves the enrollment.
      }

      const enrollmentData = {
        ...req.body,
        email: email || undefined,
        gmail: gmail || undefined,
        user_id: uid,
        status: "pending",
        created_at: new Date().toISOString(),
      };

      const docRef = await db.collection("enrollments").add(enrollmentData);
      res.json({ id: docRef.id, ...enrollmentData });
    } catch (error) {
      console.error("Enrollment error:", error);
      res.status(500).json({ error: "Failed to process enrollment" });
    }
  });

  // Special handling for messages (public for guests)
  app.post("/api/messages", async (req, res) => {
    try {
      const data = { ...req.body, created_at: new Date().toISOString() };
      await db.collection("messages").add(data);
      
      // Dispatch email to admin asynchronously
      db.collection("settings").doc("smtp_email").get().then(doc => {
        const adminEmail = doc.exists ? doc.data()?.value : null;
        if (adminEmail) {
          sendSmtpEmail({
            to: adminEmail,
            subject: `New Contact Form Submission: ${data.subject || "No Subject"}`,
            html: `Name: ${data.name}<br>Email: ${data.email}<br>Phone: ${data.phone}<br>Class: ${data.current_class}<br>School: ${data.school_name}<br>College: ${data.college_name}<br><br>Message:<br>${data.message}`,
            db: db
          }).catch(err => console.error("Contact form email error:", err));
        }
      }).catch(err => console.error("Error fetching settings for contact email:", err));

      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to send message" });
    }
  });
  app.get("/api/students", authenticate, async (req, res) => {
    try {
      let query: any = db.collection("users").where("role", "==", "student");
      Object.keys(req.query).forEach((key) => {
        if (key !== "t") query = query.where(key, "==", req.query[key]);
      });
      const snapshot = await query.get();
      res.json(snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })));
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch students" });
    }
  });

  app.get("/api/students/:id", authenticate, async (req, res) => {
    try {
      const doc = await db.collection("users").doc(req.params.id).get();
      if (!doc.exists) return res.status(404).json({ error: "Not found" });
      let data: any = { id: doc.id, ...doc.data() };

      const [attendance, payments, results, enrollments] = await Promise.all([
        db.collection("attendance").where("student_id", "==", doc.id).get(),
        db.collection("payments").where("student_id", "==", doc.id).get(),
        db.collection("results").where("student_id", "==", doc.id).get(),
        db.collection("enrollments").where("user_id", "==", doc.id).get(),
      ]);

      data = {
        ...data,
        attendance: attendance.docs.map((d) => ({ id: d.id, ...d.data() })),
        payments: payments.docs.map((d) => ({ id: d.id, ...d.data() })),
        results: results.docs.map((d) => ({ id: d.id, ...d.data() })),
        enrolled_courses: enrollments.docs.map((d) => ({
          id: d.id,
          ...d.data(),
        })),
      };
      res.json(data);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch student details" });
    }
  });

  app.post("/api/students", authenticate, async (req, res) => {
    try {
      const sanitizeUrls = (obj: any) => {
        const parsed = { ...obj };
        for (const key of ["image_url", "profile_pic", "student_image"]) {
          if (
            typeof parsed[key] === "string" &&
            parsed[key].includes("drive.google.com")
          ) {
            const match = parsed[key].match(
              /drive\.google\.com\/file\/d\/([^\/]+)/,
            );
            if (match && match[1]) {
              parsed[key] =
                `https://drive.google.com/uc?export=view&id=${match[1]}`;
            }
          }
        }
        return parsed;
      };
      req.body = sanitizeUrls(req.body);
      const {
        email: rawEmail,
        password,
        name,
        enrollment_id,
        ...rest
      } = req.body;
      if (!rawEmail || !password)
        return res.status(400).json({ error: "Email and password required" });
      const email = String(rawEmail).trim().toLowerCase();

      // Enforce 1 course per student (one email address = at most 1 user profile)
      const usersSnap = await db
        .collection("users")
        .where("email", "==", email)
        .get();
      if (!usersSnap.empty) {
        return res.status(400).json({ error: "A student with this email address is already registered. Each student can only register for one course with a unique email address." });
      }

      let uid = "";
      try {
        const userRecord = await admin.auth().createUser({
          email: email,
          password,
          displayName: name,
        });
        uid = userRecord.uid;
      } catch (err: any) {
        const isAlreadyInUse =
          err.code === "auth/email-already-exists" ||
          err.code === "auth/email-already-in-use" ||
          String(err.message || "").includes("email-already-in-use") ||
          String(err.message || "").includes("email-already-exists") ||
          String(err.message || "").includes("already in use") ||
          String(err.message || "").includes("already exists");
        if (isAlreadyInUse) {
          const userRecord = await admin.auth().getUserByEmail(email);
          uid = userRecord.uid;
          await admin.auth().updateUser(uid, { password, displayName: name });
        } else {
          throw err;
        }
      }

      const userData = {
        ...rest,
        name,
        email: email,
        gmail: email,
        role: "student",
        status: "approved",
        initial_password: password,
        created_at:
          rest.created_at ||
          rest.admission_date ||
          rest.date_of_admission ||
          new Date().toISOString(),
      };
      await db.collection("users").doc(uid).set(userData, { merge: true });

      // Automatically record initial payment as admission fee if paid_amount is provided
      const paidAmountNum = Number(rest.paid_amount || 0);
      if (paidAmountNum > 0) {
        let batchName = "";
        let programId = rest.program_id || "";
        if (rest.batch_id) {
          try {
            const batchDoc = await db
              .collection("batches")
              .doc(rest.batch_id)
              .get();
            if (batchDoc.exists) {
              batchName = batchDoc.data()?.name || "";
              if (!programId) {
                programId = batchDoc.data()?.program_id || "";
              }
            }
          } catch (batchErr) {
            console.warn(
              "Failed to fetch batch details for payment record:",
              batchErr,
            );
          }
        }

        const now = new Date();
        const paymentDoc = {
          amount: paidAmountNum,
          type: "admission",
          date: now.toISOString().split("T")[0],
          month:
            rest.admission_month ||
            now.toLocaleString("en-US", { month: "long" }),
          year: rest.admission_year || now.getFullYear().toString(),
          status: "approved",
          student_id: uid,
          student_name: name,
          roll_number: rest.roll_number || "",
          batch_id: rest.batch_id || "",
          batch_name: batchName,
          program_id: programId,
          email: email.trim(),
          phone: rest.phone || "",
          payment_method: "Cash",
          method: "Cash",
          created_at: now.toISOString(),
        };
        try {
          await db.collection("payments").add(paymentDoc);
        } catch (paymentErr) {
          console.error("Failed to auto-record admission payment:", paymentErr);
        }
      }

      if (enrollment_id) {
        try {
          await db.collection("enrollments").doc(enrollment_id).update({
            status: "approved",
            user_id: uid,
          });
        } catch (e) {
          console.warn("Failed to update enrollment:", e);
        }
      }

      // Dispatch welcome email via SMTP
      if (email && email.trim()) {
        try {
          await sendSmtpEmail({
            to: email.trim(),
            subject: "Admission Completed Successfully - Jaber Math Care",
            db: db,
            html: `
              <div style="font-family: sans-serif; padding: 20px; color: #333; line-height: 1.6;">
                <h2 style="color: #16a34a;">Welcome to Jaber Math Care!</h2>
                <p>Dear ${name || "Student"},</p>
                <p>Your admission for the program <strong>${rest.course_title || rest.program_title || "our course"}</strong> has been completed successfully.</p>
                <p>You can now log in to our portal using your registered email and password.</p>
                <div style="margin: 20px 0; padding: 15px; background: #f0fdf4; border-radius: 8px; border-left: 5px solid #16a34a;">
                  <p style="margin: 0;"><strong>Your Login Email:</strong> ${email.trim()}</p>
                  <p style="margin: 5px 0 0 0;"><strong>Your Password:</strong> ${password}</p>
                  ${rest.roll_number ? `<p style="margin: 5px 0 0 0;"><strong>Roll Number:</strong> ${rest.roll_number}</p>` : ""}
                  <p style="margin: 5px 0 0 0;"><strong>Program:</strong> ${rest.course_title || rest.program_title || "N/A"}</p>
                </div>
                <p>Best regards,<br/>Jaber Math Care Team</p>
              </div>
            `,
          });
        } catch (emailErr) {
          console.error("Failed to send welcome email to student:", emailErr);
        }
      }

      // Dispatch welcome SMS with batch name
      const phoneToNotify = (rest.phone || rest.guardian_phone || "").trim();
      if (phoneToNotify) {
        try {
          let batchNameStr = "";
          if (rest.batch_id) {
            const batchDoc = await db.collection("batches").doc(rest.batch_id).get();
            if (batchDoc.exists) {
              batchNameStr = batchDoc.data()?.name || "";
            }
          }
          const rollStr = rest.roll_number || "N/A";
          let smsMsg = `প্রিয় ${name || "শিক্ষার্থী"}, জাবর ম্যাথ কেয়ার-এ আপনার ভর্তি সম্পন্ন হয়েছে। `;
          if (batchNameStr) {
            smsMsg += `ব্যাচ: ${batchNameStr}। `;
          }
          smsMsg += `রোল: ${rollStr}। পাসওয়ার্ড: ${password}। অ্যাপে লগইন করুন।`;
          await sendAutosms(phoneToNotify, smsMsg, db);
          console.log(`[OFFLINE SMS DISPATCH] Sent welcome message to ${phoneToNotify} for batch "${batchNameStr}"`);
        } catch (smsErr: any) {
          console.error("[OFFLINE SMS ERROR]:", smsErr.message || smsErr);
        }
      }

      res.json({ id: uid, ...userData });
    } catch (error: any) {
      console.error("Error creating student:", error);
      res
        .status(500)
        .json({ error: error.message || "Failed to create student" });
    }
  });

  app.put("/api/students/:id", authenticate, async (req, res) => {
    try {
      const sanitizeUrls = (obj: any) => {
        const parsed = { ...obj };
        for (const key of ["image_url", "profile_pic", "student_image"]) {
          if (
            typeof parsed[key] === "string" &&
            parsed[key].includes("drive.google.com")
          ) {
            const match = parsed[key].match(
              /drive\.google\.com\/file\/d\/([^\/]+)/,
            );
            if (match && match[1]) {
              parsed[key] =
                `https://drive.google.com/uc?export=view&id=${match[1]}`;
            }
          }
        }
        return parsed;
      };

      const payload = sanitizeUrls(req.body);
      const { password, confirmPassword, ...updateData } = payload;

      if (updateData.email) {
        updateData.email = String(updateData.email).trim().toLowerCase();
        updateData.gmail = updateData.email;
      } else if (updateData.gmail) {
        updateData.gmail = String(updateData.gmail).trim().toLowerCase();
        updateData.email = updateData.gmail;
      }

      // If a new password is provided during update, update it in Auth
      if (password && password.length >= 6) {
        try {
          await admin.auth().updateUser(req.params.id, { password });
          updateData.initial_password = password; // Optional: keep record of latest password if they want
        } catch (authErr) {
          console.warn(
            "Could not update auth password for student update:",
            authErr,
          );
          // if user doesn't exist in auth, maybe create one?
          // usually they do, but if not we just ignore or log
        }
      }

      await db.collection("users").doc(req.params.id).update(updateData);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to update student" });
    }
  });

  app.delete("/api/students/:id", authenticate, async (req: any, res) => {
    if (req.user.role !== "admin")
      return res.status(403).json({ error: "Forbidden" });
    try {
      // Also delete from Auth if possible (optional but good)
      try {
        await admin.auth().deleteUser(req.params.id);
      } catch (e) {
        console.log(
          "User not in Auth or delete failed, proceeding with Firestore delete",
        );
      }
      await deleteStudentData(req.params.id);
      await db.collection("users").doc(req.params.id).delete();
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete student" });
    }
  });

  app.delete(
    "/api/cancel-enrollment/:id",
    authenticate,
    async (req: any, res) => {
      try {
        const enrollmentRef = db.collection("enrollments").doc(req.params.id);
        const enrollmentDoc = await enrollmentRef.get();
        if (!enrollmentDoc.exists)
          return res.status(404).json({ error: "Enrollment not found" });

        const enrollmentData = enrollmentDoc.data() as any;

        const userRef = await db.collection("users").doc(req.user.uid).get();
        const userData = userRef.exists ? userRef.data() : null;

        const isOwner =
          req.user.role === "admin" ||
          enrollmentData.user_id === req.user.uid ||
          (userData &&
            userData.email &&
            enrollmentData.email === userData.email) ||
          (userData &&
            userData.email &&
            enrollmentData.gmail === userData.email) ||
          (userData &&
            userData.phone &&
            enrollmentData.phone === userData.phone) ||
          (userData &&
            userData.phone &&
            enrollmentData.phone &&
            userData.phone.replace(/\\D/g, "").slice(-10) ===
              enrollmentData.phone.replace(/\\D/g, "").slice(-10));

        if (!isOwner) {
          return res.status(403).json({ error: "Forbidden" });
        }
        if (enrollmentData.status !== "pending" && req.user.role !== "admin") {
          return res
            .status(400)
            .json({ error: "Only pending enrollments can be cancelled" });
        }

        await enrollmentRef.delete();
        res.json({ success: true });
      } catch (error) {
        console.error("Error cancelling enrollment:", error);
        res.status(500).json({ error: "Failed to cancel application" });
      }
    },
  );

  app.delete("/api/moderators/:id", authenticate, async (req: any, res) => {
    if (req.user.role !== "admin")
      return res.status(403).json({ error: "Forbidden" });
    try {
      await db.collection("users").doc(req.params.id).delete();
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete moderator" });
    }
  });

  // Moderator CRUD
  app.get("/api/moderators", authenticate, async (req, res) => {
    try {
      const snapshot = await db
        .collection("users")
        .where("role", "==", "moderator")
        .get();
      res.json(snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })));
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch moderators" });
    }
  });

  app.post("/api/moderators", authenticate, async (req, res) => {
    try {
      const sanitizeUrls = (obj: any) => {
        const parsed = { ...obj };
        for (const key of ["image_url", "profile_pic", "student_image"]) {
          if (
            typeof parsed[key] === "string" &&
            parsed[key].includes("drive.google.com")
          ) {
            const match = parsed[key].match(
              /drive\.google\.com\/file\/d\/([^\/]+)/,
            );
            if (match && match[1]) {
              parsed[key] =
                `https://drive.google.com/uc?export=view&id=${match[1]}`;
            }
          }
        }
        return parsed;
      };
      req.body = sanitizeUrls(req.body);
      const { email, password, name, ...rest } = req.body;
      const userRecord = await admin.auth().createUser({
        email: email.trim(),
        password,
        displayName: name,
      });
      const userData = {
        ...rest,
        name,
        email: email.trim(),
        role: "moderator",
        created_at: new Date().toISOString(),
      };
      await db.collection("users").doc(userRecord.uid).set(userData);
      res.json({ id: userRecord.uid, ...userData });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Enrollment Status & Approval
  app.put("/api/enrollments/:id/status", authenticate, async (req, res) => {
    try {
      const { status, roll_number, monthly_fee, admission_fee, batch_id } =
        req.body;
      const enrollmentRef = db.collection("enrollments").doc(req.params.id);
      const enrollmentDoc = await enrollmentRef.get();

      if (!enrollmentDoc.exists)
        return res.status(404).json({ error: "Enrollment not found" });

      const enrollmentData = enrollmentDoc.data() || {};

      // Update enrollment status
      await enrollmentRef.update({
        status,
        updated_at: new Date().toISOString(),
        ...(roll_number && { roll_number }),
        ...(monthly_fee && { monthly_fee }),
        ...(admission_fee && { admission_fee }),
        ...(batch_id && { batch_id }),
        payment_generated: status === "approved" ? true : undefined,
      });

      // Sync with user record
      if (status === "approved") {
        let uid = enrollmentData.user_id;
        const userEmail = String(
          enrollmentData.email ||
            enrollmentData.gmail ||
            enrollmentData.email_address ||
            "",
        )
          .trim()
          .toLowerCase();

        // Try to find user by email if uid is missing or invalid
        if (!uid && userEmail) {
          const userSnap = await db
            .collection("users")
            .where("email", "==", userEmail)
            .limit(1)
            .get();
          if (!userSnap.empty) {
            uid = userSnap.docs[0].id;
            await enrollmentRef.update({ user_id: uid });
          }
        }

        const isOnline = !!(
          enrollmentData.course_id ||
          enrollmentData.course_title ||
          enrollmentData.student_type === "online"
        );

        const updatePayload: any = {
          status: "approved",
          role: "student",
          updated_at: new Date().toISOString(),
        };

        if (roll_number) updatePayload.roll_number = roll_number;
        if (monthly_fee) updatePayload.monthly_fee = String(monthly_fee);
        if (admission_fee) updatePayload.admission_fee = String(admission_fee);
        if (batch_id) updatePayload.batch_id = String(batch_id);
        updatePayload.student_type = isOnline ? "online" : "offline";
        if (enrollmentData.phone) updatePayload.phone = enrollmentData.phone;
        if (enrollmentData.guardian_phone) updatePayload.guardian_phone = enrollmentData.guardian_phone;
        if (enrollmentData.address) updatePayload.address = enrollmentData.address;
        if (enrollmentData.school_name) updatePayload.school_name = enrollmentData.school_name;
        if (enrollmentData.college_name) updatePayload.college_name = enrollmentData.college_name;
        if (enrollmentData.blood_group) updatePayload.blood_group = enrollmentData.blood_group;
        if (enrollmentData.current_class) {
          updatePayload.current_class = enrollmentData.current_class;
          updatePayload.class = enrollmentData.current_class;
        } else if (enrollmentData.class) {
          updatePayload.current_class = enrollmentData.class;
          updatePayload.class = enrollmentData.class;
        }
        if (enrollmentData.password) {
          updatePayload.initial_password = enrollmentData.password;
        }

        if (uid) {
          const userRef = db.collection("users").doc(uid);
          const userDoc = await userRef.get();
          if (userDoc.exists) {
            const currentData = userDoc.data();
            if (enrollmentData.course_id) {
              const enrolledCourses = currentData?.enrolled_courses || [];
              if (!enrolledCourses.includes(enrollmentData.course_id)) {
                enrolledCourses.push(enrollmentData.course_id);
              }
              updatePayload.enrolled_courses = enrolledCourses;
            }
            // Update auth password if available and they were pending
            if (currentData?.status === "pending" && enrollmentData.password) {
              try {
                await admin
                  .auth()
                  .updateUser(uid, { password: enrollmentData.password });
              } catch (e) {}
            }
            await userRef.update(updatePayload);
            
            // Auto generate a payment record so delete enrollment doesn't lose the money tracking!
            const feeVal = Number(enrollmentData.fee) || 0;
            if (feeVal > 0) {
              const currentMonthName = new Date().toLocaleString('default', { month: 'long' });
              const paymentRef = db.collection("payments").doc();
              await paymentRef.set({
                student_id: uid,
                student_name: updatePayload.name || enrollmentData.name || currentData?.name || "Unknown",
                roll_number: roll_number || enrollmentData.roll_number || currentData?.roll_number || "",
                amount: feeVal.toString(),
                date: new Date().toISOString().split("T")[0],
                type: "admission",
                month: currentMonthName,
                year: new Date().getFullYear().toString(),
                method: "online",
                created_at: new Date().toISOString()
              });
            }
          } else {
            // Recreate missing document
            await userRef.set({ ...enrollmentData, ...updatePayload });
          }
        } else if (userEmail) {
          // Create new user if not found
          const newUser = {
            ...enrollmentData,
            ...updatePayload,
            email: userEmail,
            student_type: isOnline ? "online" : "offline",
          };
          delete (newUser as any).id;
          try {
            const userRecord = await admin.auth().createUser({
              email: userEmail,
              password: enrollmentData.password || "Student@123",
              displayName: enrollmentData.name,
            });
            uid = userRecord.uid;
          } catch (authErr: any) {
            const isAlreadyInUse =
              authErr.code === "auth/email-already-exists" ||
              authErr.code === "auth/email-already-in-use" ||
              String(authErr.message || "").includes("email-already-in-use") ||
              String(authErr.message || "").includes("email-already-exists") ||
              String(authErr.message || "").includes("already in use") ||
              String(authErr.message || "").includes("already exists");
            if (isAlreadyInUse) {
              const existing = await admin.auth().getUserByEmail(userEmail);
              uid = existing.uid;
            } else {
              uid = db.collection("users").doc().id;
            }
          }
          await db.collection("users").doc(uid).set(newUser, { merge: true });
          await enrollmentRef.update({ user_id: uid });
        }

        // Send Approval Notification
        if (uid) {
          const nTitle = "Admission Approved";
          const nBody = `Congratulations! Your admission for ${enrollmentData?.course_title || enrollmentData?.program_title || "a program"} has been approved.`;
          await db.collection("notifications").add({
            user_id: uid,
            title: nTitle,
            message: nBody,
            type: "enrollment",
            is_read: false,
            created_at: new Date().toISOString(),
          });
        }

        // Load Settings for email
        let smtp_email, smtp_password;
        try {
          const emailDoc = await db
            .collection("settings")
            .doc("smtp_email")
            .get();
          const passDoc = await db
            .collection("settings")
            .doc("smtp_password")
            .get();
          smtp_email = emailDoc.exists ? emailDoc.data()?.value : undefined;
          smtp_password = passDoc.exists ? passDoc.data()?.value : undefined;
        } catch (e) {}

        // Send Email over SMTP
        if (userEmail) {
          try {
            await sendSmtpEmail({
              to: userEmail,
              subject: "Admission Approved - Jaber Math Care",
              db: db,
              html: `
                <div style="font-family: sans-serif; padding: 20px; color: #333; line-height: 1.6;">
                  <h2 style="color: #16a34a;">Congratulations!</h2>
                  <p>Dear ${enrollmentData.name || "Student"},</p>
                  <p>Your admission request for the program <strong>${enrollmentData.course_title || enrollmentData.program_title || "our course"}</strong> has been successfully approved.</p>
                  <p>You can now log in to the Student Dashboard using your registered email and password.</p>
                  <div style="margin: 20px 0; padding: 15px; background: #f0fdf4; border-radius: 8px; border-left: 5px solid #16a34a;">
                    <p style="margin: 0;"><strong>Program:</strong> ${enrollmentData.course_title || enrollmentData.program_title || "N/A"}</p>
                    ${roll_number ? `<p style="margin: 5px 0 0 0;"><strong>Roll Number:</strong> ${roll_number}</p>` : ""}
                  </div>
                  <p>Best regards,<br/>Jaber Math Care Team</p>
                </div>
              `,
            });
          } catch (smtpErr: any) {
            console.error("SMTP Setup/Send Error:", smtpErr.message || smtpErr);
          }
        }

        // Send SMS over Gateway on Admission Approval
        const enrollmentPhone = (
          enrollmentData.phone ||
          enrollmentData.guardian_phone ||
          ""
        ).trim();
        if (enrollmentPhone) {
          try {
            const courseOrProg =
              enrollmentData.course_title ||
              enrollmentData.program_title ||
              "আমাদের প্রোগ্রাম";
            const smsMessage = `প্রিয় ${enrollmentData.name || "শিক্ষার্থী"}, জাবেরম্যাথ কেয়ার-এ আপনার ${courseOrProg}-এ ভর্তি সফলভাবে অনুমোদিত হয়েছে। রোল: ${roll_number || "N/A"}। অ্যাপে লগইন করুন।`;
            await sendAutosms(enrollmentPhone, smsMessage, db);
          } catch (smsErr: any) {
            console.error(
              "Admission API Auto SMS Error:",
              smsErr.message || smsErr,
            );
          }
        }
      }

      res.json({ success: true });
    } catch (error: any) {
      console.error("Error updating status:", error);
      res.status(500).json({ error: "Failed to update status" });
    }
  });

  // Student Search for Attendance
  app.get("/api/student-search", authenticate, async (req, res) => {
    try {
      const { batch_id, roll_number } = req.query;
      let q: any = db.collection("users").where("role", "==", "student");
      if (batch_id) q = q.where("batch_id", "==", String(batch_id));
      if (roll_number) q = q.where("roll_number", "==", String(roll_number));

      const snapshot = await q.get();
      if (snapshot.empty)
        return res.status(404).json({ error: "Student not found" });

      const student = { id: snapshot.docs[0].id, ...snapshot.docs[0].data() };
      res.json(student);
    } catch (error) {
      res.status(500).json({ error: "Search failed" });
    }
  });

  app.get("/api/attendance/report", authenticate, async (req: any, res) => {
    try {
      const {
        batch_id,
        program_id,
        startDate,
        endDate,
        type,
        status,
        roll_number,
      } = req.query;
      let query: any = db.collection("attendance");

      if (batch_id && batch_id !== "all") {
        query = query.where("batch_id", "==", String(batch_id));
      } else if (program_id) {
        query = query.where("program_id", "==", String(program_id));
      }

      const snapshot = await query.get();
      let records = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));

      // In-memory filtration to bypass complex composite index requirements
      if (program_id && batch_id && batch_id !== "all") {
        records = records.filter((r: any) => String(r.program_id) === String(program_id));
      }
      if (type) {
        records = records.filter((r: any) => {
          const rType = String(r.type || "").toLowerCase();
          const filterType = String(type).toLowerCase();
          if (filterType === "class" || filterType === "regular") {
            return rType === "class" || rType === "regular" || rType === "";
          }
          return rType === filterType;
        });
      }
      if (status) {
        records = records.filter((r: any) => String(r.status || "").toLowerCase() === String(status).toLowerCase());
      }
      if (roll_number) {
        records = records.filter((r: any) => String(r.roll_number || "") === String(roll_number));
      }

      // Apply date filters in memory if needed
      if (startDate || endDate) {
        records = records.filter((r: any) => {
          const d = r.date;
          if (startDate && d < startDate) return false;
          if (endDate && d > endDate) return false;
          return true;
        });
      }

      res.json(records);
    } catch (error) {
      console.error("Error fetching attendance report:", error);
      res.status(500).json({ error: "Failed to fetch attendance report" });
    }
  });

  // Standardize collection names (map URL paths to Firestore collection names)

  const collectionMap: Record<string, string> = {
    batches: "batches",
    programs: "programs",
    courses: "courses",
    notices: "notices",
    resources: "resources",
    routines: "routines",
    gallery: "gallery",
    exams: "exams",
    chapters: "chapters",
    "class-slides": "class_slides",
    payments: "payments",
    results: "results",
    reviews: "reviews",
    "video-classes": "video_classes",
    degrees: "degrees",
    "study-materials": "study_materials",
    "web-recorded-classes": "web_recorded_classes",
    "web-class-schedules": "web_class_schedules",
    enrollments: "enrollments",
    "live-classes": "live_classes",
    attendance: "attendance",
    "live-chat-messages": "live_chat_messages",
    "live-polls": "live_polls",
    "live-reactions": "live_reactions",
    "live-participants": "live_participants",
    coupons: "coupons",
    "exam-categories": "exam_categories",
    "exam-types": "exam_types",
    "result-histories": "result_histories",
    sponsorships: "sponsorships",
    messages: "messages",
    blogs: "blogs",
    events: "events",
  };

  const genericCollections = Object.keys(collectionMap);

  genericCollections.forEach((pathName) => {
    const collectionName = collectionMap[pathName];

    // GET all
    app.get(`/api/${pathName}`, authenticate, async (req, res) => {
      try {
        let query: any = db.collection(collectionName);
        Object.keys(req.query).forEach((key) => {
          if (key !== "t") query = query.where(key, "==", req.query[key]);
        });
        const snapshot = await query.get();
        res.json(snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })));
      } catch (error) {
        console.error(`Error fetching ${pathName}:`, error);
        res.status(500).json({ error: `Failed to fetch ${pathName}` });
      }
    });

    // GET one
    app.get(`/api/${pathName}/:id`, authenticate, async (req, res) => {
      try {
        const doc = await db
          .collection(collectionName)
          .doc(req.params.id)
          .get();
        if (!doc.exists) return res.status(404).json({ error: "Not found" });
        res.json({ id: doc.id, ...doc.data() });
      } catch (error) {
        res.status(500).json({ error: "Failed to fetch document" });
      }
    });

    const sanitizeUrls = (obj: any) => {
      const parsed = { ...obj };
      for (const key of ["image_url", "profile_pic", "student_image"]) {
        if (
          typeof parsed[key] === "string" &&
          parsed[key].includes("drive.google.com")
        ) {
          const match = parsed[key].match(
            /drive\.google\.com\/file\/d\/([^\/]+)/,
          );
          if (match && match[1]) {
            parsed[key] =
              `https://drive.google.com/uc?export=view&id=${match[1]}`;
          }
        }
      }
      return parsed;
    };

    // POST
    if (pathName !== "enrollments" && pathName !== "messages") {
      app.post(`/api/${pathName}`, authenticate, async (req, res) => {
        try {
          const sanitizedBody = sanitizeUrls(req.body);
          const data = {
            ...sanitizedBody,
            created_at: new Date().toISOString(),
          };
          if (pathName === "payments" && !data.status) {
            data.status = "approved";
          }
          const docRef = await db.collection(collectionName).add(data);

          // Background tasks: SMS, Email, FCM Push
          if (["payments", "notices"].includes(pathName)) {
            (async () => {
              try {
                if (pathName === "notices") {
                  // Broadcast Push for Notices
                  const nTitle = data.title || "Notice Update";
                  const nMsg = data.content ? (data.content.substring(0, 100) + (data.content.length > 100 ? "..." : "")) : "A new notice has been published.";
                  
                  let studentQuery: any = db.collection("users").where("role", "==", "student");
                  
                  // Filter by batch/program if specified
                  if (data.batch_id && data.batch_id !== "all") {
                    studentQuery = studentQuery.where("batch_id", "==", data.batch_id);
                  } else if (data.program_id && data.program_id !== "all") {
                    studentQuery = studentQuery.where("program_id", "==", data.program_id);
                  }

                  const studentSnap = await studentQuery.get();
                  console.log(`[FCM NOTICE] Broadcasting to ${studentSnap.size} students for notice: ${nTitle}`);
                  
                  // Sequential or chunked send would be safer for very large lists, but for typical use this is okay:
                  return;
                }

                // Get student phone and email for payments/results
                const studentId = data.student_id;
                let phone = "";
                let studentEmail = "";
                let studentName = data.student_name || "Student";
                if (studentId) {
                  const studentDoc = await db
                    .collection("users")
                    .doc(studentId)
                    .get();
                  if (studentDoc.exists) {
                    const sData = studentDoc.data();
                    phone = sData?.guardian_phone || sData?.phone || "";
                    studentEmail =
                      sData?.email ||
                      sData?.gmail ||
                      sData?.gmail_address ||
                      sData?.email_address ||
                      "";
                    if (!studentName || studentName === "Student") {
                      studentName = sData?.name || "Student";
                    }
                  }
                }

                // Call fallback roll search if studentEmail is empty but roll_number exists
                const rawRoll = data.roll_number || data.roll;
                if (!studentEmail && rawRoll) {
                  const cleanedRoll = String(rawRoll).trim();
                  if (cleanedRoll) {
                    console.log(
                      `[${pathName.toUpperCase()} BACKGROUND] Checking student by roll_number: "${cleanedRoll}"`,
                    );
                    const rollSnap = await db
                      .collection("users")
                      .where("roll_number", "==", cleanedRoll)
                      .limit(1)
                      .get();
                    if (!rollSnap.empty) {
                      const sData = rollSnap.docs[0].data();
                      phone =
                        phone || sData?.guardian_phone || sData?.phone || "";
                      studentEmail =
                        sData?.email ||
                        sData?.gmail ||
                        sData?.gmail_address ||
                        sData?.email_address ||
                        "";
                      if (!studentName || studentName === "Student") {
                        studentName = sData?.name || "Student";
                      }
                      console.log(
                        `[${pathName.toUpperCase()} BACKGROUND] Success! Resolved student by roll_number: "${studentName}"`,
                      );
                    }
                  }
                }

                // Try to find by email if data is missing (checking fallbacks outside studentId condition)
                if (!studentEmail && data.email) studentEmail = data.email;
                if (!studentEmail && data.gmail) studentEmail = data.gmail;
                if (!studentEmail && data.email_address)
                  studentEmail = data.email_address;
                if (!studentEmail && data.gmail_address)
                  studentEmail = data.gmail_address;

                if (studentEmail) {
                  studentEmail = String(studentEmail).trim().toLowerCase();
                }
                if (!phone && data.phone) phone = data.phone;
                if (!phone && data.guardian_phone) phone = data.guardian_phone;

                console.log(
                  `[${pathName.toUpperCase()} BACKGROUND] studentId: ${studentId || "NONE"}, name: ${studentName}, email resolved: ${studentEmail || "NONE"}, phone resolved: ${phone || "NONE"}`,
                );

                if (studentId) {
                  // In-app notification
                  const nTitle = pathName === "payments" ? "Payment Received" : "Result Published";
                  const nMsg = pathName === "payments" 
                    ? `Your payment of ৳${data.amount} for ${data.month || "the month"} has been received.`
                    : `Your result for ${data.exam_name || "the exam"} has been published. Marks: ${data.marks}`;
                  
                  await db.collection("notifications").add({
                    user_id: studentId,
                    title: nTitle,
                    message: nMsg,
                    type: pathName,
                    is_read: false,
                    created_at: new Date().toISOString(),
                  }).catch(() => {});
                }

                if (studentEmail && studentEmail.includes("@")) {
                  console.log(`[${pathName.toUpperCase()} EMAIL] Sending to: ${studentEmail}`);
                  const sub = pathName === "payments" ? `Payment Receipt: ${data.month || ""} Fee` : `Result Published: ${data.exam_name || "Exam"}`;
                  const htmlStr = pathName === "payments" 
                    ? `<div style="text-align: center; margin-bottom: 25px;">
                        <span style="display: inline-block; padding: 6px 16px; background-color: #ecfdf5; color: #047857; font-weight: 700; font-size: 11px; border-radius: 9999px; text-transform: uppercase; letter-spacing: 0.05em; border: 1px solid #a7f3d0; font-family: sans-serif;">
                          PAID
                        </span>
                       </div>
                       <p style="font-size: 15px; margin-top: 0; color: #1e293b; font-family: sans-serif;">
                         Dear <strong>${studentName || "Student"}</strong>,
                       </p>
                       <p style="font-size: 14px; color: #475569; line-height: 1.6; font-family: sans-serif;">
                         Your official payment receipt is presented below. Thank you for being with Jaber Math Care!
                       </p>
                       
                       <table border="0" cellpadding="0" cellspacing="0" width="100%" style="margin: 25px 0; background-color: #f8fafc; border-radius: 16px; border: 1px solid #e2e8f0; border-collapse: separate; overflow: hidden; font-family: sans-serif;">
                         <thead>
                           <tr bgcolor="#f1f5f9">
                             <th align="left" style="padding: 12px 16px; font-size: 11px; font-weight: 700; color: #475569; text-transform: uppercase; border-bottom: 1px solid #e2e8f0;">Description</th>
                             <th align="right" style="padding: 12px 16px; font-size: 11px; font-weight: 700; color: #475569; text-transform: uppercase; border-bottom: 1px solid #e2e8f0;">Amount</th>
                           </tr>
                         </thead>
                         <tbody>
                           <tr>
                             <td style="padding: 14px 16px; font-size: 14px; font-weight: 600; color: #1e293b; border-bottom: 1px solid #f1f5f9; text-align: left;">
                               ${data.month || "Current"} Fee Monthly Tuition
                               <div style="font-size: 11px; color: #94a3b8; font-weight: normal; margin-top: 3px;">
                                 Monthly Tuition Fee (Year: ${data.year || new Date().getFullYear()})
                               </div>
                             </td>
                             <td align="right" style="padding: 14px 16px; font-size: 15px; font-weight: 700; color: #0f172a; border-bottom: 1px solid #f1f5f9;">
                               ৳${data.amount}
                             </td>
                           </tr>
                           ${(data.payment_method || data.method) ? `
                           <tr>
                             <td style="padding: 10px 16px; font-size: 11px; color: #64748b; font-weight: 600; text-align: left; border-bottom: 1px solid #f1f5f9;">Payment Method</td>
                             <td align="right" style="padding: 10px 16px; font-size: 11px; color: #1e293b; font-weight: 700; border-bottom: 1px solid #f1f5f9;">${data.payment_method || data.method}</td>
                           </tr>` : ""}
                           ${(data.trx_id || data.transaction_id || data.slip_number) ? `
                           <tr>
                             <td style="padding: 10px 16px; font-size: 11px; color: #64748b; font-weight: 600; text-align: left; border-bottom: 1px solid #f1f5f9;">Transaction ID</td>
                             <td align="right" style="padding: 10px 16px; font-size: 11px; color: #1e293b; font-weight: 700; border-bottom: 1px solid #f1f5f9;">${data.trx_id || data.transaction_id || data.slip_number}</td>
                           </tr>` : ""}
                           ${data.date ? `
                           <tr>
                             <td style="padding: 10px 16px; font-size: 11px; color: #64748b; font-weight: 600; text-align: left;">Payment Date</td>
                             <td align="right" style="padding: 10px 16px; font-size: 11px; color: #1e293b; font-weight: 700;">${new Date(data.date).toLocaleDateString()}</td>
                           </tr>` : ""}
                         </tbody>
                         <tfoot>
                           <tr bgcolor="#f1f5f9">
                             <td style="padding: 14px 16px; font-size: 13px; font-weight: bold; color: #0f172a; text-align: left; border-top: 1px solid #e2e8f0;">Total Collected</td>
                             <td align="right" style="padding: 14px 16px; font-size: 16px; font-weight: 900; color: #10b981; border-top: 1px solid #e2e8f0;">৳${data.amount}</td>
                           </tr>
                         </tfoot>
                       </table>
                       
                       <p style="font-size: 13px; color: #64748b; font-family: sans-serif; text-align: center; margin-top: 25px;">
                         You can access your detailed account history on your student dashboard. Thank you!
                       </p>`
                    : `<div style="text-align: center; margin-bottom: 25px;">
                        <span style="display: inline-block; padding: 6px 16px; background-color: #eff6ff; color: #2563eb; font-weight: 700; font-size: 11px; border-radius: 9999px; text-transform: uppercase; letter-spacing: 0.05em; border: 1px solid #bfdbfe; font-family: sans-serif;">
                          RESULT PUBLISHED
                        </span>
                       </div>
                       <p style="font-size: 15px; margin-top: 0; color: #1e293b; font-family: sans-serif;">
                         Dear <strong>${studentName || "Student"}</strong>,
                       </p>
                       <p style="font-size: 14px; color: #475569; line-height: 1.6; font-family: sans-serif;">
                         Your result for <strong>${data.exam_name || "Exam"}</strong> has been published. Your obtained score is listed below:
                       </p>
                       
                       <div style="margin: 25px 0; padding: 20px; background-color: #f8fafc; border-radius: 16px; border: 1px solid #e2e8f0; text-align: center; font-family: sans-serif;">
                         <div style="font-size: 12px; color: #64748b; text-transform: uppercase; font-weight: 700;">Score / Marks Obtained</div>
                         <div style="font-size: 38px; font-weight: 900; color: #2563eb; margin: 10px 0;">${data.marks}</div>
                         <div style="font-size: 11px; color: #94a3b8;">Log in to the student dashboard to access detailed merit lists and answer sheets.</div>
                       </div>
                       
                       <p style="font-size: 13px; color: #64748b; font-family: sans-serif; text-align: center; margin-top: 25px;">
                         Wishing you a bright future,<br/>Jaber Math Care Team
                       </p>`;

                  await sendSmtpEmail({ to: studentEmail, subject: sub, html: htmlStr, db });
                }

                if (phone) {
                  console.log(`[${pathName.toUpperCase()} SMS] Sending to: ${phone}`);
                  const smsMsg = pathName === "payments"
                    ? `Jaber Math Care: Your payment of TK.${data.amount} for ${data.month || "fee"} received. Thank you.`
                    : `Jaber Math Care: Result for ${data.exam_name || "Exam"} published. Marks: ${data.marks}. Login to see details.`;
                  await sendAutosms(phone, smsMsg, db);
                }
              } catch (e: any) {
                console.error(`[BACKGROUND TASK ERROR] ${pathName}:`, e.message);
              }
            })();
          }

          res.json({ id: docRef.id, ...data });
        } catch (error) {
          res.status(500).json({ error: `Failed to add ${pathName}` });
        }
      });
    }

    // PUT
    app.put(`/api/${pathName}/:id`, authenticate, async (req, res) => {
      try {
        const sanitizedBody = sanitizeUrls(req.body);
        delete sanitizedBody.id;
        Object.keys(sanitizedBody).forEach(key => {
          if (sanitizedBody[key] === undefined) {
            delete sanitizedBody[key];
          }
        });

        // Check if an exam is transitioning to published: true
        let isTransitioningToPublished = false;
        if (pathName === "exams" && sanitizedBody.published === true) {
          const existingExam = await db.collection("exams").doc(req.params.id).get();
          if (existingExam.exists && existingExam.data()?.published !== true) {
            isTransitioningToPublished = true;
          }
        }

        // Check if a sponsorship proposal is transitioning to active
        let sendApprovedEmail = false;
        let sponsorEmail = "";
        let brandName = "";
        if (pathName === "sponsorships" && sanitizedBody.status === "active") {
          const sponsorDoc = await db.collection("sponsorships").doc(req.params.id).get();
          if (sponsorDoc.exists) {
            const oldData = sponsorDoc.data();
            if (oldData?.status !== "active" && oldData?.email) {
              sendApprovedEmail = true;
              sponsorEmail = oldData.email;
              brandName = oldData.brand_name || "Sponsor";
            }
          }
        }

        await db
          .collection(collectionName)
          .doc(req.params.id)
          .update(sanitizedBody);

        res.json({ success: true });

        // Trigger Alerts in Background
        if (isTransitioningToPublished) {
          (async () => {
            try {
              const examId = req.params.id;
              const examDoc = await db.collection("exams").doc(examId).get();
              const examName = examDoc.exists ? examDoc.data()?.name || "Exam" : "Exam";

              const resultsSnap = await db.collection("results").where("exam_id", "==", examId).get();
              console.log(`[PUBLISH ALERTS] Found ${resultsSnap.size} results for exam "${examName}" (${examId}) to process.`);

              for (const rDoc of resultsSnap.docs) {
                const rData = rDoc.data();
                const studentId = rData.student_id;
                const roll_number = rData.roll_number || rData.roll;
                const marks = rData.marks;
                const merit_position = rData.merit_position || rData.merit || "N/A";
                const highest_marks = rData.highest_marks || "N/A";

                let phone = rData.phone || rData.guardian_phone || "";
                let studentEmail = rData.email || rData.gmail || "";
                let studentName = rData.student_name || "Student";

                if (studentId) {
                  const studentDoc = await db.collection("users").doc(studentId).get();
                  if (studentDoc.exists) {
                    const sData = studentDoc.data();
                    phone = phone || sData?.guardian_phone || sData?.phone || "";
                    studentEmail = studentEmail || sData?.email || sData?.gmail || sData?.gmail_address || sData?.email_address || "";
                    if (!studentName || studentName === "Student") {
                      studentName = sData?.name || "Student";
                    }
                  }
                }

                if (!studentEmail && roll_number) {
                  const cleanedRoll = String(roll_number).trim();
                  if (cleanedRoll) {
                    const rollSnap = await db.collection("users").where("roll_number", "==", cleanedRoll).limit(1).get();
                    if (!rollSnap.empty) {
                      const sData = rollSnap.docs[0].data();
                      phone = phone || sData?.guardian_phone || sData?.phone || "";
                      studentEmail = studentEmail || sData?.email || sData?.gmail || sData?.gmail_address || sData?.email_address || "";
                      if (!studentName || studentName === "Student") {
                        studentName = sData?.name || "Student";
                      }
                    }
                  }
                }

                if (studentEmail) {
                  studentEmail = String(studentEmail).trim().toLowerCase();
                }

                // Web Notification
                if (studentId) {
                  const nMsg = `Your result for ${examName} has been published. Marks: ${marks}, Merit Position: ${merit_position} (Highest: ${highest_marks}).`;
                  await db.collection("notifications").add({
                    user_id: studentId,
                    title: "Result Published",
                    message: nMsg,
                    type: "results",
                    is_read: false,
                    created_at: new Date().toISOString(),
                  }).catch(() => {});
                }

                // Email via SMTP
                if (studentEmail && studentEmail.includes("@")) {
                  const sub = `Result Published: ${examName}`;
                  const htmlStr = `<div style="text-align: center; margin-bottom: 25px;">
                      <span style="display: inline-block; padding: 6px 16px; background-color: #eff6ff; color: #2563eb; font-weight: 700; font-size: 11px; border-radius: 9999px; text-transform: uppercase; letter-spacing: 0.05em; border: 1px solid #bfdbfe; font-family: sans-serif;">
                        RESULT PUBLISHED WITH MERIT RANKINGS
                      </span>
                     </div>
                     <p style="font-size: 15px; margin-top: 0; color: #1e293b; font-family: sans-serif;">
                       Dear <strong>${studentName}</strong>,
                     </p>
                     <p style="font-size: 14px; color: #475569; line-height: 1.6; font-family: sans-serif;">
                       Your result for <strong>${examName}</strong> has been published. Your score details and merit rankings are listed below:
                     </p>
                     
                     <div style="margin: 25px 0; padding: 25px; background-color: #f8fafc; border-radius: 16px; border: 1px solid #e2e8f0; font-family: sans-serif;">
                       <table border="0" cellpadding="8" cellspacing="0" width="100%" style="font-size: 14px; color: #334155;">
                         <tr>
                           <td width="50%" style="font-weight: 600; border-bottom: 1px solid #f1f5f9;">Obtained Marks:</td>
                           <td style="font-size: 20px; font-weight: 800; color: #2563eb; border-bottom: 1px solid #f1f5f9;">${marks}</td>
                         </tr>
                         <tr>
                           <td style="font-weight: 600; border-bottom: 1px solid #f1f5f9;">Highest Marks in Exam:</td>
                           <td style="font-weight: 700; color: #1e293b; border-bottom: 1px solid #f1f5f9;">${highest_marks}</td>
                         </tr>
                         <tr>
                           <td style="font-weight: 600;">Merit Position:</td>
                           <td style="font-size: 18px; font-weight: 800; color: #059669;">${merit_position}</td>
                         </tr>
                       </table>
                       <p style="font-size: 11px; color: #94a3b8; text-align: center; margin-top: 15px; margin-bottom: 0;">Log in to the student dashboard to access detailed merit lists and answer sheets.</p>
                     </div>
                     
                     <p style="font-size: 13px; color: #64748b; font-family: sans-serif; text-align: center; margin-top: 25px;">
                       Wishing you a bright future,<br/>Jaber Math Care Team
                     </p>`;
                  await sendSmtpEmail({ to: studentEmail, subject: sub, html: htmlStr, db }).catch(() => {});
                }

                // SMS
                if (phone) {
                  const smsMsg = `Jaber Math Care: Result for ${examName} published. Marks: ${marks}, Highest: ${highest_marks}, Merit Position: ${merit_position}. Login to see details.`;
                  await sendAutosms(phone, smsMsg, db).catch(() => {});
                }
              }
            } catch (alertErr: any) {
              console.error("[PUBLISH ALERTS ERROR]:", alertErr.message);
            }
          })();
        }

        if (sendApprovedEmail && sponsorEmail) {
          (async () => {
            try {
              await sendSmtpEmail({
                to: sponsorEmail,
                subject: "Sponsorship Proposal Approved - Jaber Math Care",
                db: db,
                html: `
                  <div style="font-family: sans-serif; padding: 25px; color: #1e293b; line-height: 1.6; max-width: 600px; margin: 0 auto; border: 1px solid #e2e8f0; border-radius: 20px; background-color: #ffffff;">
                    <h2 style="color: #059669; text-align: center; margin-bottom: 20px;">Congratulations! Sponsorship Approved</h2>
                    <p>Dear Partner,</p>
                    <p>We are delighted to inform you that your sponsorship proposal for <strong>${brandName}</strong> has been officially approved and published on our platform!</p>
                    
                    <div style="margin: 25px 0; padding: 15px; background-color: #f0fdf4; border-radius: 12px; border-left: 6px solid #10b981;">
                      <p style="margin: 0; font-size: 14px; color: #065f46;"><strong>Brand Name:</strong> ${brandName}</p>
                      <p style="margin: 5px 0 0 0; font-size: 14px; color: #065f46;"><strong>Status:</strong> Active / Published</p>
                    </div>

                    <p>Your educational ad/banner code is now visible on our Support Page and Homepage. Thank you for supporting Jaber Math Care!</p>
                    <p style="margin-top: 30px; font-size: 13px; color: #64748b; border-top: 1px solid #f1f5f9; padding-top: 15px; text-align: center;">
                       Best regards,<br/><strong>Jaber Math Care Team</strong>
                    </p>
                  </div>
                `
              });
              console.log(`[SPONSOR APPROVAL EMAIL] Approved email sent to: ${sponsorEmail}`);
            } catch (smtpErr: any) {
              console.error("[SPONSOR APPROVAL EMAIL ERROR]:", smtpErr.message);
            }
          })();
        }

      } catch (error) {
        res.status(500).json({ error: "Failed to update document" });
      }
    });

    // DELETE
    app.delete(`/api/${pathName}/:id`, authenticate, async (req: any, res) => {
      if (req.user.role !== "admin" && req.user.role !== "moderator") {
        return res.status(403).json({ error: "Forbidden" });
      }
      try {
        const id = req.params.id;

        // Special handling for courses, programs, batches -> recursively delete students
        if (
          pathName === "courses" ||
          pathName === "programs" ||
          pathName === "batches"
        ) {
          if (pathName === "programs") {
            await deleteProgramData(id);
          } else if (pathName === "batches") {
            await deleteBatchData(id);
          } else if (pathName === "courses") {
            let fieldName = "course_id";
            // Find students matching this ID, delete theirs
            const studentsQuery = await db
              .collection("users")
              .where(fieldName, "==", id)
              .get();
            for (const doc of studentsQuery.docs) {
              try {
                if (doc.id) {
                  await admin
                    .auth()
                    .deleteUser(doc.id)
                    .catch(() => {});
                  await deleteStudentData(doc.id);
                }
                await doc.ref.delete();
              } catch (err) {
                console.error(`Failed to delete student ${doc.id}:`, err);
              }
            }

            // Also delete sub-collections of courses as in old frontend logic
            const collectionsToDelete = [
              "chapters",
              "routines",
              "study_materials",
              "video_classes",
              "class_slides",
              "web_recorded_classes",
              "web_class_schedules",
              "live_classes",
              "notices",
              "payments",
              "enrollments",
              "attendance",
              "results"
            ];
            for (const colName of collectionsToDelete) {
              try {
                const items = await db
                  .collection(colName)
                  .where("course_id", "==", id)
                  .get();
                for (const itemDoc of items.docs) {
                  await itemDoc.ref.delete();
                }
              } catch (e) {
                console.error(
                  `Failed to delete sub-collection ${colName} of course ${id}:`,
                  e,
                );
              }
            }

            // Clean up exams associated with this course and their child results
            try {
              const examsQuery = await db
                .collection("exams")
                .where("course_id", "==", id)
                .get();
              for (const examDoc of examsQuery.docs) {
                try {
                  const resQuery = await db
                    .collection("results")
                    .where("exam_id", "==", examDoc.id)
                    .get();
                  for (const rDoc of resQuery.docs) {
                    await rDoc.ref.delete();
                  }
                  await examDoc.ref.delete();
                } catch (examErr) {
                  console.error(`Failed to delete course exam cascade:`, examErr);
                }
              }
            } catch (examsErr) {
              console.error(`Failed to request exams for course:`, examsErr);
            }
          }
        }

        await db.collection(collectionName).doc(id).delete();
        res.json({ success: true });
      } catch (error) {
        console.error(`[DELETE /api/${pathName}/:id] Error:`, error);
        res.status(500).json({ error: "Failed to delete document" });
      }
    });
  });

  // Special handling for attendance (Admin/Moderator only)
  app.post(
    "/api/attendance/mark-present",
    authenticate,
    async (req: any, res) => {
      if (req.user.role !== "admin" && req.user.role !== "moderator")
        return res.status(403).json({ error: "Forbidden" });
      try {
        const { student_id, batch_id, date, status, roll_number } = req.body;
        const data = {
          student_id,
          batch_id,
          date: date || new Date().toISOString().split("T")[0],
          status: status || "present",
          roll_number,
          created_at: new Date().toISOString(),
        };
        const docRef = await db.collection("attendance").add(data);
        res.json({ id: docRef.id, ...data });
      } catch (error) {
        res.status(500).json({ error: "Failed to mark attendance" });
      }
    },
  );

  app.post(
    "/api/attendance/auto-absent",
    authenticate,
    async (req: any, res) => {
      if (req.user.role !== "admin" && req.user.role !== "moderator")
        return res.status(403).json({ error: "Forbidden" });
      try {
        const { batch_id, date, type = "class", exam_id } = req.body;
        if (!batch_id || !date)
          return res.status(400).json({ error: "batch_id and date required" });

        // Get all students in this batch (primary or secondary)
        const studentsSnapshot1 = await db
          .collection("users")
          .where("role", "==", "student")
          .where("batch_id", "==", String(batch_id))
          .get();

        const studentsSnapshot2 = await db
          .collection("users")
          .where("role", "==", "student")
          .where("batch_id_2", "==", String(batch_id))
          .get();

        const studentDocsMap = new Map();
        studentsSnapshot1.docs.forEach((doc) =>
          studentDocsMap.set(doc.id, doc),
        );
        studentsSnapshot2.docs.forEach((doc) =>
          studentDocsMap.set(doc.id, doc),
        );

        const allStudentDocs = Array.from(studentDocsMap.values());

        const studentIds = allStudentDocs.map((doc) => doc.id);

        // Get existing attendance for this date and batch and type
        const attendanceSnapshot = await db
          .collection("attendance")
          .where("batch_id", "==", String(batch_id))
          .where("date", "==", date)
          .where("type", "==", type)
          .get();

        const alreadyMarkedIds = new Set(
          attendanceSnapshot.docs.map((doc) => doc.data().student_id),
        );

        const batch = db.batch();
        let count = 0;

        for (const studentDoc of allStudentDocs) {
          if (!alreadyMarkedIds.has(studentDoc.id)) {
            const studentData = studentDoc.data();
            const attendanceRef = db.collection("attendance").doc();
            batch.set(attendanceRef, {
              student_id: studentDoc.id,
              batch_id: String(batch_id),
              date,
              status: "absent",
              type,
              roll_number: studentData.roll_number,
              isAuto: true,
              ...(exam_id && { exam_id: String(exam_id) }),
              created_at: new Date().toISOString(),
            });
            count++;
          }
        }

        if (count > 0) await batch.commit();
        res.json({ success: true, count });
      } catch (error) {
        console.error("Auto-absent error:", error);
        res.status(500).json({ error: "Failed to trigger auto-absent" });
      }
    },
  );

  app.post("/api/admin/clear-all-data", authenticate, async (req: any, res) => {
    if (req.user.role !== "admin")
      return res.status(403).json({ error: "Forbidden" });
    const { collection: collectionName } = req.body;
    try {
      const snapshot = await db.collection(collectionName).get();
      const batch = db.batch();
      snapshot.docs.forEach((doc) => batch.delete(doc.ref));
      await batch.commit();
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to clear data" });
    }
  });

  // Student Status Update
  app.patch("/api/students/:id/status", authenticate, async (req, res) => {
    try {
      const { status } = req.body;

      const userDoc = await db.collection("users").doc(req.params.id).get();
      if (!userDoc.exists)
        return res.status(404).json({ error: "User not found" });

      const updateData: any = { status };

      // If approved and current type is online, change to offline
      if (status === "approved" && userDoc.data()?.student_type === "online") {
        updateData.student_type = "offline";
      }

      await db.collection("users").doc(req.params.id).update(updateData);
      res.json({ success: true });
    } catch (error) {
      console.error("Failed to update student status:", error);
      res.status(500).json({ error: "Failed to update student status" });
    }
  });

  // Reset Data Route
  app.post("/api/reset-data", authenticate, async (req: any, res) => {
    if (req.user.role !== "admin")
      return res.status(403).json({ error: "Forbidden" });
    const { type } = req.body;
    try {
      const collections: Record<string, string> = {
        students: "users",
        online_students: "users",
        offline_students: "users",
        batches: "batches",
        payments: "payments",
        enrollments: "enrollments",
        attendance: "attendance",
        exams: "exams",
        results: "results",
        notices: "notices",
        live_classes: "live_classes",
        study_materials: "study_materials",
        gallery: "gallery",
        video_classes: "video_classes",
        class_slides: "class_slides",
        routines: "routines",
        programs: "programs",
        courses: "courses",
        chapters: "chapters",
        messages: "messages",
        web_recorded_classes: "web_recorded_classes",
        web_class_schedules: "web_class_schedules",
      };

      const collectionName = collections[type];
      if (!collectionName)
        return res.status(400).json({ error: "Invalid type" });

      let query: any = db.collection(collectionName);
      if (type === "online_students")
        query = query.where("student_type", "==", "online");
      if (type === "offline_students")
        query = query.where("student_type", "==", "offline");
      if (type === "students") query = query.where("role", "==", "student");

      const snapshot = await query.get();
      const batch = db.batch();
      snapshot.docs.forEach((doc: any) => {
        // Don't delete the admin user if resetting students
        if (collectionName === "users" && doc.data().role === "admin") return;
        batch.delete(doc.ref);
      });
      await batch.commit();
      res.json({ success: true });
    } catch (error) {
      console.error("Reset error:", error);
      res.status(500).json({ error: "Failed to reset data" });
    }
  });

  // Public routes (no auth needed for some GETs)
  app.get("/api/public/notices", async (req, res) => {
    try {
      const snapshot = await db
        .collection("notices")
        .where("is_verified", "==", true)
        .get();
      const notices = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      res.json(notices);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch notices" });
    }
  });

  app.get("/api/public/results", async (req, res) => {
    try {
      const [resultsSnap, usersSnap] = await Promise.all([
        db.collection("results").get(),
        db.collection("users").get(),
      ]);
      const usersMap = new Map();
      usersSnap.docs.forEach((doc) => {
        usersMap.set(doc.id, doc.data());
      });
      const results = resultsSnap.docs.map((doc) => {
        const data = doc.data();
        let roll_number = data.roll_number;
        let student_name = data.student_name;
        if ((!roll_number || !student_name) && data.student_id) {
          const studentData = usersMap.get(data.student_id);
          if (studentData) {
            roll_number = studentData.roll_number || "";
            student_name = studentData.name || "";
          }
        }
        return {
          id: doc.id,
          ...data,
          roll_number,
          student_name,
        };
      });
      res.json(results);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to fetch results" });
    }
  });

  app.get("/api/public/exams", async (req, res) => {
    try {
      const snapshot = await db.collection("exams").get();
      const exams = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
      res.json(exams);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch exams" });
    }
  });

  app.get("/api/public/programs", async (req, res) => {
    try {
      const snapshot = await db.collection("programs").get();
      const programs = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      res.json(programs);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch programs" });
    }
  });

  app.get("/api/public/batches", async (req, res) => {
    try {
      const snapshot = await db.collection("batches").get();
      const batches = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      res.json(batches);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch batches" });
    }
  });

  // SMS Integration
  app.post(
    "/api/notifications/broadcast",
    authenticate,
    async (req: any, res) => {
      try {
        const { user_ids, title, message, type } = req.body;
        if (!Array.isArray(user_ids))
          return res.status(400).json({ error: "user_ids must be an array" });

        const batch = db.batch();
        user_ids.forEach((uid) => {
          const ref = db.collection("notifications").doc();
          batch.set(ref, {
            user_id: uid,
            title,
            message,
            type: type || "announcement",
            is_read: false,
            created_at: new Date().toISOString(),
          });
        });

        await batch.commit();

        res.json({ success: true, count: user_ids.length });
      } catch (error) {
        console.error("Broadcast error:", error);
        res.status(500).json({ error: "Failed to broadcast notifications" });
      }
    },
  );

  app.post("/api/send-sms", authenticate, async (req: any, res) => {
    if (req.user.role !== "admin" && req.user.role !== "moderator")
      return res.status(403).json({ error: "Forbidden" });
    try {
      const { phone, message } = req.body;
      if (!phone || !message) {
        return res
          .status(400)
          .json({ error: "Phone and message are required" });
      }

      const settingsSnapshot = await db.collection("settings").get();
      const settings: any = {};
      settingsSnapshot.docs.forEach((doc) => {
        settings[doc.id] = doc.data().value;
      });

      if (!settings.sms_api_url) {
        return res
          .status(400)
          .json({ error: "SMS Gateway URL not configured in Settings" });
      }

      const url = new URL(settings.sms_api_url);
      if (settings.sms_api_key)
        url.searchParams.append("api_key", settings.sms_api_key);
      if (settings.sms_sender_id)
        url.searchParams.append("senderid", settings.sms_sender_id);
      url.searchParams.append("number", phone);
      url.searchParams.append("message", message);

      const response = await fetch(url.toString());
      const responseText = await response.text();

      console.log(`SMS dispatched to ${phone}. Response: ${responseText}`);
      res.json({ success: true, response: responseText });
    } catch (error: any) {
      console.error("Error sending SMS:", error);
      res
        .status(500)
        .json({ error: "Failed to send SMS", details: error.message });
    }
  });

  app.post("/api/send-system-email", async (req, res) => {
    try {
      const { type, data } = req.body;
      if (!type || !data) {
        return res.status(400).json({ error: "Type and data are required" });
      }

      console.log(`[System SMTP] Received send-system-email request, type: ${type}`, data);

      let subject = "";
      let html = "";
      let recipient = data.email || data.gmail || "";

      if (type === "student_welcome") {
        subject = "Admission Completed Successfully - Jaber Math Care";
        html = `
          <div style="font-family: sans-serif; padding: 20px; color: #333; line-height: 1.6;">
            <h2 style="color: #16a34a;">Welcome!</h2>
            <p>Dear ${data.name || "Student"},</p>
            <p>Your admission for the program <strong>${data.course_title || data.program_title || "our course"}</strong> has been completed successfully.</p>
            <p>You can now log in to our website using your email and password.</p>
            <div style="margin: 20px 0; padding: 15px; background: #f0fdf4; border-radius: 8px; border-left: 5px solid #16a34a;">
              <p style="margin: 0;"><strong>Your Login Email:</strong> ${recipient.trim()}</p>
              <p style="margin: 5px 0 0 0;"><strong>Your Password:</strong> ${data.password || "N/A"}</p>
              ${data.roll_number ? `<p style="margin: 5px 0 0 0;"><strong>Roll Number:</strong> ${data.roll_number}</p>` : ""}
              <p style="margin: 5px 0 0 0;"><strong>Program:</strong> ${data.course_title || data.program_title || "N/A"}</p>
            </div>
            <p>Best regards,<br/>Jaber Math Care Team</p>
          </div>
        `;
      } else if (type === "admission_approved") {
        subject = "Admission Approved - Jaber Math Care";
        html = `
          <div style="font-family: sans-serif; padding: 20px; color: #333; line-height: 1.6;">
            <h2 style="color: #16a34a;">Congratulations!</h2>
            <p>Dear ${data.name || "Student"},</p>
            <p>Your admission request for the program <strong>${data.course_title || data.program_title || "our course"}</strong> has been successfully approved.</p>
            <p>You can now log in to the Student Dashboard using your registered email and password.</p>
            <div style="margin: 20px 0; padding: 15px; background: #f0fdf4; border-radius: 8px; border-left: 5px solid #16a34a;">
              <p style="margin: 0;"><strong>Program:</strong> ${data.course_title || data.program_title || "N/A"}</p>
              ${data.roll_number ? `<p style="margin: 5px 0 0 0;"><strong>Roll Number:</strong> ${data.roll_number}</p>` : ""}
            </div>
            <p>Best regards,<br/>Jaber Math Care Team</p>
          </div>
        `;
      } else if (type === "payment_receipt") {
        const invoiceNo = "INV-" + Date.now().toString().slice(-6);
        const currentDate = new Date().toLocaleDateString("en-US", { year: 'numeric', month: 'long', day: 'numeric' });
        subject = `Paid Invoice & Receipt - ${invoiceNo}`;
        html = `
          <div style="font-family: sans-serif; padding: 15px; color: #333; max-width: 500px; margin: auto;">
            <!-- Status Badge -->
            <div style="text-align: right; margin-bottom: 20px;">
              <span style="background-color: #d1fae5; color: #065f46; padding: 8px 16px; border-radius: 9999px; font-weight: bold; font-size: 12px; text-transform: uppercase; letter-spacing: 0.05em;">PAID INVOICE</span>
            </div>

            <h2 style="color: #0f172a; font-size: 20px; font-weight: 800; margin: 0 0 10px 0; letter-spacing: -0.025em;">Payment Confirmation</h2>
            <p style="font-size: 14px; color: #475569; margin: 0 0 25px 0; line-height: 1.5;">Dear ${data.student_name || "Student"},</p>
            <p style="font-size: 14px; color: #475569; margin: 0 0 20px 0; line-height: 1.5;">Thank you for your payment. Your registration status is up to date, and we have generated your official digital paid invoice below.</p>

            <!-- Invoice Details Card -->
            <div style="border: 1px solid #e2e8f0; border-radius: 16px; overflow: hidden; background-color: #fafafa; margin-bottom: 25px;">
              <div style="padding: 16px; background-color: #f1f5f9; border-bottom: 1px solid #e2e8f0;">
                <table width="100%" cellpadding="0" cellspacing="0" style="font-size: 12px; color: #475569;">
                  <tr>
                    <td><strong>INVOICE NO:</strong> ${invoiceNo}</td>
                    <td align="right"><strong>DATE:</strong> ${currentDate}</td>
                  </tr>
                </table>
              </div>
              <div style="padding: 20px;">
                <p style="font-size: 11px; color: #64748b; text-transform: uppercase; letter-spacing: 0.05em; margin: 0 0 6px 0;"><strong>Student Details:</strong></p>
                <p style="font-size: 14px; color: #1e293b; font-weight: bold; margin: 0 0 4px 0;">${data.student_name || "Student"}</p>
                ${data.phone ? `<p style="font-size: 12px; color: #475569; margin: 0;"><strong>Phone:</strong> ${data.phone}</p>` : ""}
                ${data.email ? `<p style="font-size: 12px; color: #475569; margin: 2px 0 0 0;"><strong>Email:</strong> ${data.email}</p>` : ""}
              </div>
            </div>

            <!-- Items Table -->
            <table width="100%" cellpadding="0" cellspacing="0" style="font-size: 13px; line-height: 1.6; border-collapse: collapse; margin-bottom: 25px;">
              <thead>
                <tr style="border-bottom: 2px solid #e2e8f0; font-weight: bold; color: #475569;">
                  <td style="padding: 10px 0;">Description</td>
                  <td align="right" style="padding: 10px 0;">Amount</td>
                </tr>
              </thead>
              <tbody>
                <tr style="border-bottom: 1px solid #f1f5f9; color: #1e293b;">
                  <td style="padding: 12px 0;">
                    <div style="font-weight: bold;">Educational Tuition Fee</div>
                    <div style="font-size: 11px; color: #64748b; margin-top: 2px;">Billing Term: ${data.month || "Current Program Fee"}</div>
                  </td>
                  <td align="right" style="font-weight: bold; padding: 12px 0;">৳${data.amount}</td>
                </tr>
                <tr style="font-size: 15px; color: #0f172a; font-weight: bold;">
                  <td style="padding: 16px 0 0 0; text-transform: uppercase; letter-spacing: 0.02em;">Total Paid</td>
                  <td align="right" style="padding: 16px 0 0 0; font-size: 18px; color: #4f46e5;">৳${data.amount}</td>
                </tr>
              </tbody>
            </table>

            <div style="border-top: 1px dashed #cbd5e1; padding-top: 20px; font-size: 11px; color: #94a3b8; text-align: center; line-height: 1.5;">
              This paid invoice is generated electronically for educational enrollment at Jaber Math Care.<br/>If you have questions about this payment, please contact our support desk.
            </div>
          </div>
        `;
      } else if (type === "result_published") {
        subject = `Result Published: ${data.exam_name || "Exam"}`;
        html = `
          <div style="font-family: sans-serif; padding: 20px; color: #333;">
            <h2 style="color: #2563eb;">Exam Result</h2>
            <p>Dear ${data.student_name || "Student"},</p>
            <p>Your result for <strong>${data.exam_name || "the exam"}</strong> has been published.</p>
            <p>Marks Obtained: <strong>${data.marks}</strong></p>
            <p>Log in to the Jaber Math Care app to see detailed results.</p>
          </div>
        `;
      } else if (type === "contact_submission") {
        recipient = data.adminEmail;
        subject = `New Contact Form Submission: ${data.subject || "No Subject"}`;
        html = `Name: ${data.name}<br>Email: ${data.email}<br>Phone: ${data.phone}<br>Class: ${data.current_class}<br>School: ${data.school_name}<br>College: ${data.college_name}<br><br>Message:<br>${data.message}`;
      } else {
        return res.status(400).json({ error: "Invalid type specified" });
      }

      if (!recipient || !recipient.includes("@")) {
        console.warn("[System SMTP] Missing or invalid recipient email:", recipient);
        return res.status(400).json({ error: "Missing or invalid recipient email address" });
      }

      // Send SMS asynchronously if needed
      if ((type === "payment_receipt" || type === "result_published") && data.phone) {
        let smsMsg = "";
        if (type === "payment_receipt") {
          smsMsg = `Jaber Math Care: Your payment of TK.${data.amount} for ${data.month || "fee"} received. Thank you.`;
        } else {
          smsMsg = `Jaber Math Care: Result for ${data.exam_name || "Exam"} published. Marks: ${data.marks}. Login to see details.`;
        }
        sendAutosms(data.phone, smsMsg, db).catch(e => {
          console.error("[System SMTP] Quick SMS dispatch error:", e.message);
        });
      } else if (type === "admission_approved" && data.phone) {
        const smsMsg = `Jaber Math Care: Congratulation! Your admission application for ${data.course_title || data.program_title || "Program"} approved. Please login to student panel.`;
        sendAutosms(data.phone, smsMsg, db).catch(e => {
          console.error("[System SMTP] Quick Approval SMS failure:", e.message);
        });
      }

      // Send Email
      console.log(`[System SMTP] Dispatching email to: ${recipient}`);
      const sendResult = await sendSmtpEmail({
        to: recipient,
        subject,
        html,
        db,
      });

      if (!sendResult.success) {
        return res.status(500).json({ error: "SMTP Dispatch fail", details: sendResult.error });
      }

      res.json({ success: true, message: "Transactional message dispatched successfully" });
    } catch (e: any) {
      console.error("[System SMTP] General error in send-system-email endpoint:", e);
      res.status(500).json({ error: "System SMTP process error", details: e.message });
    }
  });

  app.post("/api/send-email", authenticate, async (req: any, res) => {
    if (req.user.role !== "admin" && req.user.role !== "moderator")
      return res.status(403).json({ error: "Forbidden" });
    try {
      const { email, subject, message } = req.body;
      if (!email || !subject || !message) {
        return res
          .status(400)
          .json({ error: "Email, subject and message are required" });
      }

      // Pre-fetch settings once so that sendSmtpEmail doesn't need to query Firestore repetitively
      const settingsSnap = await db.collection("settings").get();
      const settings: any = {};
      settingsSnap.forEach((doc) => {
        settings[doc.id] = doc.data().value;
      });

      const sendResult = await sendSmtpEmail({
        to: email,
        subject,
        html: message,
        smtp_email: settings.smtp_email,
        smtp_password: settings.smtp_password,
        db: db,
      });

      if (sendResult?.success === false) {
         return res.status(500).json({ error: "Failed to send Email", details: sendResult.error });
      }

      res.json({
        success: true,
        message: "Email dispatched successfully",
      });
    } catch (error: any) {
      console.error("Error sending Email:", error);
      res
        .status(500)
        .json({ error: "Failed to send Email", details: error.message });
    }
  });

  app.post("/api/send-email-bulk", authenticate, async (req: any, res) => {
    if (req.user.role !== "admin" && req.user.role !== "moderator")
      return res.status(403).json({ error: "Forbidden" });
    try {
      const { emails, subject, message } = req.body;
      if (!emails || !Array.isArray(emails) || emails.length === 0 || !subject || !message) {
        return res
          .status(400)
          .json({ error: "Emails array, subject and message are required" });
      }

      const settingsSnap = await db.collection("settings").get();
      const settings: any = {};
      settingsSnap.forEach((doc) => {
        settings[doc.id] = doc.data().value;
      });

      if (!settings.smtp_email || !settings.smtp_password) {
         return res.status(500).json({ error: "SMTP settings not found in database" });
      }

      let successCount = 0;
      let failedCount = 0;
      
      // Batch emails by 50 to avoid BCC limits
      for (let i = 0; i < emails.length; i += 50) {
        const batch = emails.slice(i, i + 50);
        
        const sendResult = await sendSmtpEmail({
          to: settings.smtp_email, // Self-address to hide BCC recipients
          bcc: batch.join(','),
          subject,
          html: message,
          smtp_email: settings.smtp_email,
          smtp_password: settings.smtp_password,
          db: db,
        });

        if (sendResult?.success === false) {
           failedCount += batch.length;
           console.error("Bulk email error", sendResult.error);
        } else {
           successCount += batch.length;
        }
      }

      res.json({
        success: true,
        successCount,
        failedCount,
        message: "Bulk email dispatched successfully",
      });
    } catch (error: any) {
      console.error("Error sending bulk Email:", error);
      res
        .status(500)
        .json({ error: "Failed to send bulk Email", details: error.message });
    }
  });

  app.post("/api/test-smtp", authenticate, async (req: any, res) => {
    if (req.user.role !== "admin" && req.user.role !== "moderator")
      return res.status(403).json({ error: "Forbidden" });
    try {
      const { smtp_email, smtp_password } = req.body;
      if (!smtp_email || !smtp_password) {
        return res
          .status(400)
          .json({
            error: "Both SMTP Email and SMTP App Password are required",
          });
      }

      // Try sending a test email using our robust helper
      const sendResult = await sendSmtpEmail({
        to: smtp_email.trim(),
        subject: "SMTP Connection Test - Jaber Math Care",
        html: `
          <div style="font-family: sans-serif; padding: 20px; color: #333; line-height: 1.6;">
            <p style="font-size: 18px; font-weight: bold; color: #16a34a;">SMTP Test Succeeded!</p>
            <p>Congratulations, your App has successfully connected to the Gmail SMTP server.</p>
            <p>Automated transactional messages will now be dispatched without issue!</p>
            <p>Best regards,<br/>Jaber Math Care system</p>
          </div>
        `,
        smtp_email,
        smtp_password,
        db: db,
      });

      if (sendResult?.success === false) {
        return res.status(500).json({ error: "SMTP Connection failed", details: sendResult.error });
      }

      res.json({
        success: true,
        message:
          "SMTP configurations are valid! A test email has been sent to " +
          smtp_email,
      });
    } catch (error: any) {
      console.error("SMTP testing connection failed:", error);
      res
        .status(500)
        .json({ error: "SMTP Connection Failed", details: error.message });
    }
  });

  // Coupons
  app.get("/api/coupons", authenticate, async (req: any, res) => {
    try {
      const snapshot = await db.collection("coupons").get();
      res.json(snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })));
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch coupons" });
    }
  });

  app.post("/api/coupons", authenticate, async (req: any, res) => {
    if (req.user.role !== "admin")
      return res.status(403).json({ error: "Not authorized" });
    try {
      const { code, type, value, expiry_date, status } = req.body;
      const couponData = {
        code: code.toUpperCase(),
        type,
        value: Number(value),
        expiry_date,
        status: status || "active",
        created_at: new Date().toISOString(),
      };
      const docRef = await db.collection("coupons").add(couponData);
      res.json({ id: docRef.id, ...couponData });
    } catch (error) {
      res.status(500).json({ error: "Failed to create coupon" });
    }
  });

  app.delete("/api/coupons/:id", authenticate, async (req: any, res) => {
    if (req.user.role !== "admin")
      return res.status(403).json({ error: "Not authorized" });
    try {
      await db.collection("coupons").doc(req.params.id).delete();
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete coupon" });
    }
  });

  app.post("/api/validate-coupon", async (req, res) => {
    try {
      const { code, amount } = req.body;
      const snapshot = await db
        .collection("coupons")
        .where("code", "==", code.toUpperCase())
        .where("status", "==", "active")
        .get();

      if (snapshot.empty)
        return res.status(404).json({ error: "Invalid coupon code" });

      const coupon = snapshot.docs[0].data();
      const now = new Date();
      if (coupon.expiry_date && new Date(coupon.expiry_date) < now) {
        return res.status(400).json({ error: "Coupon has expired" });
      }

      let discount = 0;
      if (coupon.type === "percentage") {
        discount = (Number(amount) * Number(coupon.value)) / 100;
      } else {
        discount = Number(coupon.value);
      }

      res.json({
        valid: true,
        discount: Math.min(discount, Number(amount)),
        final_amount: Math.max(0, Number(amount) - discount),
        coupon_id: snapshot.docs[0].id,
      });
    } catch (error) {
      res.status(500).json({ error: "Validation failed" });
    }
  });

  app.post("/api/forgot-password/request", async (req, res) => {
    try {
      let { identifier, email } = req.body;
      const targetQuery = identifier || email;
      if (!targetQuery) {
        return res.status(400).json({ error: "Please provide your email, phone, or roll number." });
      }

      const cleanQuery = targetQuery.toLowerCase().trim();
      const originalQuery = targetQuery.trim();

      // Check if user exists in Firestore
      let userDoc = null;
      
      if (originalQuery.includes("@")) {
        let usersSnap = await db.collection("users").where("email", "==", cleanQuery).get();
        if (usersSnap.empty) {
          usersSnap = await db.collection("users").where("gmail", "==", cleanQuery).get();
        }
        if (usersSnap.empty) {
          usersSnap = await db.collection("users").where("email", "==", originalQuery).get();
        }
        if (usersSnap.empty) {
          usersSnap = await db.collection("users").where("gmail", "==", originalQuery).get();
        }
        if (!usersSnap.empty) userDoc = usersSnap.docs[0];
      } else {
        let usersSnap = await db.collection("users").where("roll_number", "==", originalQuery).get();
        if (usersSnap.empty && !isNaN(Number(originalQuery))) {
          usersSnap = await db.collection("users").where("roll_number", "==", Number(originalQuery)).get();
        }
        
        // Match both normal and parent phone fields across multiple potential BD formats (+880, 880, 01...)
        const digits = originalQuery.replace(/\D/g, '');
        if (usersSnap.empty && digits.length >= 9) {
          let phoneVariants: string[] = [];
          if (digits.length === 10) {
            phoneVariants = [`0${digits}`, `+880${digits}`, `880${digits}`, digits];
          } else if (digits.length === 11 && digits.startsWith('0')) {
            const base = digits.substring(1);
            phoneVariants = [digits, `+880${base}`, `880${base}`, base];
          } else if (digits.length === 13 && digits.startsWith('880')) {
            const base = digits.substring(3);
            phoneVariants = [`0${base}`, `+880${base}`, digits, base];
          } else if (digits.length === 14 && digits.startsWith('880')) {
            const base = digits.substring(4);
            phoneVariants = [`0${base}`, `+880${base}`, digits, base];
          } else {
            phoneVariants = [originalQuery, digits];
          }
          
          for (const variant of phoneVariants) {
            usersSnap = await db.collection("users").where("phone", "==", variant).get();
            if (!usersSnap.empty) {
              userDoc = usersSnap.docs[0];
              break;
            }
            usersSnap = await db.collection("users").where("guardian_phone", "==", variant).get();
            if (!usersSnap.empty) {
              userDoc = usersSnap.docs[0];
              break;
            }
          }
        }
        
        if (!userDoc && !usersSnap.empty) {
          userDoc = usersSnap.docs[0];
        }
      }

      // Check if enrolled user
      if (!userDoc) {
        return res.status(404).json({ error: "No student account found. Please ensure you are enrolled." });
      }
      
      const userData = userDoc.data();
      const targetEmail = userData.email || userData.gmail;
      if (!targetEmail) {
        return res.status(400).json({ error: "Your account does not have a registered email address. Contact admin to update." });
      }
      const cleanEmail = targetEmail.toLowerCase().trim();
      const uid = userDoc.id;

      // Generate a 6-digit verification code
      const verificationCode = Math.floor(100000 + Math.random() * 900000).toString();
      const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString(); // 10 minutes

      // Store reset info using lowercase email as key
      await db.collection("password_resets").doc(cleanEmail).set({
        code: verificationCode,
        expiresAt,
        uid,
      });

      // Send code via SMTP
      await sendSmtpEmail({
        to: cleanEmail,
        subject: "Password Reset Verification Code - Jaber Math Care",
        db,
        html: `
          <div style="font-family: sans-serif; padding: 25px; color: #333; line-height: 1.6; max-width: 500px; margin: 0 auto; border: 1px solid #e2e8f0; border-radius: 16px;">
            <h2 style="color: #ea580c; border-bottom: 2px solid #ffedd5; padding-bottom: 10px;">Reset Your Password</h2>
            <p>Dear Student / User,</p>
            <p>You requested a verification code to reset your password for your Jaber Math Care account.</p>
            <div style="background-color: #fff7ed; border: 1px solid #ffedd5; border-radius: 12px; padding: 15px; margin: 20px 0; text-align: center;">
              <span style="font-family: monospace; font-size: 32px; font-weight: 900; color: #ea580c; letter-spacing: 0.1em;">${verificationCode}</span>
            </div>
            <p style="color: #64748b; font-size: 13px;">This verification code is valid for <strong>10 minutes</strong>. If you did not make this request, please ignore other actions.</p>
            <p style="border-top: 1px solid #e2e8f0; padding-top: 15px; font-size: 12px; color: #94a3b8; text-align: center;">Thank you • Jaber Math Care Team</p>
          </div>
        `
      });

      res.json({ success: true, email: cleanEmail });
    } catch (error: any) {
      console.error("Forgot password request error:", error);
      res.status(500).json({ error: error.message || "Failed to process forgot password request" });
    }
  });

  app.post("/api/forgot-password/verify", async (req, res) => {
    try {
      const { email, code } = req.body;
      if (!email || !code) {
        return res.status(400).json({ error: "Email and verification code are required." });
      }

      const cleanEmail = email.toLowerCase().trim();
      const resetDoc = await db.collection("password_resets").doc(cleanEmail).get();
      if (!resetDoc.exists) {
        return res.status(400).json({ error: "Verification code has expired or is invalid." });
      }

      const resetData = resetDoc.data();
      if (resetData?.code !== code.trim()) {
        return res.status(400).json({ error: "Invalid verification code. Please check and try again." });
      }

      if (new Date(resetData?.expiresAt) < new Date()) {
        return res.status(400).json({ error: "Verification code has expired." });
      }

      res.json({ success: true, verified: true });
    } catch (error: any) {
      console.error("Forgot password verify error:", error);
      res.status(500).json({ error: error.message || "Failed to verify code" });
    }
  });

  app.post("/api/forgot-password/reset", async (req, res) => {
    try {
      const { email, code, newPassword } = req.body;
      if (!email || !code || !newPassword) {
        return res.status(400).json({ error: "Email, code and new password are required." });
      }

      const cleanEmail = email.toLowerCase().trim();
      const resetDoc = await db.collection("password_resets").doc(cleanEmail).get();
      if (!resetDoc.exists) {
        return res.status(400).json({ error: "Verification code expired or is invalid." });
      }

      const resetData = resetDoc.data();
      if (resetData?.code !== code.trim()) {
        return res.status(400).json({ error: "Invalid verification code." });
      }

      if (new Date(resetData?.expiresAt) < new Date()) {
        return res.status(400).json({ error: "Verification code has expired." });
      }

      // Update in Firebase Auth using Admin SDK
      const uid = resetData?.uid;
      await admin.auth().updateUser(uid, { password: newPassword });

      // Clean reset doc
      await db.collection("password_resets").doc(cleanEmail).delete();

      // Send confirmation email
      await sendSmtpEmail({
        to: cleanEmail,
        subject: "Your password has been reset - Jaber Math Care",
        db,
        html: `
          <div style="font-family: sans-serif; padding: 25px; color: #333; line-height: 1.6; max-width: 500px; margin: 0 auto; border: 1px solid #e2e8f0; border-radius: 16px;">
            <p>Dear Student / User,</p>
            <p>Your password for Jaber Math Care has been successfully changed.</p>
            <p>You can now sign in using your new password. If you didn't perform this transaction, please contact us immediately.</p>
            <p style="border-top: 1px solid #e2e8f0; padding-top: 15px; font-size: 12px; color: #94a3b8; text-align: center;">Thank you • Jaber Math Care Team</p>
          </div>
        `
      });

      res.json({ success: true });
    } catch (error: any) {
      console.error("Forgot password reset error:", error);
      res.status(500).json({ error: error.message || "Failed to reset password" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(
      express.static(distPath, {
        setHeaders: (res, path) => {
          if (path.endsWith(".html")) {
            res.set(
              "Cache-Control",
              "no-store, no-cache, must-revalidate, proxy-revalidate",
            );
            res.set("Pragma", "no-cache");
            res.set("Expires", "0");
          }
        },
      }),
    );
    app.get("*", (req, res) => {
      res.setHeader(
        "Cache-Control",
        "no-store, no-cache, must-revalidate, proxy-revalidate",
      );
      res.setHeader("Pragma", "no-cache");
      res.setHeader("Expires", "0");
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
export { db, admin };
