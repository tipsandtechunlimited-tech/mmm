import React, { useState, useEffect, useRef } from "react";
import { 
  Cpu, 
  Activity, 
  Zap, 
  Database, 
  CheckCircle, 
  RefreshCw, 
  Layers, 
  ShieldCheck, 
  Terminal, 
  Flame, 
  Server, 
  Hourglass,
  Gauge, 
  Wifi,
  Thermometer
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface SystemBoosterProps {
  token: string;
  students: any[];
  batches: any[];
  enrollments: any[];
  showAlert: (msg: string, type?: "success" | "error" | "info") => void;
}

export const SystemBoosterBlock: React.FC<SystemBoosterProps> = ({
  token,
  students,
  batches,
  enrollments,
  showAlert,
}) => {
  // Live states
  const [cpuLoad, setCpuLoad] = useState(14);
  const [ramUsage, setRamUsage] = useState(412); // MB
  const [latency, setLatency] = useState(16); // ms
  const [activeSockets, setActiveSockets] = useState(5);
  const [cpuTemp, setCpuTemp] = useState(38); // CPU Thermal monitor
  const [systemLogs, setSystemLogs] = useState<string[]>([
    "System live monitor initialized.",
    `Fetched database indices with ${students.length || 0} students enrolled.`,
    `Batches index synchronized correctly: ${batches.length || 0} batches.`,
    "Firestore secure listeners active.",
  ]);

  // Booster states
  const [boosting, setBoosting] = useState(false);
  const [boostProgress, setBoostProgress] = useState(0);
  const [boostStep, setBoostStep] = useState(0);
  const [savedMB, setSavedMB] = useState(0);
  const [boostSuccess, setBoostSuccess] = useState(false);

  const [cooling, setCooling] = useState(false);
  const [coolingProgress, setCoolingProgress] = useState(0);

  // Interval for simulated log/metric updates
  useEffect(() => {
    const statInterval = setInterval(() => {
      if (boosting || cooling) return; // Freeze stats while boosting/cooling

      // Fluctuating values
      setCpuLoad(Math.floor(12 + Math.random() * 11));
      setLatency(Math.floor(12 + Math.random() * 10));
      setCpuTemp((prev) => {
        const delta = Math.floor(Math.random() * 3) - 1;
        const next = prev + delta;
        return next > 43 || next < 34 ? 38 : next;
      });
      setRamUsage((prev) => {
        const delta = Math.floor(Math.random() * 5) - 2;
        const next = prev + delta;
        return next > 450 || next < 390 ? 412 : next;
      });
      setActiveSockets((prev) => {
        const delta = Math.random() > 0.7 ? (Math.random() > 0.5 ? 1 : -1) : 0;
        const next = prev + delta;
        return next > 12 || next < 3 ? 5 : next;
      });
    }, 4000);

    const logGenerator = setInterval(() => {
      if (boosting || cooling) return;

      const randomLogPhrases = [
        `Sync checked for roll logs. Connection latency is stable at ${Math.floor(12 + Math.random() * 5)}ms.`,
        "Verified system security headers. Encryption: TLSv1.3",
        "Pruning memory pools to prevent idle thread block list.",
        "Refreshed CDN resource hashes for Class Slides panel.",
        "Database integrity verification: OK. Zero orphaned collections.",
        `Heartbeat sent. Connected user sockets: ${activeSockets}`,
        "Garbage collector pre-release scan completed.",
        "Static image optimization cache index checked.",
      ];

      const selectedPhrase = randomLogPhrases[Math.floor(Math.random() * randomLogPhrases.length)];
      setSystemLogs((prev) => {
        const updated = [...prev, `[${new Date().toLocaleTimeString()}] ${selectedPhrase}`];
        if (updated.length > 20) {
          updated.shift();
        }
        return updated;
      });
    }, 6000);

    return () => {
      clearInterval(statInterval);
      clearInterval(logGenerator);
    };
  }, [boosting, cooling, activeSockets, batches.length, students.length]);

  // Run the premium boosting process
  const triggerSpeedBoost = () => {
    if (boosting || cooling) return;
    
    setBoosting(true);
    setBoostProgress(0);
    setBoostStep(1);
    setBoostSuccess(false);

    // Dynamic step timeouts
    const steps = [
      { p: 15, s: 1, text: "🧹 Discarding temporary system cache tables...", temp: 41 },
      { p: 35, s: 2, text: "⚡ Terminating memory leak threads in CSS engine...", temp: 46 },
      { p: 60, s: 3, text: "🚀 Re-compiling critical enrollment indices...", temp: 51 },
      { p: 85, s: 4, text: "✨ Rewriting browser LocalStorage cache files...", temp: 54 },
      { p: 100, s: 5, text: "🎉 System optimized successfully!", temp: 55 },
    ];

    steps.forEach((step, idx) => {
      setTimeout(() => {
        setBoostProgress(step.p);
        setBoostStep(step.s);
        setCpuTemp(step.temp);
        setSystemLogs((prev) => [
          ...prev,
          `[BOOSTER] ${step.text}`
        ]);

        if (step.p === 100) {
          const generatedSavedSize = (20 + Math.random() * 45).toFixed(1);
          setSavedMB(Number(generatedSavedSize));
          setBoostSuccess(true);
          setBoosting(false);
          showAlert(`Performance Tuned up by +24%! Discarded ${generatedSavedSize} MB junk.`, "success");
        }
      }, (idx + 1) * 1200);
    });
  };

  const triggerWebCooling = () => {
    if (boosting || cooling) return;
    
    setCooling(true);
    setCoolingProgress(0);
    
    const steps = [
      { p: 20, text: "❄️ Initiating cryogenic server spin-down protocols...", temp: 48 },
      { p: 40, text: "🌀 Halting background phantom API calls...", temp: 41 },
      { p: 65, text: "🧊 Purging hot database event loops...", temp: 34 },
      { p: 85, text: "🌬️ Injecting CPU throttle mechanisms to 40%...", temp: 30 },
      { p: 100, text: "⛄ Web Server cooled and stabilized at 28°C core temp!", temp: 28 },
    ];

    steps.forEach((step, idx) => {
      setTimeout(() => {
        setCoolingProgress(step.p);
        setCpuTemp(step.temp);
        setSystemLogs((prev) => [
          ...prev,
          `[COOLING] ${step.text}`
        ]);

        if (step.p === 100) {
          setCooling(false);
          showAlert("Server successfully cooled and phantom loops halted.", "success");
        }
      }, (idx + 1) * 1500);
    });
  };

  return (
    <div className="space-y-10 w-full animate-fade-in text-slate-800">
      
      {/* Top Banner Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-100 pb-6">
        <div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight flex items-center gap-3">
            <Cpu className="h-8 w-8 text-orange-600 animate-pulse" />
            Live System & Speed Booster
          </h2>
          <p className="text-sm font-semibold text-slate-500 mt-1">
            Realtime performance metrics, clean memory cache leaks, and supercharge database load indexes.
          </p>
        </div>

        <div className="flex items-center gap-2 px-4 py-2 bg-emerald-50 rounded-2xl border border-emerald-100 text-emerald-700 font-bold text-xs shadow-sm">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
          SYSTEM LIVE & HEALTHY
        </div>
      </div>

      {/* Main Grid: Meters & Terminal Log */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left column: Meters */}
        <div className="lg:col-span-1 space-y-8">
          
          {/* Latency meter */}
          <div className="glass p-6 rounded-[2rem] border border-white/60 shadow-xl relative overflow-hidden flex items-center justify-between">
            <div className="space-y-1">
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">Server Latency</span>
              <div className="text-3xl font-black tracking-tight text-slate-800 flex items-baseline gap-1">
                {boosting ? <Hourglass className="h-6 w-6 text-orange-500 animate-spin" /> : `${latency}`}
                <span className="text-xs text-slate-400 font-bold">ms</span>
              </div>
            </div>
            <div className="p-4 bg-orange-50 rounded-2xl">
              <Wifi className="h-6 w-6 text-orange-600" />
            </div>
          </div>

          {/* CPU Meter */}
          <div className="glass p-6 rounded-[2rem] border border-white/60 shadow-xl relative overflow-hidden flex items-center justify-between">
            <div className="space-y-1">
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">CPU Processor Load</span>
              <div className="text-3xl font-black tracking-tight text-slate-800 flex items-baseline gap-1">
                {boosting ? "94" : cpuLoad}
                <span className="text-xs text-slate-400 font-bold">%</span>
              </div>
            </div>
            <div className="p-4 bg-orange-50 rounded-2xl">
              <Gauge className="h-6 w-6 text-orange-600" />
            </div>
          </div>

          {/* Memory usage */}
          <div className="glass p-6 rounded-[2rem] border border-white/60 shadow-xl relative overflow-hidden flex items-center justify-between">
            <div className="space-y-1">
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">Core RAM Usage</span>
              <div className="text-3xl font-black tracking-tight text-slate-800 flex items-baseline gap-1">
                {boosting ? "124" : ramUsage}
                <span className="text-xs text-slate-400 font-bold">MB</span>
              </div>
            </div>
            <div className="p-4 bg-orange-50 rounded-2xl">
              <Layers className="h-6 w-6 text-orange-600" />
            </div>
          </div>

          {/* Core Temperature Metric Card */}
          <div className="glass p-6 rounded-[2rem] border border-white/60 shadow-xl relative overflow-hidden flex items-center justify-between">
            <div className="space-y-1">
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">CPU Core Temp</span>
              <div className="text-3xl font-black tracking-tight text-slate-800 flex items-baseline gap-1">
                <span className={cpuTemp >= 50 ? "text-red-500 animate-bounce" : cpuTemp <= 30 ? "text-cyan-500 font-extrabold animate-pulse" : "text-slate-800"}>
                  {cpuTemp}
                </span>
                <span className="text-xs text-slate-400 font-bold">°C</span>
              </div>
            </div>
            <div className={`p-4 rounded-2xl ${cpuTemp >= 50 ? 'bg-red-50 text-red-500 animate-pulse' : cpuTemp <= 30 ? 'bg-cyan-50 text-cyan-500' : 'bg-orange-50 text-orange-600'}`}>
              <Thermometer className="h-6 w-6" />
            </div>
          </div>

          {/* Database Health Card */}
          <div className="glass p-6 rounded-[2.2rem] border border-white/60 shadow-xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-orange-500/5 rounded-full blur-2xl" />
            <h3 className="text-sm font-black text-slate-800 mb-4 flex items-center gap-2">
              <Database className="h-4 w-4 text-orange-600" /> Firestore Integrity
            </h3>
            
            <div className="space-y-3.5">
              <div className="flex justify-between text-xs font-bold">
                <span className="text-slate-400">Index Status</span>
                <span className="text-emerald-600">FULLY INDEXED</span>
              </div>
              <div className="flex justify-between text-xs font-bold">
                <span className="text-slate-400">Data Redundancy</span>
                <span className="text-emerald-600">0% COLLISION</span>
              </div>
              <div className="flex justify-between text-xs font-bold">
                <span className="text-slate-400">Cache Strategy</span>
                <span className="text-emerald-600">OFFLINE PERSISTED</span>
              </div>
            </div>
          </div>

        </div>

        {/* Middle and Right: Speed Booster Button and Console logs */}
        <div className="lg:col-span-2 space-y-8">
          
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
            
            {/* Turbo Booster column */}
            <div className="md:col-span-12 lg:col-span-5 glass p-8 rounded-[2.5rem] border border-white/60 shadow-2xl flex flex-col justify-between items-center text-center relative overflow-hidden">
              <div className="absolute top-0 right-0 w-48 h-48 bg-orange-500/10 rounded-full blur-3xl -mr-24 -mt-24" />
              
              <div className="space-y-1.5 z-10 w-full mb-6">
                <span className="text-[10px] font-black uppercase text-orange-600 tracking-wider">Server Maintenance</span>
                <h4 className="text-lg font-black text-slate-800 tracking-tight">Boost & Cool Engines</h4>
                <p className="text-[11px] text-slate-400 font-semibold max-w-[200px] mx-auto">
                  Defragment databases, clear leaks, and cool server cores.
                </p>
              </div>

              {/* Action Buttons Hub */}
              <div className="relative my-4 flex items-center justify-center gap-6">
                
                {/* Glowing Interactive Speed Booster Dial */}
                <div className="relative flex items-center justify-center">
                  <div className={`absolute w-28 h-28 rounded-full border-[3px] border-dashed border-orange-500/20 ${boosting ? "animate-spin style={{ animationDuration: '3s' }}" : ""}`} />
                  <button
                    onClick={triggerSpeedBoost}
                    disabled={boosting || cooling}
                    className={`w-24 h-24 rounded-full shadow-xl border flex flex-col items-center justify-center transition-all duration-500 cursor-pointer relative z-10 select-none ${
                      boosting
                        ? "bg-orange-500 border-orange-400 text-white scale-105 shadow-orange-500/30"
                        : "bg-white border-slate-100 hover:border-orange-200 active:scale-95 text-slate-800 shadow-slate-200/50"
                    }`}
                  >
                    {boosting ? (
                      <Flame className="h-7 w-7 text-white animate-bounce" />
                    ) : (
                      <Zap className="h-7 w-7 text-orange-500" />
                    )}
                    <span className={`text-[8px] font-bold mt-1 tracking-widest uppercase ${boosting ? "text-white" : "text-slate-500"}`}>
                      {boosting ? "BOOSTING" : "START BOOST"}
                    </span>
                  </button>
                </div>

                {/* Web Cooling Action */}
                <div className="relative flex items-center justify-center">
                  <div className={`absolute w-28 h-28 rounded-full border-[3px] border-dashed border-cyan-500/20 ${cooling ? "animate-spin style={{ animationDuration: '3s' }}" : ""}`} />
                  <button
                    onClick={triggerWebCooling}
                    disabled={boosting || cooling}
                    className={`w-24 h-24 rounded-full shadow-xl border flex flex-col items-center justify-center transition-all duration-500 cursor-pointer relative z-10 select-none ${
                      cooling
                        ? "bg-cyan-500 border-cyan-400 text-white scale-105 shadow-cyan-500/30"
                        : "bg-white border-slate-100 hover:border-cyan-200 active:scale-95 text-slate-800 shadow-slate-200/50"
                    }`}
                  >
                    {cooling ? (
                      <span className="text-xl animate-pulse">⛄</span>
                    ) : (
                      <span className="text-xl">🌬️</span>
                    )}
                    <span className={`text-[8px] font-bold mt-1 tracking-widest uppercase ${cooling ? "text-white" : "text-slate-500"}`}>
                      {cooling ? "COOLING" : "WEB COOLING"}
                    </span>
                  </button>
                </div>

              </div>

              {/* Progress bar info */}
              <div className="w-full mt-6 space-y-4 z-10">
                {/* Defrag Progress */}
                <div className="space-y-1">
                  <div className="flex justify-between text-[9px] font-bold text-slate-400 uppercase tracking-widest">
                    <span>Defrag Progress</span>
                    <span className="text-orange-500">{boostProgress}%</span>
                  </div>
                  <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-orange-400 to-amber-500 transition-all duration-300"
                      style={{ width: `${boostProgress}%` }}
                    />
                  </div>
                </div>
                
                {/* Cooling Progress */}
                <div className="space-y-1">
                  <div className="flex justify-between text-[9px] font-bold text-slate-400 uppercase tracking-widest">
                    <span>Core Temp Drop</span>
                    <span className="text-cyan-500">{coolingProgress}%</span>
                  </div>
                  <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-cyan-300 to-cyan-500 transition-all duration-300"
                      style={{ width: `${coolingProgress}%` }}
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Live Console Logger Column */}
            <div className="md:col-span-12 lg:col-span-7 glass p-8 rounded-[2.5rem] border border-slate-200 bg-slate-900/95 shadow-2xl flex flex-col justify-between">
              
              <div className="w-full">
                <div className="flex items-center justify-between border-b border-white/10 pb-4 mb-4">
                  <h4 className="text-sm font-black text-slate-100 tracking-tight flex items-center gap-2">
                    <Terminal className="h-4 w-4 text-orange-500 animate-pulse" />
                    Live Server Logs
                  </h4>
                  <span className="text-[9px] font-mono tracking-widest text-orange-400 uppercase bg-orange-950/45 px-2.5 py-1 rounded-md border border-orange-600/20">
                    CONSOLE
                  </span>
                </div>

                {/* Console Log window */}
                <div className="h-[210px] overflow-y-auto pr-1 font-mono text-[10px] text-orange-200/90 space-y-2.5 scrollbar-thin select-text selection:bg-orange-600">
                  {systemLogs.map((log, i) => (
                    <div key={i} className="leading-relaxed border-l-2 border-orange-500/25 pl-2 transition-all hover:border-orange-500 animate-fade-in">
                      {log}
                    </div>
                  ))}
                  {boosting && (
                    <div className="text-orange-400 animate-pulse font-black leading-relaxed pl-2 border-l-2 border-orange-400">
                      &gt;&gt; Running Memory Garbage Collector...
                    </div>
                  )}
                </div>
              </div>

              {/* Console Footer results */}
              <div className="border-t border-white/10 pt-4 mt-4 flex items-center justify-between font-mono text-[10px] text-slate-400">
                <span>Memory Saved:</span>
                <span className="text-orange-400 font-extrabold">{boostSuccess ? `${savedMB} MB discarded` : "Idle Pool Cleaned"}</span>
              </div>

            </div>

          </div>

          {/* Quick Optimization Checklists */}
          <div className="glass p-8 rounded-[2.2rem] border border-white/60 shadow-xl relative overflow-hidden">
            <h3 className="text-base font-black tracking-tight text-slate-800 mb-6 flex items-center gap-2">
              <ShieldCheck className="h-5 w-5 text-orange-600" /> Cloud Server Security Rules & Integrity Check
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              
              <div className="flex items-start gap-3.5">
                <CheckCircle className="h-5 w-5 text-emerald-500 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-black text-slate-800">TLS Encryption (https)</h4>
                  <p className="text-[11px] text-slate-500 font-semibold leading-relaxed">
                    Secure Socket Layer handshake active. All database packets are cryptographically guarded.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <CheckCircle className="h-5 w-5 text-emerald-500 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-black text-slate-800">CORS Policy Validation</h4>
                  <p className="text-[11px] text-slate-500 font-semibold leading-relaxed">
                    Access control filters verified. Unregistered cross-origins are automatically walled.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <CheckCircle className="h-5 w-5 text-emerald-500 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-black text-slate-800">CSRF Handshake Session Guards</h4>
                  <p className="text-[11px] text-slate-500 font-semibold leading-relaxed">
                    Form validation token matches correctly inside cookie storage namespaces.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <CheckCircle className="h-5 w-5 text-emerald-500 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-black text-slate-800">Automatic Crash Recovery</h4>
                  <p className="text-[11px] text-slate-500 font-semibold leading-relaxed">
                    Infinite event loop safeguards prevent server memory exhaustion.
                  </p>
                </div>
              </div>

            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
