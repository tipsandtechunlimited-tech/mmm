const fs = require('fs');
const path = require('path');

function copyRecursiveSync(src, dest) {
  const exists = fs.existsSync(src);
  const stats = exists && fs.statSync(src);
  const isDirectory = exists && stats.isDirectory();
  if (isDirectory) {
    if (!fs.existsSync(dest)) fs.mkdirSync(dest);
    fs.readdirSync(src).forEach(function(childItemName) {
      copyRecursiveSync(path.join(src, childItemName),
                        path.join(dest, childItemName));
    });
  } else {
    fs.copyFileSync(src, dest);
  }
}

copyRecursiveSync('./temp_clone/src', './src');
copyRecursiveSync('./temp_clone/package.json', './package.json');
copyRecursiveSync('./temp_clone/server.ts', './server.ts');
copyRecursiveSync('./temp_clone/index.html', './index.html');
copyRecursiveSync('./temp_clone/vite.config.ts', './vite.config.ts');
copyRecursiveSync('./temp_clone/tsconfig.json', './tsconfig.json');
