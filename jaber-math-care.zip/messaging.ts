import nodemailer from 'nodemailer';
import fetch from 'node-fetch';
import { initializeApp, getApps } from 'firebase/app';
import { getFirestore, doc, getDoc, collection, addDoc, getDocs } from 'firebase/firestore';
import fs from 'fs';
import path from 'path';

let clientDbInstance: any = null;

const getClientFirestoreDb = () => {
  if (!clientDbInstance) {
    try {
      const configPath = path.join(process.cwd(), "firebase-applet-config.json");
      if (fs.existsSync(configPath)) {
        const firebaseConfig = JSON.parse(fs.readFileSync(configPath, "utf-8"));
        // Avoid initializing multiple times
        const apps = getApps();
        const app = apps.length > 0 ? apps[0] : initializeApp(firebaseConfig, "MessagingClientApp");
        const dbId = firebaseConfig.firestoreDatabaseId === "(default)" ? undefined : firebaseConfig.firestoreDatabaseId;
        clientDbInstance = getFirestore(app, dbId);
        console.log("[SMTP Helper] Client Firestore database initialized successfully on server.");
      } else {
        console.warn("[SMTP Helper] firebase-applet-config.json not found.");
      }
    } catch (e: any) {
      console.error("[SMTP Helper] Client Firestore initialization failed:", e.message);
    }
  }
  return clientDbInstance;
};

export interface MailOptions {
  to: string;
  subject: string;
  html: string;
  fromName?: string;
  smtp_email?: string;
  smtp_password?: string;
  bcc?: string;
  db: any;
}

export const sendSmtpEmail = async ({
  to,
  subject,
  html,
  fromName = 'Jaber Math Care',
  smtp_email,
  smtp_password,
  bcc,
  db
}: MailOptions) => {
  const recipient = (to || '').trim().toLowerCase();

  if (!recipient || !recipient.includes('@')) {
    console.log(`[SMTP Helper] Invalid recipient: ${to}`);
    return { success: false, error: 'Invalid recipient' };
  }

  let user = smtp_email;
  let pass = smtp_password;
  let logoUrl = 'https://cdn-icons-png.flaticon.com/512/4136/4136012.png'; // math education academy icon fallback
  let siteName = 'Jaber Math Care';
  let fbUrl = 'https://facebook.com';
  let ytUrl = 'https://youtube.com';

  const cDb = getClientFirestoreDb();
  if (cDb) {
    try {
      const [logoSnap, nameSnap, fbSnap, ytSnap] = await Promise.all([
        getDoc(doc(cDb, "settings", "logo_url")),
        getDoc(doc(cDb, "settings", "site_name")),
        getDoc(doc(cDb, "settings", "facebook_url")),
        getDoc(doc(cDb, "settings", "youtube_url"))
      ]);
      if (logoSnap.exists() && logoSnap.data()?.value) logoUrl = logoSnap.data().value;
      if (nameSnap.exists() && nameSnap.data()?.value) siteName = nameSnap.data().value;
      if (fbSnap.exists() && fbSnap.data()?.value) fbUrl = fbSnap.data().value;
      if (ytSnap.exists() && ytSnap.data()?.value) ytUrl = ytSnap.data().value;
    } catch (e: any) {
      console.warn("[SMTP Helper] Client SDK brand settings load warn:", e.message);
    }
  }

  // Retrieve settings via client SDK to bypass GCP credentials issue
  if (!user || !pass) {
    if (cDb) {
      try {
        console.log("[SMTP Helper] Fetching SMTP settings using Client SDK...");
        const [emailSnap, passSnap] = await Promise.all([
          getDoc(doc(cDb, "settings", "smtp_email")),
          getDoc(doc(cDb, "settings", "smtp_password"))
        ]);
        if (emailSnap.exists()) {
          user = emailSnap.data()?.value;
        }
        if (passSnap.exists()) {
          pass = passSnap.data()?.value;
        }

        if (!user || !pass) {
          const snapshot = await getDocs(collection(cDb, "settings"));
          const settings: any = {};
          snapshot.forEach((d) => {
            settings[d.id] = d.data().value;
          });
          user = user || settings.smtp_email;
          pass = pass || settings.smtp_password;
        }
      } catch (clientErr: any) {
        console.error("[SMTP Helper] Client SDK fetch failed, falling back to Admin SDK:", clientErr.message);
      }
    }

    // Admin SDK fallback
    if (!user || !pass) {
      try {
        const emailDoc = await db.collection('settings').doc('smtp_email').get();
        const passDoc = await db.collection('settings').doc('smtp_password').get();
        user = emailDoc.exists ? emailDoc.data()?.value : undefined;
        pass = passDoc.exists ? passDoc.data()?.value : undefined;

        if (!user || !pass) {
          const snap = await db.collection('settings').get();
          const settings: any = {};
          snap.forEach((doc: any) => { settings[doc.id] = doc.data().value; });
          user = user || settings.smtp_email;
          pass = pass || settings.smtp_password;
          if (settings.logo_url) logoUrl = settings.logo_url;
          if (settings.site_name) siteName = settings.site_name;
          if (settings.facebook_url) fbUrl = settings.facebook_url;
          if (settings.youtube_url) ytUrl = settings.youtube_url;
        }
      } catch (e: any) {
        console.error('[SMTP Helper] DB Settings Error:', e.message);
      }
    }
  }

  if (!user || !pass) {
    console.error('[SMTP Helper] SMTP Credentials missing');
    return { success: false, error: 'SMTP Credentials missing' };
  }

  // Double check admin SDK fallback values for header info
  if (db && (!logoUrl || siteName === 'Jaber Math Care')) {
    try {
      const [logoDoc, nameDoc, fbDoc, ytDoc] = await Promise.all([
        db.collection('settings').doc('logo_url').get(),
        db.collection('settings').doc('site_name').get(),
        db.collection('settings').doc('facebook_url').get(),
        db.collection('settings').doc('youtube_url').get()
      ]);
      if (logoDoc.exists && logoDoc.data()?.value) logoUrl = logoDoc.data().value;
      if (nameDoc.exists && nameDoc.data()?.value) siteName = nameDoc.data().value;
      if (fbDoc.exists && fbDoc.data()?.value) fbUrl = fbDoc.data().value;
      if (ytDoc.exists && ytDoc.data()?.value) ytUrl = ytDoc.data().value;
    } catch (e) {}
  }

  const trimmedUser = user.trim();
  const trimmedPass = pass.trim().replace(/\s+/g, '');

  // Wrap the HTML content in a breathtaking premium email card framework
  let preparedHtml = html;
  if (html && !html.includes('<p>') && !html.includes('</div>') && !html.includes('<br')) {
    preparedHtml = html.replace(/\n/g, '<br />');
  }

  let finalHtml = preparedHtml;
  if (!html.includes('<body') && !html.includes('wrap-brand-framework')) {
    finalHtml = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${subject}</title>
</head>
<body class="wrap-brand-framework" style="margin:0; padding:0; background-color:#f1f5f9; font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; -webkit-font-smoothing: antialiased;">
  <table border="0" cellpadding="0" cellspacing="0" width="100%" style="table-layout:fixed; background-color:#f1f5f9; padding: 25px 0;">
    <tr>
      <td align="center">
        <!-- Card Container -->
        <table border="0" cellpadding="0" cellspacing="0" width="550" style="margin:20px auto; background-color:#ffffff; border-radius:24px; overflow:hidden; box-shadow:0 12px 24px -4px rgba(15,23,42,0.06); border:1px solid #e2e8f0; width: 100%; max-width: 550px;">
          <!-- Top Accent Bar -->
          <tr>
            <td height="6" style="background: linear-gradient(90deg, #4f46e5, #3b82f6);"></td>
          </tr>
          <!-- Design Header -->
          <tr>
            <td align="center" style="padding:40px 30px 20px 30px; text-align:center;">
              <img src="${logoUrl}" alt="${siteName} Logo" width="75" height="75" style="width:75px; height:75px; object-fit:contain; border-radius:20px; display:block; margin: 0 auto 12px auto; box-shadow: 0 4px 10px rgba(0,0,0,0.05); border: 2px solid #f1f5f9;" />
              <div style="font-size:22px; font-weight:800; color:#0f172a; margin:0; letter-spacing: -0.025em; font-family: sans-serif;">${siteName}</div>
              <div style="font-size:10px; font-weight:700; color:#64748b; margin:3px 0 0 0; text-transform:uppercase; letter-spacing:0.15em; font-family: sans-serif;">The Future of Math Education</div>
            </td>
          </tr>
          <!-- Elegant Line Divider -->
          <tr>
            <td style="padding: 0 35px;">
              <div style="border-bottom: 1px solid #f1f5f9;"></div>
            </td>
          </tr>
          <!-- Body Message Area -->
          <tr>
            <td style="padding:35px 35px 30px 35px; color:#334155; font-size:15px; line-height:1.6; text-align:left; font-family: sans-serif;">
              ${preparedHtml}
            </td>
          </tr>
          <!-- Footer Branding Section -->
          <tr>
            <td style="padding:25px 35px 30px 35px; background-color:#f8fafc; border-top:1px solid #f1f5f9; text-align:center; font-family: sans-serif;">
              <div style="font-size:13px; font-weight:700; color:#1e293b; margin:0;">${siteName}</div>
              <div style="font-size:11px; color:#64748b; margin:4px 0 16px 0;">Where mathematical excellence meets engineering dreams.</div>
              
              <!-- Social Links -->
              <table border="0" cellpadding="0" cellspacing="0" align="center" style="margin: 0 auto;">
                <tr>
                  ${fbUrl ? `
                  <td style="padding: 0 8px;">
                    <a href="${fbUrl}" target="_blank" style="text-decoration:none; font-size:12px; color:#4f46e5; font-weight:700;">Facebook</a>
                  </td>` : ''}
                  ${fbUrl && ytUrl ? `<td style="padding: 0 4px; color:#cbd5e1; font-size:11px;">•</td>` : ''}
                  ${ytUrl ? `
                  <td style="padding: 0 8px;">
                    <a href="${ytUrl}" target="_blank" style="text-decoration:none; font-size:12px; color:#4f46e5; font-weight:700;">YouTube</a>
                  </td>` : ''}
                </tr>
              </table>
              
              <div style="font-size:10px; color:#94a3b8; margin-top:24px;">
                This is an automated educational service message. All rights reserved © ${new Date().getFullYear()} ${siteName}.
              </div>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
    `;
  }

  const mailData: any = {
    from: { name: fromName, address: trimmedUser },
    to: recipient,
    subject,
    html: finalHtml,
  };

  if (bcc) mailData.bcc = bcc;

  // Try Port 465
  try {
    const transporter = nodemailer.createTransport({
      host: 'smtp.gmail.com',
      port: 465,
      secure: true,
      auth: { user: trimmedUser, pass: trimmedPass },
      tls: { rejectUnauthorized: false }
    });

    await transporter.sendMail(mailData);
    console.log(`[SMTP Helper] Sent to ${recipient} via 465`);
    
    // Log using Client SDK
    if (cDb) {
      await addDoc(collection(cDb, 'message_logs'), {
        type: 'EMAIL',
        to: recipient,
        subject,
        status: 'SUCCESS_465',
        timestamp: new Date().toISOString()
      }).catch(() => {});
    } else {
      await db.collection('message_logs').add({
        type: 'EMAIL',
        to: recipient,
        subject,
        status: 'SUCCESS_465',
        timestamp: new Date().toISOString()
      }).catch(() => {});
    }
    return { success: true };
  } catch (err465: any) {
    console.warn(`[SMTP Helper] 465 failed: ${err465.message}. Trying 587...`);
    
    // Try Port 587
    try {
      const transporter = nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 587,
        secure: false,
        requireTLS: true,
        auth: { user: trimmedUser, pass: trimmedPass },
        tls: { rejectUnauthorized: false }
      });
      await transporter.sendMail(mailData);
      console.log(`[SMTP Helper] Sent to ${recipient} via 587`);
      
      // Log using Client SDK
      if (cDb) {
        await addDoc(collection(cDb, 'message_logs'), {
          type: 'EMAIL',
          to: recipient,
          subject,
          status: 'SUCCESS_587',
          timestamp: new Date().toISOString()
        }).catch(() => {});
      } else {
        await db.collection('message_logs').add({
          type: 'EMAIL',
          to: recipient,
          subject,
          status: 'SUCCESS_587',
          timestamp: new Date().toISOString()
        }).catch(() => {});
      }
      return { success: true };
    } catch (err587: any) {
      console.error(`[SMTP Helper] All ports failed for ${recipient}: ${err587.message}`);
      
      // Log using Client SDK
      if (cDb) {
        await addDoc(collection(cDb, 'message_logs'), {
          type: 'EMAIL',
          to: recipient,
          subject,
          status: 'FAILED',
          error: err587.message,
          timestamp: new Date().toISOString()
        }).catch(() => {});
      } else {
        await db.collection('message_logs').add({
          type: 'EMAIL',
          to: recipient,
          subject,
          status: 'FAILED',
          error: err587.message,
          timestamp: new Date().toISOString()
        }).catch(() => {});
      }
      return { success: false, error: err587.message };
    }
  }
};

export const sendAutosms = async (phone: string, message: string, db: any) => {
  if (!phone || !phone.trim()) return;

  let cleanPhone = phone.trim().replace(/[^\d+]/g, '');
  if (cleanPhone.startsWith('+')) cleanPhone = cleanPhone.replace('+', '');
  if (cleanPhone.length === 11 && cleanPhone.startsWith('01')) cleanPhone = '88' + cleanPhone;

  try {
    let settings: any = {};
    const cDb = getClientFirestoreDb();

    if (cDb) {
      try {
        const snapshot = await getDocs(collection(cDb, "settings"));
        snapshot.forEach((d) => {
          settings[d.id] = d.data().value;
        });
      } catch (e) {
        console.error('[SMS Auto] Client SDK error reading settings, falling back to Admin SDK:', e);
      }
    }

    if (!settings.sms_api_url) {
      const snap = await db.collection('settings').get();
      snap.forEach((doc: any) => { settings[doc.id] = doc.data().value; });
    }

    if (!settings.sms_api_url) return;

    const url = new URL(settings.sms_api_url);
    if (settings.sms_api_key) url.searchParams.set('api_key', settings.sms_api_key);
    if (settings.sms_sender_id) url.searchParams.set('senderid', settings.sms_sender_id);
    url.searchParams.set('number', cleanPhone);
    url.searchParams.set('message', message);

    const res = await fetch(url.toString());
    const text = await res.text();
    console.log(`[SMS Auto] Response: ${text}`);
    
    if (cDb) {
      await addDoc(collection(cDb, 'message_logs'), {
        type: 'SMS',
        to: cleanPhone,
        status: 'SENT',
        response: text,
        timestamp: new Date().toISOString()
      }).catch(() => {});
    } else {
      await db.collection('message_logs').add({
        type: 'SMS',
        to: cleanPhone,
        status: 'SENT',
        response: text,
        timestamp: new Date().toISOString()
      }).catch(() => {});
    }
  } catch (e: any) {
    console.error('[SMS Auto] Error:', e.message);
  }
};
