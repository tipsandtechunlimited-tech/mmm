import React from 'react';
import { motion } from 'motion/react';
import { useSettings } from '../context/SettingsContext';
import { Plus, Minus, X, Divide, Hash, Percent, Variable, FunctionSquare } from 'lucide-react';

const FloatingSymbol = ({ icon: Icon, delay, x, y }: { icon: any, delay: number, x: string, y: string }) => (
  <motion.div
    className="absolute text-orange-500/20 pointer-events-none"
    style={{ left: x, top: y }}
    animate={{
      y: [0, -20, 0],
      rotate: [0, 360],
      opacity: [0.1, 0.3, 0.1],
    }}
    transition={{
      duration: 5 + Math.random() * 5,
      repeat: Infinity,
      delay: delay,
      ease: "easeInOut"
    }}
  >
    <Icon size={24 + Math.random() * 24} />
  </motion.div>
);

export default function LoadingSpinner() {
  const { settings } = useSettings();
  
  const siteName = settings.site_name || "Jaber Math Care";
  const parts = siteName.split(' ');
  const firstPart = parts[0];

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').substring(0, 3).toUpperCase();
  };
  const siteInitials = getInitials(siteName);

  return (
    <div className="flex-1 flex flex-col items-center justify-center gap-12 py-20 min-h-[60vh] relative overflow-hidden">
      {/* Background Decorative Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <FloatingSymbol icon={Plus} delay={0} x="10%" y="20%" />
        <FloatingSymbol icon={Minus} delay={1} x="85%" y="15%" />
        <FloatingSymbol icon={X} delay={2} x="15%" y="75%" />
        <FloatingSymbol icon={Divide} delay={3} x="80%" y="80%" />
        <FloatingSymbol icon={Hash} delay={4} x="50%" y="10%" />
        <FloatingSymbol icon={Percent} delay={5} x="45%" y="85%" />
        <FloatingSymbol icon={Variable} delay={1.5} x="25%" y="40%" />
        <FloatingSymbol icon={FunctionSquare} delay={2.5} x="75%" y="60%" />
      </div>

      {/* Math Grid Background */}
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none" 
           style={{ backgroundImage: 'radial-gradient(#ea580c 1px, transparent 1px)', backgroundSize: '30px 30px' }} />

      <div className="relative">
        {/* Pulsing Outer Glow */}
        <motion.div
          className="absolute inset-0 bg-orange-500/20 rounded-full blur-3xl"
          animate={{
            scale: [1, 1.8, 1],
            opacity: [0.2, 0.5, 0.2],
          }}
          transition={{
            duration: 4,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
        
        {/* Main Logo Container */}
        <motion.div
          className="relative w-32 h-32 md:w-40 md:h-40 bg-white rounded-[2.5rem] shadow-2xl flex items-center justify-center border-2 border-orange-100 overflow-hidden"
          animate={{
            y: [0, -15, 0],
            rotate: [0, 5, -5, 0]
          }}
          transition={{
            duration: 5,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        >
          {settings.logo_url ? (
            <img 
              src={settings.logo_url} 
              alt={siteName} 
              className="h-20 md:h-24 w-auto object-contain z-10" 
              referrerPolicy="no-referrer" 
            />
          ) : (
            <div className="h-20 md:h-24 px-6 bg-orange-50 rounded-2xl flex items-center justify-center border-2 border-orange-100">
              <span className="text-xl md:text-2xl font-black text-orange-600 truncate max-w-[200px]">{siteName}</span>
            </div>
          )}
          
          {/* Scanning Line */}
          <motion.div
            className="absolute inset-x-0 h-1 bg-gradient-to-r from-transparent via-orange-500 to-transparent z-20"
            animate={{
              top: ["-10%", "110%", "-10%"],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "linear",
            }}
          />

          {/* Rotating Border Effect */}
          <motion.div 
            className="absolute inset-0 border-4 border-orange-500/10 rounded-[2.5rem]"
            animate={{ rotate: 360 }}
            transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
          />
        </motion.div>
      </div>

      <div className="flex flex-col items-center gap-6 relative z-10">
        <div className="text-center space-y-3">
          <motion.h2 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-3xl md:text-4xl font-black text-orange-600 tracking-tight"
          >
            {siteName}
          </motion.h2>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="flex items-center justify-center gap-3"
          >
            <span className="h-px w-12 bg-orange-200" />
            <p className="text-orange-600 font-black text-[12px] uppercase tracking-[0.4em]">
              Solving Excellence
            </p>
            <span className="h-px w-12 bg-orange-200" />
          </motion.div>
        </div>

        {/* Progress Bar Style Loader */}
        <div className="w-64 h-2 bg-slate-100 rounded-full overflow-hidden relative shadow-inner">
          <motion.div
            className="absolute inset-y-0 left-0 bg-gradient-to-r from-orange-400 to-orange-600 rounded-full"
            animate={{
              left: ["-100%", "100%"],
            }}
            transition={{
              duration: 2.5,
              repeat: Infinity,
              ease: "easeInOut",
            }}
            style={{ width: "70%" }}
          />
        </div>
        
        <div className="flex flex-col items-center gap-2">
          <p className="text-slate-400 font-bold text-[10px] uppercase tracking-widest animate-pulse">
            Calculating your experience
          </p>
          <div className="flex gap-1">
            {[0, 1, 2].map(i => (
              <motion.div
                key={i}
                className="w-1 h-1 bg-orange-400 rounded-full"
                animate={{ scale: [1, 1.5, 1], opacity: [0.3, 1, 0.3] }}
                transition={{ duration: 1, repeat: Infinity, delay: i * 0.2 }}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
