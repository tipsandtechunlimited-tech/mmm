import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Bell, X, Calendar, ArrowRight } from "lucide-react";
import { useRealtimeCollection } from "../hooks/useRealtime";
import { Link } from "react-router-dom";

const FloatingNoticePopup = () => {
  const { data: notices } = useRealtimeCollection("notices");
  const [isVisible, setIsVisible] = useState(false);
  const [latestNotice, setLatestNotice] = useState<any>(null);

  useEffect(() => {
    if (notices && notices.length > 0) {
      // Sort to get the most recent notice
      const sortedNotices = [...notices].sort((a: any, b: any) => {
        const timeA = a.created_at ? new Date(a.created_at).getTime() : 0;
        const timeB = b.created_at ? new Date(b.created_at).getTime() : 0;
        return timeB - timeA;
      });

      const topNotice = sortedNotices[0];
      if (!topNotice) return;

      // Check if this particular notice has already been dismissed
      const dismissedNoticeId = localStorage.getItem("dismissed_notice_id");
      if (dismissedNoticeId === topNotice.id) {
        return; // Stay hidden as the user closed it
      }

      setLatestNotice(topNotice);
      // Wait slightly after page load so it transitions in gracefully
      const timer = setTimeout(() => setIsVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, [notices]);

  const handleClose = () => {
    setIsVisible(false);
    if (latestNotice) {
      localStorage.setItem("dismissed_notice_id", latestNotice.id);
    }
  };

  if (!latestNotice) return null;

  return (
    <AnimatePresence>
      {isVisible && (
        <div 
          id="floating-notice-panel"
          className="fixed bottom-6 right-6 z-[9999] p-4 max-w-md w-full pointer-events-auto"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 50, x: 50 }}
            animate={{ opacity: 1, scale: 1, y: 0, x: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20, x: 20 }}
            transition={{ type: "spring", stiffness: 260, damping: 25 }}
            className="relative bg-white border border-slate-200 rounded-[2rem] shadow-[0_20px_50px_rgba(0,0,0,0.15)] max-h-[80vh] flex flex-col overflow-hidden"
          >
            {/* Header / Accent Bar */}
            <div className="flex items-center justify-between px-8 pt-8 pb-4">
              <h3 className="text-3xl font-black text-slate-800 tracking-tight leading-tight pr-8">
                {latestNotice.title}
              </h3>
              <button
                onClick={handleClose}
                className="absolute top-6 right-6 text-slate-400 hover:text-slate-700 bg-slate-100 hover:bg-slate-200 transition-colors rounded-full p-2"
                aria-label="Dismiss announcement"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Title & Date */}
            <div className="px-8 pb-4 flex items-center gap-2 text-sm uppercase font-black tracking-widest text-slate-500">
              <Calendar className="h-4 w-4 text-orange-500" /> 
              {latestNotice.created_at ? new Date(latestNotice.created_at).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric', hour: 'numeric', minute: 'numeric' }) : ''}
            </div>
            
            {/* Scrollable Content */}
            <div className="px-8 pb-8 text-slate-700 text-base whitespace-pre-wrap leading-relaxed overflow-y-auto scrollbar-thin">
              {latestNotice.content}
            </div>

            {/* Action Buttons */}
            <div className="px-8 py-5 border-t border-slate-100 flex items-center justify-end gap-3 bg-slate-50">
              <button
                onClick={handleClose}
                className="px-6 py-3 bg-white text-slate-500 hover:text-slate-700 hover:bg-slate-50 font-extrabold rounded-xl transition-all tracking-widest uppercase border border-slate-200"
              >
                Close
              </button>
              <Link
                to="/notices"
                onClick={handleClose}
                className="flex items-center gap-2 px-8 py-3 bg-slate-900 border-2 border-slate-900 text-white font-extrabold rounded-xl hover:bg-white hover:text-slate-900 transition-all tracking-widest uppercase shadow-xl shadow-slate-900/10"
              >
                View All
              </Link>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default FloatingNoticePopup;
