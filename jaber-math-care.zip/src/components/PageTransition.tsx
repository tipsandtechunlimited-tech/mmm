import React, { useEffect } from 'react';
import { useLocation } from 'react-router-dom';

export default function PageTransition({ children }: { children: React.ReactNode }) {
  const location = useLocation();

  useEffect(() => {
    // Instant scroll to top without delay
    window.scrollTo(0, 0);
  }, [location.pathname]);

  return (
    <>
      {children}
    </>
  );
}
