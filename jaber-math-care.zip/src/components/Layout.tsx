import React from 'react';
import Navbar from './Navbar';
import Footer from './Footer';
import { useOutlet } from 'react-router-dom';
import BackgroundAnimation from './BackgroundAnimation';
import FloatingElements from './FloatingElements';

const Layout = () => {
  const outlet = useOutlet();

  return (
    <div className="flex flex-col min-h-screen relative">
      <BackgroundAnimation />
      <FloatingElements />
      <Navbar />
      <main className="flex-grow pt-24 overflow-x-hidden relative z-30">
        {outlet}
      </main>
      <Footer />
    </div>
  );
};

export default Layout;
