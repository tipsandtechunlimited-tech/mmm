import React from 'react';
import { Helmet } from 'react-helmet-async';
import { useSettings } from '../context/SettingsContext';

const SEO: React.FC = () => {
  const { settings } = useSettings();

  React.useEffect(() => {
    if (settings.custom_seo_tags) {
      // Find and remove old custom tags to avoid duplicates
      const oldTags = document.querySelectorAll('[data-custom-seo]');
      oldTags.forEach(t => t.remove());

      // Create a container to parse the string
      const div = document.createElement('div');
      div.innerHTML = settings.custom_seo_tags;
      
      // Move all elements from container to head
      Array.from(div.children).forEach(child => {
        const newEl = child.cloneNode(true) as HTMLElement;
        newEl.setAttribute('data-custom-seo', 'true');
        
        // Scripts need special handling to execute
        if (newEl.tagName === 'SCRIPT') {
          const script = document.createElement('script');
          Array.from(newEl.attributes).forEach(attr => script.setAttribute(attr.name, attr.value));
          script.textContent = newEl.textContent;
          document.head.appendChild(script);
        } else {
          document.head.appendChild(newEl);
        }
      });
    }
  }, [settings.custom_seo_tags]);

  const title = settings.seo_title || settings.site_name || "Jaber Math Care";
  const description = settings.seo_description || settings.hero_subtitle || "Professional Math & Physics Education Hub";
  const keywords = settings.seo_keywords || "math, physics, education, jaber math care";
  const siteUrl = settings.website_url || window.location.origin;
  const logoUrl = settings.logo_url || "";

  return (
    <Helmet>
      {/* Primary Meta Tags */}
      <title>{title}</title>
      <meta name="title" content={title} />
      <meta name="description" content={description} />
      <meta name="keywords" content={keywords} />

      {/* Open Graph / Facebook */}
      <meta property="og:type" content="website" />
      <meta property="og:url" content={siteUrl} />
      <meta property="og:title" content={title} />
      <meta property="og:description" content={description} />
      {logoUrl && <meta property="og:image" content={logoUrl} />}

      {/* Twitter */}
      <meta property="twitter:card" content="summary_large_image" />
      <meta property="twitter:url" content={siteUrl} />
      <meta property="twitter:title" content={title} />
      <meta property="twitter:description" content={description} />
      {logoUrl && <meta property="twitter:image" content={logoUrl} />}
    </Helmet>
  );
};

export default SEO;
