import React, { useState, useEffect, useRef } from 'react';
import { db } from '../firebase';
import { collection, query, where, getDocs, orderBy } from 'firebase/firestore';
import { motion } from 'motion/react';
import { ShieldCheck, Calendar, ExternalLink, Award, Share2, Sparkles, AlertCircle, ArrowLeft, Heart } from 'lucide-react';
import { Link } from 'react-router-dom';
import LoadingSpinner from '../components/LoadingSpinner';

interface SponsorAd {
  id: string;
  brand_name: string;
  banner_type: 'image' | 'html';
  image_url?: string;
  destination_link?: string;
  html_code?: string;
  status: string;
  order_index?: number;
  duration?: string;
  created_at?: any;
}

// Sandbox iframe container to run Adsterra and other third-party script ad banners safely without breaking React bundle
const HTMLAdRenderer = ({ htmlCode }: { htmlCode: string }) => {
  const iframeRef = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    if (iframeRef.current && htmlCode) {
      const doc = iframeRef.current.contentDocument || iframeRef.current.contentWindow?.document;
      if (doc) {
        doc.open();
        doc.write(`
          <!DOCTYPE html>
          <html>
            <head>
              <meta charset="utf-8">
              <style>
                body {
                  margin: 0;
                  padding: 0;
                  display: flex;
                  justify-content: center;
                  align-items: center;
                  background-color: transparent;
                  overflow: hidden;
                  font-family: system-ui, -apple-system, sans-serif;
                }
              </style>
            </head>
            <body>
              ${htmlCode}
            </body>
          </html>
        `);
        doc.close();
      }
    }
  }, [htmlCode]);

  return (
    <div className="w-full flex justify-center bg-slate-50/50 p-4 rounded-2xl border border-slate-100 min-h-[140px] relative overflow-hidden">
      <iframe
        ref={iframeRef}
        title="Sponsor Banner Ad"
        className="w-full border-0 max-w-full"
        style={{ minHeight: '130px', height: '100px', overflow: 'hidden' }}
        sandbox="allow-scripts allow-popups allow-popups-to-escape-sandbox allow-same-origin"
      />
    </div>
  );
};

const Sponsorship = () => {
  const [sponsors, setSponsors] = useState<SponsorAd[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchSponsors = async () => {
      try {
        const q = query(
          collection(db, 'sponsorships'),
          where('status', '==', 'active')
        );
        const snapshot = await getDocs(q);
        const loadedSponsors: SponsorAd[] = [];
        snapshot.forEach((doc) => {
          loadedSponsors.push({ id: doc.id, ...doc.data() } as SponsorAd);
        });
        
        // Sorting in-memory by order_index to be safe if firestore order isn't fully configured
        loadedSponsors.sort((a, b) => (a.order_index ?? 0) - (b.order_index ?? 0));
        setSponsors(loadedSponsors);
      } catch (err) {
        console.error("Failed to load sponsorship programs:", err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchSponsors();
  }, []);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <LoadingSpinner />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50/30 pb-24">
      {/* Title / Hero Banner */}
      <div className="bg-gradient-to-br from-slate-900 to-slate-800 text-white relative overflow-hidden py-16 md:py-24">
        <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-gradient-to-br from-orange-500/10 to-transparent rounded-full translate-x-1/4 -translate-y-1/4 blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-[300px] h-[300px] bg-gradient-to-tr from-blue-500/10 to-transparent rounded-full -translate-x-1/4 translate-y-1/4 blur-3xl pointer-events-none" />
        
        <div className="max-w-6xl mx-auto px-4 text-center space-y-4 relative z-10">
          <Link to="/" className="inline-flex items-center gap-1.5 text-xs font-black text-orange-400 hover:text-orange-300 uppercase tracking-widest bg-white/5 border border-white/10 px-4 py-2 rounded-full transition-all">
            <ArrowLeft className="h-3.5 w-3.5" /> Back to Home
          </Link>
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="space-y-3"
          >
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-gradient-to-r from-orange-500/20 to-amber-500/20 border border-orange-500/30 rounded-full">
              <Award className="h-4 w-4 text-orange-400" />
              <span className="text-[10px] text-orange-300 font-black uppercase tracking-widest">Official Support Program</span>
            </div>
            <h1 className="text-3xl md:text-5xl lg:text-6xl font-black tracking-tight text-white leading-tight">
              Sponsorship & <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-amber-300">Partnership</span>
            </h1>
            <p className="text-slate-300 text-sm md:text-lg max-w-2xl mx-auto font-medium leading-relaxed">
              We collaborate with premier sponsors, educational platforms, and agencies. Explore official partnership models, banners, and verified advertisement listings.
            </p>
          </motion.div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 mt-12">
        {/* Why Support Card */}
        <div className="bg-white border border-slate-100 rounded-[2.5rem] p-6 md:p-10 shadow-xl relative overflow-hidden mb-12 flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="absolute top-0 right-0 w-32 h-32 bg-orange-500/5 rounded-full blur-2xl" />
          <div className="space-y-4">
            <span className="text-xs font-black text-orange-600 uppercase tracking-widest block bg-orange-50 px-3 py-1 rounded-full border border-orange-100/50 w-fit">
              Partner with JaberMath
            </span>
            <h2 className="text-2xl font-black text-slate-800 tracking-tight">Sponsorship Opportunities Available</h2>
            <p className="text-slate-500 text-sm font-semibold max-w-xl leading-relaxed">
              Display your educational banners, agency products, or services directly inside our application and reach thousands of active mathematical and engineering students daily.
            </p>
          </div>
          <a
            href="mailto:contact.jabermathcare@gmail.com"
            className="w-full md:w-auto px-8 py-4.5 bg-slate-900 hover:bg-black text-white rounded-2xl text-xs font-black uppercase tracking-widest text-center shadow-lg transition-all"
          >
            Apply for Sponsorship
          </a>
        </div>

        {/* Banners & Ad Ledger with Scroll view */}
        <div className="space-y-8">
          <div className="flex justify-between items-end">
            <div>
              <h3 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
                <div className="w-2.5 h-6 rounded-full bg-orange-500" />
                Sponsor Announcements & Banners
              </h3>
              <p className="text-xs text-slate-400 font-semibold mt-1">Scroll down to explore active promotional programs</p>
            </div>
            <div className="hidden sm:flex items-center gap-1.5 text-xs text-slate-400 font-bold bg-white px-3 py-1.5 rounded-full border border-slate-100 shadow-sm">
              <ShieldCheck className="h-4 w-4 text-emerald-500" /> VERIFIED LISTING
            </div>
          </div>

          {sponsors.length === 0 ? (
            <div className="bg-white border border-slate-150 p-16 rounded-[2.5rem] text-center flex flex-col items-center justify-center gap-4.5 max-w-3xl mx-auto shadow-sm">
              <div className="p-4 bg-orange-50 rounded-2xl text-orange-600 animate-bounce">
                <Sparkles className="h-8 w-8" />
              </div>
              <div>
                <h4 className="text-lg font-black text-slate-800">Become Our Pioneer Sponsor</h4>
                <p className="text-slate-400 text-sm font-semibold max-w-md mt-2 leading-relaxed">
                  Excellent sponsorship opportunities await! Standard banner spots, tracking links, and custom HTML scripts are ready to live-stream.
                </p>
              </div>
              <a
                href="mailto:contact.jabermathcare@gmail.com"
                className="px-6 py-3 bg-orange-600 hover:bg-orange-700 text-white rounded-xl text-xs font-black uppercase tracking-widest shadow-lg shadow-orange-500/20 transition-all"
              >
                Get Featured Now
              </a>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {sponsors.map((sponsor, index) => (
                <motion.div
                  key={sponsor.id}
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="bg-white border border-slate-150 rounded-[2.5rem] p-6 shadow-md hover:shadow-xl transition-all duration-300 flex flex-col justify-between group overflow-hidden relative"
                >
                  {/* Card Sparkle element */}
                  <div className="absolute top-0 right-0 w-24 h-24 bg-orange-500/5 rounded-full blur-xl pointer-events-none group-hover:bg-orange-500/10 transition-colors" />

                  <div className="space-y-4">
                    {/* Brand header */}
                    <div className="flex justify-between items-start">
                      <div className="space-y-1">
                        <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
                          <Heart className="h-3 w-3 text-red-500 fill-red-500" /> SPONSOR: {sponsor.duration || 'GOLD'}
                        </span>
                        <h4 className="text-lg font-black text-slate-800 group-hover:text-orange-600 transition-colors">
                          {sponsor.brand_name}
                        </h4>
                      </div>
                      <div className="px-2.5 py-1 text-[9px] font-black uppercase tracking-wider rounded-lg border border-slate-100 text-slate-400 bg-slate-50/50">
                        {sponsor.banner_type === 'html' ? 'Custom Code / Ad' : 'Image Banner'}
                      </div>
                    </div>

                    {/* Rendering the actual Ad Banner based on type */}
                    {sponsor.banner_type === 'image' && sponsor.image_url ? (
                      <div className="relative rounded-2xl overflow-hidden border border-slate-100 bg-slate-50 shadow-inner group">
                        <img
                          src={sponsor.image_url}
                          alt={sponsor.brand_name}
                          className="w-full h-auto max-h-[180px] object-contain mx-auto group-hover:scale-[1.02] transition-transform duration-500"
                          referrerPolicy="no-referrer"
                        />
                        {sponsor.destination_link && (
                          <a
                            href={sponsor.destination_link}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2 text-white font-black uppercase tracking-widest text-xs"
                          >
                            Visit Partner <ExternalLink className="h-4 w-4" />
                          </a>
                        )}
                      </div>
                    ) : (
                      sponsor.banner_type === 'html' && sponsor.html_code && (
                        <HTMLAdRenderer htmlCode={sponsor.html_code} />
                      )
                    )}
                  </div>

                  {/* Visit Link details if any */}
                  {sponsor.banner_type === 'image' && sponsor.destination_link && (
                    <div className="mt-5 pt-4 border-t border-slate-50 flex items-center justify-between text-xs text-slate-400 font-semibold">
                      <span className="group-hover:text-slate-600 transition-colors">Direct sponsorship tracking URL</span>
                      <a
                        href={sponsor.destination_link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 text-orange-600 font-extrabold uppercase tracking-wide group-hover:scale-105 transition-transform"
                      >
                        Visit sponsor <ExternalLink className="h-3.5 w-3.5" />
                      </a>
                    </div>
                  )}

                  {sponsor.banner_type === 'html' && (
                    <div className="mt-5 pt-4 border-t border-slate-50 flex items-center justify-between text-[11px] text-slate-400 font-bold">
                      <span className="flex items-center gap-1 text-slate-400 uppercase tracking-widest">
                        <AlertCircle className="h-3.5 w-3.5 text-orange-500" /> Sandboxed Partner Code
                      </span>
                    </div>
                  )}
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Sponsorship;
