import React from 'react';
import { motion } from 'motion/react';
import { ShieldCheck, FileText, Lock, Info } from 'lucide-react';

const Privacy = () => {
  return (
    <div className="min-h-screen pt-4 md:pt-8 pb-20 px-4 sm:px-6 lg:px-8 bg-slate-50">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <div className="inline-flex p-4 rounded-full bg-orange-100 text-orange-600 mb-6">
            <Lock size={40} />
          </div>
          <h1 className="section-title">Privacy Policy</h1>
          <p className="section-subtitle">
            Your privacy is our top priority. Learn how we handle your data.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white p-8 md:p-12 rounded-3xl shadow-xl border border-slate-200 space-y-8 text-slate-700 leading-relaxed"
        >
          <section className="space-y-4">
            <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
              <ShieldCheck className="text-orange-600" /> 1. Information We Collect
            </h2>
            <p>
              We collect personal information such as your name, email address, and phone number when you register for an account or contact us. We also collect data about your course progress and exam results.
            </p>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
              <Lock className="text-orange-600" /> 2. How We Use Your Data
            </h2>
            <p>
              Your data is used to provide and improve our educational services, personalize your learning experience, communicate important updates, and process payments. We do not sell your data to third parties.
            </p>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
              <Info className="text-orange-600" /> 3. Data Security
            </h2>
            <p>
              We implement industry-standard security measures to protect your personal information from unauthorized access, disclosure, or alteration. Your account is protected by your chosen password.
            </p>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
              <ShieldCheck className="text-orange-600" /> 4. Third-Party Services
            </h2>
            <p>
              We may use third-party services for payment processing and analytics. These services have their own privacy policies and are responsible for the data they collect.
            </p>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
              <Lock className="text-orange-600" /> 5. Your Rights
            </h2>
            <p>
              You have the right to access, update, or delete your personal information at any time. If you have any questions or concerns about your data, please contact us.
            </p>
          </section>

          <div className="pt-8 border-t border-slate-100 text-sm text-slate-500 text-center">
            Last Updated: March 19, 2026
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Privacy;
