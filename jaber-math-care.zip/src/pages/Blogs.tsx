import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence } from 'motion/react';
import { FileText, Calendar, User, Search, X, BookOpen, Clock, ArrowRight } from 'lucide-react';
import { useRealtimeCollection } from '../hooks/useRealtime';

interface BlogItem {
  id: string;
  title: string;
  content: string;
  author: string;
  image_url?: string;
  created_at?: string;
}

const Blogs = () => {
  const { data: blogs, loading } = useRealtimeCollection<BlogItem>('blogs');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedBlog, setSelectedBlog] = useState<BlogItem | null>(null);

  useEffect(() => {
    if (selectedBlog) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [selectedBlog]);

  // Filter blogs based on search term
  const filteredBlogs = blogs.filter(b => 
    b.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (b.author || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
    b.content.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Estimates reading time based on 200 words per minute average
  const getReadingTime = (text: string) => {
    const words = text.split(/\s+/).length;
    const time = Math.max(1, Math.ceil(words / 200));
    return `${time} min read`;
  };

  const formatDate = (isoString?: string) => {
    if (!isoString) return 'Recent Post';
    try {
      const date = new Date(isoString);
      return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      });
    } catch {
      return 'Recent Post';
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 pt-4 md:pt-8 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Page Header */}
        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-10"
        >
          <span className="bg-orange-50 text-orange-600 px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-widest border border-orange-100">
            Articles & Insights
          </span>
          <h1 className="section-title mt-3">Jaber Math Care Blog</h1>
          <p className="section-subtitle mt-2">
            Explore useful math tips, exam preparation strategies, and student success stories.
          </p>

          {/* Search Box */}
          <div className="max-w-md mx-auto mt-6 relative group">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-slate-400 h-5 w-5 group-focus-within:text-orange-500 transition-colors" />
            <input
              type="text"
              placeholder="Search articles, topics or authors..."
              className="pl-12 pr-6 py-3.5 bg-white border border-slate-200 rounded-2xl focus:outline-none focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500 shadow-md w-full transition-all text-slate-800 placeholder-slate-400"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </motion.div>

        {loading ? (
          <div className="flex flex-col items-center justify-center py-20 gap-4">
            <div className="h-10 w-10 border-4 border-orange-600 border-t-transparent rounded-full animate-spin"></div>
            <p className="text-slate-500 font-bold uppercase tracking-widest text-xs">Loading articles...</p>
          </div>
        ) : (
          <>
            {filteredBlogs.length === 0 ? (
              <div className="text-center py-20 bg-white rounded-3xl border border-slate-100 shadow-sm max-w-xl mx-auto">
                <FileText className="h-16 w-16 mx-auto mb-4 text-slate-300" />
                <h3 className="text-lg font-black text-slate-700">No Articles Found</h3>
                <p className="text-slate-400 text-sm mt-1">Try searching with other keywords or check back later.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {filteredBlogs.map((blog, idx) => (
                  <motion.article
                    key={blog.id}
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.05 }}
                    className="bg-white rounded-[2rem] overflow-hidden border border-slate-100 shadow-xl shadow-slate-200/50 flex flex-col h-full group hover:shadow-2xl hover:shadow-orange-500/5 hover:-translate-y-1 transition-all duration-300"
                  >
                    {/* Blog Cover Image */}
                    <div className="h-52 relative overflow-hidden bg-slate-100 flex-shrink-0 cursor-pointer" onClick={() => setSelectedBlog(blog)}>
                      {blog.image_url ? (
                        <img 
                          src={blog.image_url} 
                          alt={blog.title} 
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" 
                          referrerPolicy="no-referrer"
                          onError={(e) => {
                            const target = e.target as HTMLImageElement;
                            target.src = 'https://images.unsplash.com/photo-1518133835878-5a93cc3f89e5?auto=format&fit=crop&q=80&w=800';
                            target.onerror = null;
                          }}
                        />
                      ) : (
                        <div className="w-full h-full bg-orange-500/5 flex items-center justify-center relative">
                          <BookOpen className="h-12 w-12 text-orange-500 opacity-20" />
                        </div>
                      )}
                      <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-md px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest text-orange-600 flex items-center gap-1.5 shadow-sm">
                        <Clock className="h-3 w-3" /> {getReadingTime(blog.content)}
                      </div>
                    </div>

                    {/* Blog Content Info */}
                    <div className="p-6 md:p-8 flex flex-col flex-1">
                      {/* Meta info */}
                      <div className="flex items-center gap-4 text-xs font-bold text-slate-400 uppercase tracking-widest mb-4 flex-wrap">
                        <span className="flex items-center gap-1.5">
                          <User className="h-3.5 w-3.5 text-orange-500/70" /> {blog.author || 'Instructor'}
                        </span>
                        <span className="flex items-center gap-1.5">
                          <Calendar className="h-3.5 w-3.5 text-orange-500/70" /> {formatDate(blog.created_at)}
                        </span>
                      </div>

                      <h3 
                        className="text-xl font-black text-slate-900 tracking-tight leading-snug line-clamp-2 cursor-pointer group-hover:text-orange-600 transition-colors"
                        onClick={() => setSelectedBlog(blog)}
                      >
                        {blog.title}
                      </h3>

                      <p className="text-slate-500 text-sm mt-3 leading-relaxed line-clamp-3">
                        {blog.content}
                      </p>

                      <div className="pt-6 mt-auto border-t border-slate-50 flex justify-start">
                        <button
                          onClick={() => setSelectedBlog(blog)}
                          className="text-orange-600 font-black text-xs uppercase tracking-widest flex items-center gap-2 group/btn hover:text-orange-700 transition-colors"
                        >
                          Read Full Article 
                          <ArrowRight className="h-4 w-4 transform group-hover/btn:translate-x-1 transition-transform" />
                        </button>
                      </div>
                    </div>
                  </motion.article>
                ))}
              </div>
            )}
          </>
        )}
      </div>

      {/* Detail Reading Modal */}
      {createPortal(
        <AnimatePresence>
          {selectedBlog && (
            <div 
              className="fixed inset-0 bg-slate-900/80 backdrop-blur-md flex justify-center items-center z-[9999] p-4 sm:p-6 animate-in fade-in duration-300"
              onClick={() => setSelectedBlog(null)}
            >
              <motion.div
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                className="bg-white/95 backdrop-blur-xl rounded-[2rem] shadow-2xl max-w-4xl w-full max-h-[85vh] sm:max-h-[90vh] p-6 md:p-10 border border-slate-200/50 relative flex flex-col"
                onClick={(e) => e.stopPropagation()}
              >
                <button
                  onClick={() => setSelectedBlog(null)}
                  className="absolute top-4 right-4 p-2 rounded-full bg-slate-100/80 text-slate-600 hover:bg-orange-600 hover:text-white transition-all active:scale-90 z-20 shadow-sm"
                >
                  <X className="h-5 w-5" />
                </button>

                <div className="space-y-6 overflow-y-auto flex-1 pr-2 mt-4 pb-4 custom-scrollbar">
                  {/* Image */}
                  {selectedBlog.image_url && (
                    <div className="h-48 sm:h-80 rounded-[1.5rem] overflow-hidden bg-slate-100">
                      <img 
                        src={selectedBlog.image_url} 
                        alt={selectedBlog.title} 
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.src = 'https://images.unsplash.com/photo-1518133835878-5a93cc3f89e5?auto=format&fit=crop&q=80&w=800';
                          target.onerror = null;
                        }}
                      />
                    </div>
                  )}

                  {/* Meta details */}
                  <div className="space-y-3">
                    <div className="flex flex-wrap gap-4 text-xs font-black text-slate-400 uppercase tracking-widest">
                      <span className="flex items-center gap-1.5">
                        <User className="h-3.5 w-3.5 text-orange-600" /> {selectedBlog.author || 'Instructor'}
                      </span>
                      <span className="flex items-center gap-1.5">
                        <Calendar className="h-3.5 w-3.5 text-orange-600" /> {formatDate(selectedBlog.created_at)}
                      </span>
                      <span className="flex items-center gap-1.5">
                        <Clock className="h-3.5 w-3.5 text-orange-600" /> {getReadingTime(selectedBlog.content)}
                      </span>
                    </div>

                    <h2 className="text-2xl sm:text-3.5xl font-black text-slate-900 leading-tight">
                      {selectedBlog.title}
                    </h2>
                  </div>

                  <hr className="border-slate-100" />

                  {/* Content body */}
                  <div className="text-slate-700 leading-relaxed text-base whitespace-pre-line font-medium space-y-4">
                    {selectedBlog.content}
                  </div>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>,
        document.body
      )}
    </div>
  );
};

export default Blogs;
