import { db } from '../firebase';
import { collection, onSnapshot } from 'firebase/firestore';
import LoadingSpinner from '../components/LoadingSpinner';
import { showAlert, showConfirm } from '../utils/alert';
import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, User, Users, Filter, Award, Trophy, Star, RefreshCw, FileText } from 'lucide-react';

const Results = () => {
  const [exams, setExams] = useState<any[]>([]);
  const [results, setResults] = useState<any[]>([]);
  const [programs, setPrograms] = useState<any[]>([]);
  const [batches, setBatches] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'your' | 'full'>('your');
  
  // Filters
  const [selectedProgram, setSelectedProgram] = useState('');
  const [selectedClass, setSelectedClass] = useState('');
  const [selectedBatch, setSelectedBatch] = useState('');
  const [selectedExam, setSelectedExam] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedExamType, setSelectedExamType] = useState('');
  const [rollNumber, setRollNumber] = useState('');

  const [users, setUsers] = useState<any[]>([]);

  useEffect(() => {
    setLoading(true);
    const unsubscribes: (() => void)[] = [];

    const unsubUsers = onSnapshot(collection(db, 'users'), (s) => {
      setUsers(s.docs.map(d => ({ id: d.id, ...d.data() })));
    });
    unsubscribes.push(unsubUsers);

    const unsubExams = onSnapshot(collection(db, 'exams'), (s) => {

      setExams(s.docs.map(d => ({ id: d.id, ...d.data() })));
    });
    unsubscribes.push(unsubExams);

    const unsubResults = onSnapshot(collection(db, 'results'), (s) => {
      setResults(s.docs.map(d => ({ id: d.id, ...d.data() })));
    });
    unsubscribes.push(unsubResults);

    const unsubPrograms = onSnapshot(collection(db, 'programs'), (s) => {
      setPrograms(s.docs.map(d => ({ id: d.id, ...d.data() })));
    });
    unsubscribes.push(unsubPrograms);

    const unsubBatches = onSnapshot(collection(db, 'batches'), (s) => {
      setBatches(s.docs.map(d => ({ id: d.id, ...d.data() })));
      setLoading(false);
    });
    unsubscribes.push(unsubBatches);

    return () => unsubscribes.forEach(unsub => unsub());
  }, []);

  const fetchData = async () => {
    // fetchData is now real-time, kept for UI compatibility
  };

  const mappedResults = useMemo(() => {
    return results.map(r => {
      let roll_number = r.roll_number;
      let student_name = r.student_name;
      let exam_category = r.exam_category;
      let batch_id = r.batch_id;
      let program_id = r.program_id;
      let student_class = r.student_class || r.class;
      
      const user = r.student_id 
        ? users.find(u => u.id === r.student_id)
        : (roll_number ? users.find(u => String(u.roll_number).trim() === String(roll_number).trim()) : null);
        
      if (user) {
        roll_number = roll_number || user.roll_number;
        student_name = student_name || user.name;
        batch_id = batch_id || user.batch_id || user.batch_id_2;
        program_id = program_id || user.program_id || (batches.find(b => String(b.id) === String(user.batch_id) || String(b.id) === String(user.batch_id_2))?.program_id);
        student_class = student_class || user.current_class || user.class;
      }
      
      if (!exam_category && r.exam_id) {
        const exam = exams.find(e => e.id === r.exam_id);
        if (exam) {
          exam_category = exam.category;
        }
      } else if (!exam_category && r.exam_name) {
        const exam = exams.find(e => e.exam_name === r.exam_name);
        if (exam) {
          exam_category = exam.category;
        }
      }
      
      return { ...r, roll_number, student_name, exam_category, batch_id, program_id, student_class };
    });
  }, [results, users, exams, batches]);

  // Find exams that actually have results matching the selected criteria (program/class/batch)
  // or just show exams. We will just use all exams that match the program, not restrict down too strictly.
  let filteredExams = exams.filter(e => e.published);
  if (selectedProgram) {
    filteredExams = filteredExams.filter(e => !e.program_id || e.program_id === 'all' || e.program_id === selectedProgram);
  }
  if (selectedBatch) {
    // If exam has no batch_id, it is open to all batches in that program.
    filteredExams = filteredExams.filter(e => !e.batch_id || e.batch_id === 'all' || e.batch_id === selectedBatch || String(e.batch_id).includes(selectedBatch));
  }

  const uniqueCategories = Array.from(new Set(filteredExams.map(e => e.category).filter(Boolean)));
  const uniqueTypes = Array.from(new Set(filteredExams.map(e => e.exam_type).filter(Boolean)));
  
  if (selectedCategory) {
    filteredExams = filteredExams.filter(e => e.category === selectedCategory);
  }

  if (selectedExamType) {
    filteredExams = filteredExams.filter(e => e.exam_type === selectedExamType);
  }

  let uniqueExams = Array.from(new Set(filteredExams.map(e => e.exam_name).filter(Boolean))).map(name => {
    return filteredExams.find(e => e.exam_name === name);
  }).filter(Boolean);

  const filteredResults = useMemo(() => {
    if (activeTab === 'your') return [];
    
    // Only show results if activeExam is resolved
    const activeExam = selectedExam || uniqueExams[0]?.exam_name || '';
    if (!activeExam) return [];
    
    let filtered = mappedResults;

    if (selectedProgram) {
      filtered = filtered.filter(r => r.program_id?.toString() === selectedProgram || String(r.program_id).includes(selectedProgram));
    }
    if (selectedClass) {
      filtered = filtered.filter(r => r.student_class?.toString() === selectedClass || String(r.student_class).includes(selectedClass));
    }
    if (selectedBatch) {
      filtered = filtered.filter(r => r.batch_id === 'all' || r.batch_id?.toString() === selectedBatch || String(r.batch_id).includes(selectedBatch));
    }
    if (activeExam) {
      filtered = filtered.filter(r => r.exam_name === activeExam || r.exam_id?.toString() === activeExam);
    }
    if (selectedCategory) {
      filtered = filtered.filter(r => r.exam_category === selectedCategory);
    }
    if (selectedExamType) {
      filtered = filtered.filter(r => r.exam_type === selectedExamType);
    }
    
    // Add roll number search for full results too
    if (rollNumber && activeTab === 'full') {
      filtered = filtered.filter(r => r.roll_number?.toString().includes(rollNumber));
    }
    
    return filtered.sort((a, b) => (Number(b.marks) || 0) - (Number(a.marks) || 0));
  }, [mappedResults, selectedProgram, selectedClass, selectedBatch, selectedExam, uniqueExams, selectedCategory, selectedExamType, rollNumber, activeTab]);

  const searchResultsData = useMemo(() => {
    if (activeTab !== 'your' || !rollNumber) return [];
    
    let filtered = mappedResults;
    const activeExam = selectedExam || uniqueExams[0]?.exam_name || '';

    if (selectedProgram) {
      filtered = filtered.filter(r => r.program_id?.toString() === selectedProgram || String(r.program_id).includes(selectedProgram));
    }
    if (selectedClass) {
      filtered = filtered.filter(r => r.student_class?.toString() === selectedClass || String(r.student_class).includes(selectedClass));
    }
    if (selectedBatch) {
      filtered = filtered.filter(r => r.batch_id === 'all' || r.batch_id?.toString() === selectedBatch || String(r.batch_id).includes(selectedBatch));
    }
    if (activeExam) {
      filtered = filtered.filter(r => r.exam_name === activeExam || r.exam_id?.toString() === activeExam);
    }
    if (selectedCategory) {
      filtered = filtered.filter(r => r.exam_category === selectedCategory);
    }
    if (selectedExamType) {
      filtered = filtered.filter(r => r.exam_type === selectedExamType);
    }
    
    const searchRoll = rollNumber.trim();
    const foundResults = filtered.filter(r => r.roll_number?.toString().trim() === searchRoll);
    
    return foundResults.map(found => {
      let calcFound = { ...found };
      if (!calcFound.merit_position) {
        const sameExamResults = mappedResults.filter(r => r.exam_name === calcFound.exam_name || r.exam_id === calcFound.exam_id);
        sameExamResults.sort((a, b) => (Number(b.marks) || 0) - (Number(a.marks) || 0));
        const meritIndex = sameExamResults.findIndex(r => r.id === calcFound.id);
        calcFound.calculated_merit = meritIndex !== -1 ? meritIndex + 1 : 'N/A';
      }
      return calcFound;
    });
  }, [mappedResults, selectedProgram, selectedClass, selectedBatch, selectedExam, uniqueExams, selectedCategory, selectedExamType, rollNumber, activeTab]);

  const handleApplyFilters = () => {
    const activeExam = selectedExam || uniqueExams[0]?.exam_name || '';
    if (!activeExam) {
      showAlert('No exams found matching your selection criteria.');
      return;
    }
    setActiveTab('full');
  };

  const handleSearchRoll = () => {
    if (!rollNumber) return;
    const activeExam = selectedExam || uniqueExams[0]?.exam_name || '';
    if (!activeExam) {
      showAlert('No exams found matching your selection criteria.');
      return;
    }
    setActiveTab('your');
  };

  // Get unique values for dropdowns
  const classesFilteredBatches = selectedProgram ? batches.filter(b => b.program_id?.toString() === selectedProgram || String(b.program_id).includes(selectedProgram)) : batches;
  const uniqueClasses = Array.from(new Set(classesFilteredBatches.map(b => b.class || b.class_name || b.batch_class).filter(Boolean)));
  
  let uniqueBatches = batches;
  if (selectedProgram) {
    uniqueBatches = uniqueBatches.filter(b => 
      b.program_id?.toString() === selectedProgram || 
      String(b.program_id).includes(selectedProgram)
    );
  }
  if (selectedClass) {
    uniqueBatches = uniqueBatches.filter(b => (b.class || b.class_name || b.batch_class) === selectedClass);
  }

  return (
    <div className="min-h-screen pt-4 md:pt-8 pb-20 px-4 sm:px-6 lg:px-8 bg-[#F4F6F9]">
      <div className="max-w-6xl mx-auto space-y-8">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12 relative"
        >
          <h1 className="section-title">Exam Results</h1>
          <p className="section-subtitle">
            Check your performance and merit position.
          </p>
          <div className="absolute top-0 right-0">
            <motion.button
              whileHover={{ rotate: 180 }}
              whileTap={{ scale: 0.9 }}
              onClick={fetchData}
              className="p-3 bg-white rounded-2xl border border-slate-100 shadow-sm text-slate-400 hover:text-orange-500 transition-colors"
              title="Refresh Results"
            >
              <RefreshCw className={`h-5 w-5 ${loading ? 'animate-spin' : ''}`} />
            </motion.button>
          </div>
        </motion.div>
        
        {/* Filters Card */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ type: "spring", damping: 25 }}
          className="glass-card p-4 sm:p-8 relative overflow-hidden group"
        >
          {/* Newton's Apple Decoration */}
          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
            <motion.div
              animate={{ y: [0, 100, 0], rotate: [0, 15, 0] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            >
              <div className="w-12 h-12 bg-red-500 rounded-full relative">
                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-full w-1 h-3 bg-green-800 rounded-full" />
              </div>
            </motion.div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6 relative z-10">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="relative group"
            >
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Program</label>
              <div className="relative">
                <select 
                  className="w-full bg-white/50 border-2 border-slate-100 rounded-2xl px-5 py-4 text-slate-900 font-bold appearance-none focus:border-orange-500 focus:ring-4 focus:ring-orange-500/10 transition-all outline-none"
                  value={selectedProgram}
                  onChange={(e) => setSelectedProgram(e.target.value)}
                >
                  <option value="">All Programs</option>
                  {programs.map(p => (
                    <option key={p.id} value={p.id}>{p.title || p.name || p.program_name || 'Unknown Program'}</option>
                  ))}
                </select>
                <div className="absolute right-5 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
                  <Filter className="h-4 w-4" />
                </div>
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="relative group"
            >
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Class</label>
              <div className="relative">
                <select 
                  className="w-full bg-white/50 border-2 border-slate-100 rounded-2xl px-5 py-4 text-slate-900 font-bold appearance-none focus:border-orange-500 focus:ring-4 focus:ring-orange-500/10 transition-all outline-none"
                  value={selectedClass}
                  onChange={(e) => setSelectedClass(e.target.value)}
                >
                  <option value="">All Classes</option>
                  {uniqueClasses.map(c => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
                <div className="absolute right-5 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
                  <Users className="h-4 w-4" />
                </div>
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="relative group"
            >
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Batch</label>
              <div className="relative">
                <select 
                  className="w-full bg-white/50 border-2 border-slate-100 rounded-2xl px-5 py-4 text-slate-900 font-bold appearance-none focus:border-orange-500 focus:ring-4 focus:ring-orange-500/10 transition-all outline-none"
                  value={selectedBatch}
                  onChange={(e) => setSelectedBatch(e.target.value)}
                >
                  <option value="">Select Batch</option>
                  {uniqueBatches.map(b => (
                    <option key={b.id} value={b.id}>{b.name || b.batch_name || 'Unknown Batch'}</option>
                  ))}
                </select>
                <div className="absolute right-5 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
                  <Trophy className="h-4 w-4" />
                </div>
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="relative group"
            >
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Category</label>
              <div className="relative">
                <select 
                  className="w-full bg-white/50 border-2 border-slate-100 rounded-2xl px-5 py-4 text-slate-900 font-bold appearance-none focus:border-orange-500 focus:ring-4 focus:ring-orange-500/10 transition-all outline-none"
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                >
                  <option value="">All Categories</option>
                  {uniqueCategories.map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
                <div className="absolute right-5 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
                  <Star className="h-4 w-4" />
                </div>
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="relative group"
            >
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Exam Type</label>
              <div className="relative">
                <select 
                  className="w-full bg-white/50 border-2 border-slate-100 rounded-2xl px-5 py-4 text-slate-900 font-bold appearance-none focus:border-orange-500 focus:ring-4 focus:ring-orange-500/10 transition-all outline-none"
                  value={selectedExamType}
                  onChange={(e) => setSelectedExamType(e.target.value)}
                >
                  <option value="">All Types</option>
                  {uniqueTypes.map(type => (
                    <option key={type} value={type}>{type}</option>
                  ))}
                </select>
                <div className="absolute right-5 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
                  <FileText className="h-4 w-4" />
                </div>
              </div>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.6 }}
              className="flex items-end"
            >
              <motion.button 
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={handleApplyFilters}
                className="glass-btn w-full"
              >
                <Filter className="h-4 w-4" /> APPLY FILTERS
              </motion.button>
            </motion.div>
          </div>
        </motion.div>

        {/* Results Card */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="glass-card p-8 md:p-12 relative overflow-hidden"
        >
          {/* Background Glows */}
          <div className="absolute top-0 right-0 w-96 h-96 bg-orange-500/5 rounded-full blur-[100px] -mr-48 -mt-48"></div>
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-red-500/5 rounded-full blur-[100px] -ml-48 -mb-48"></div>

          {/* Tabs */}
          <div className="flex bg-slate-100/50 backdrop-blur-md rounded-2xl p-1.5 mb-10 relative z-10 border border-white/40">
            <motion.button 
              whileHover={{ scale: 1.01 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setActiveTab('your')}
              className={`flex-1 py-4 rounded-xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-3 transition-all ${activeTab === 'your' ? 'bg-orange-600 text-white shadow-xl shadow-orange-900/20' : 'text-slate-500 hover:text-slate-700 hover:bg-white/50'}`}
            >
              <User className="h-5 w-5" /> YOUR RESULT
            </motion.button>
            <motion.button 
              whileHover={{ scale: 1.01 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setActiveTab('full')}
              className={`flex-1 py-4 rounded-xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-3 transition-all ${activeTab === 'full' ? 'bg-orange-600 text-white shadow-xl shadow-orange-900/20' : 'text-slate-500 hover:text-slate-700 hover:bg-white/50'}`}
            >
              <Users className="h-5 w-5" /> FULL RESULT
            </motion.button>
          </div>

          {/* Search Bar */}
          <div className="max-w-md mx-auto mb-12 relative z-10">
            <div className="flex gap-4">
              <div className="relative flex-1 group">
                <Search className="absolute left-5 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400 group-focus-within:text-orange-500 transition-colors" />
                <input 
                  type="number" 
                  placeholder={activeTab === 'your' ? "Enter Roll Number" : "Search in Merit List..."}
                  className="glass-input pl-14 py-4 text-lg font-bold"
                  value={rollNumber}
                  onChange={(e) => setRollNumber(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && (activeTab === 'your' ? handleSearchRoll() : {})}
                />
              </div>
              {activeTab === 'your' && (
                <motion.button 
                  whileHover={{ scale: 1.05, x: 5 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={handleSearchRoll}
                  className="glass-btn px-8 py-4 flex items-center gap-2"
                >
                  <Search className="h-5 w-5" /> SEARCH
                </motion.button>
              )}
            </div>
          </div>

          {/* Tab Content */}
          {loading ? (
            <div className="space-y-6 relative z-10">
              {[1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="h-20 bg-white/40 backdrop-blur-sm rounded-2xl border border-white/60 animate-pulse flex items-center px-6 gap-4">
                  <div className="w-12 h-12 bg-slate-200 rounded-full"></div>
                  <div className="flex-1 space-y-2">
                    <div className="h-4 bg-slate-200 rounded-full w-1/3"></div>
                    <div className="h-3 bg-slate-200 rounded-full w-1/4"></div>
                  </div>
                  <div className="w-24 h-8 bg-slate-200 rounded-full"></div>
                </div>
              ))}
            </div>
          ) : activeTab === 'your' ? (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="max-w-md mx-auto relative z-10"
            >
              <AnimatePresence mode="wait">
                {searchResultsData && searchResultsData.length > 0 ? (
                  <div className="space-y-8">
                    {searchResultsData.map((result, idx) => (
                      <motion.div 
                        key={result.id || idx}
                        initial={{ opacity: 0, y: 30, scale: 0.9 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.9 }}
                        className="glass p-8 md:p-12 text-center relative overflow-hidden rounded-[40px] border border-white/60 shadow-2xl"
                      >
                        <motion.div
                          initial={{ scale: 0, rotate: -20 }}
                          animate={{ scale: 1, rotate: 0 }}
                          transition={{ type: "spring", stiffness: 200, delay: 0.1 * idx }}
                          className="w-20 h-20 md:w-28 md:h-28 bg-gradient-to-br from-orange-500 to-red-600 rounded-3xl flex items-center justify-center mx-auto mb-6 md:mb-8 border-4 border-white shadow-2xl rotate-3"
                        >
                          <Trophy className="h-10 w-10 md:h-12 md:w-12 text-white" />
                        </motion.div>

                        <h3 className="text-2xl md:text-4xl font-black text-orange-600 mb-2 uppercase tracking-tight leading-none">{result.student_name}</h3>
                        <div className="flex flex-col items-center gap-1 mb-6">
                          <div className="text-sm font-bold text-slate-700 uppercase tracking-widest">{result.exam_name}</div>
                          {result.exam_category && (
                            <div className="text-[10px] font-black text-orange-600 bg-orange-100 px-3 py-1 rounded-full uppercase tracking-widest">
                              {result.exam_category}
                            </div>
                          )}
                        </div>
                        
                        <div className="flex flex-col items-center gap-2 mb-8 md:mb-10">
                          <div className="inline-flex items-center gap-2 px-5 py-2 bg-slate-100/80 backdrop-blur-sm rounded-full text-slate-500 font-black text-[10px] uppercase tracking-widest border border-slate-200">
                            <Award className="h-3 w-3 text-orange-500" /> ROLL: {result.roll_number}
                          </div>
                          <div className="inline-flex flex-wrap justify-center items-center gap-2">
                            <div className="px-4 py-1.5 bg-orange-100/50 rounded-full text-orange-600 font-black text-[9px] uppercase tracking-widest border border-orange-200">
                              BATCH: {batches.find(b => b.id?.toString() === result.batch_id?.toString())?.name || 'N/A'}
                            </div>
                            {result.exam_category && (
                              <div className="px-4 py-1.5 bg-blue-100/50 rounded-full text-blue-600 font-black text-[9px] uppercase tracking-widest border border-blue-200">
                                CATEGORY: {result.exam_category}
                              </div>
                            )}
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-3 gap-3 md:gap-6">
                          <motion.div 
                            whileHover={{ y: -5, scale: 1.05 }}
                            className="glass p-4 md:p-6 rounded-2xl md:rounded-3xl border border-white/60 shadow-lg bg-white/40 flex flex-col items-center justify-center"
                          >
                            <div className="text-[8px] md:text-[9px] text-slate-400 font-black uppercase tracking-widest mb-1 md:mb-2 text-center text-balance">Obtained</div>
                            <div className="text-xl md:text-2xl font-black text-orange-600 leading-none">{Number(result.marks ?? 0).toFixed(2)}</div>
                          </motion.div>
                          <motion.div 
                            whileHover={{ y: -5, scale: 1.05 }}
                            className="glass p-4 md:p-6 rounded-2xl md:rounded-3xl border border-white/60 shadow-lg bg-white/40 flex flex-col items-center justify-center"
                          >
                            <div className="text-[8px] md:text-[9px] text-slate-400 font-black uppercase tracking-widest mb-1 md:mb-2 text-center text-balance">Highest</div>
                            <div className="text-xl md:text-2xl font-black text-emerald-600 leading-none">{Number(result.highest_marks ?? result.total_marks ?? 0).toFixed(2)}</div>
                          </motion.div>
                          <motion.div 
                            whileHover={{ y: -5, scale: 1.05 }}
                            className="glass p-4 md:p-6 rounded-2xl md:rounded-3xl border border-white/60 shadow-lg bg-white/40 flex flex-col items-center justify-center"
                          >
                            <div className="text-[8px] md:text-[9px] text-slate-400 font-black uppercase tracking-widest mb-1 md:mb-2 text-center text-balance">Merit</div>
                            <div className="text-xl md:text-2xl font-black text-orange-600 leading-none">#{result.merit_position || result.calculated_merit}</div>
                          </motion.div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                ) : rollNumber && !loading && (
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-center p-12 glass rounded-[40px] border border-white/60"
                  >
                    <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-6">
                      <Search className="h-10 w-10 text-slate-300" />
                    </div>
                    <h3 className="text-xl font-black text-slate-800 mb-2">Result Not Found</h3>
                    <p className="text-slate-500 text-sm font-medium">Please double check the roll number and filters.</p>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ) : (
            <div className="relative z-10">
              {/* Full Result Table (Batch Wise) */}
              <div className="w-full relative z-10 glass rounded-[20px] shadow-lg overflow-hidden border border-white/60">
                {filteredResults.length > 0 ? (
                  <div className="overflow-x-auto w-full">
                    <table className="w-full text-left border-collapse min-w-[800px]">
                      <thead>
                        <tr className="bg-[#2a3a78] text-white">
                          <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider">Roll</th>
                          <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider">Name</th>
                          <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-center">Batch</th>
                          <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-center">MCQ Marks</th>
                          <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-center">Negative Marks</th>
                          <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-center">Obtained Marks</th>
                          <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-center">Highest Marks</th>
                          <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-center">Merit Position</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 bg-white/70">
                        {filteredResults
                          .sort((a, b) => b.marks - a.marks)
                          .map((result, idx) => (
                            <tr key={result.id} className="hover:bg-slate-50 transition-colors">
                              <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold text-slate-800">{result.roll_number}</td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-700">{result.student_name}</td>
                              <td className="px-6 py-4 whitespace-nowrap text-xs font-medium text-slate-500 text-center">{batches.find(b => b.id?.toString() === result.batch_id?.toString())?.name || 'N/A'}</td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-700 text-center">{result.mcq_marks != null ? Number(result.mcq_marks).toFixed(2) : '-'}</td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-700 text-center">{result.negative_marks != null ? Number(result.negative_marks).toFixed(2) : '-'}</td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-indigo-700 text-center">{Number(result.marks ?? 0).toFixed(2)}</td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-emerald-600 text-center">{Number(result.highest_marks ?? result.total_marks ?? 0).toFixed(2)}</td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-orange-600 text-center">{result.merit_position || idx + 1}</td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <div className="col-span-full p-16 text-center glass rounded-[40px] border border-white/60">
                    <div className="p-6 bg-slate-100 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-6">
                      <Filter className="h-10 w-10 text-slate-300" />
                    </div>
                    <h3 className="text-xl font-black text-slate-800">No Results</h3>
                    <p className="text-slate-500 text-sm font-medium mt-2">Apply filters to view results.</p>
                  </div>
                )}
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
};

export default Results;
