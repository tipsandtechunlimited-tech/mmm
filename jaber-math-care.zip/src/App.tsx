import React, { Suspense, lazy } from 'react';
import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { SettingsProvider } from './context/SettingsContext';
import { ToastProvider } from './context/ToastContext';
import { HelmetProvider } from 'react-helmet-async';
import SEO from './components/SEO';
import Layout from './components/Layout';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import DashboardLayout from './components/DashboardLayout';
import ScrollToTop from './components/ScrollToTop';
import ProtectedRoute from './components/ProtectedRoute';
import LoadingSpinner from './components/LoadingSpinner';
import AnimatedRoutes from './components/AnimatedRoutes';
import NotificationManager from './components/NotificationManager';

const Home = lazy(() => import('./pages/Home'));
const Login = lazy(() => import('./pages/Login'));
const Dashboard = lazy(() => import('./pages/Dashboard'));
const AdminDashboard = lazy(() => import('./pages/AdminDashboard'));
const Courses = lazy(() => import('./pages/Courses'));
const About = lazy(() => import('./pages/About'));
const Resources = lazy(() => import('./pages/Resources'));
const Contact = lazy(() => import('./pages/Contact'));
const Gallery = lazy(() => import('./pages/Gallery'));
const Schedule = lazy(() => import('./pages/Schedule'));
const OnlineCourses = lazy(() => import('./pages/OnlineCourses'));
const Results = lazy(() => import('./pages/Results'));
const PublicNotices = lazy(() => import('./pages/Notices'));
const PublicVideoLibrary = lazy(() => import('./pages/PublicVideoLibrary'));
const RecordedClasses = lazy(() => import('./pages/RecordedClasses'));
const Programs = lazy(() => import('./pages/Programs'));
const Slide = lazy(() => import('./pages/Slide'));
const Terms = lazy(() => import('./pages/Terms'));
const Privacy = lazy(() => import('./pages/Privacy'));
const Developer = lazy(() => import('./pages/Developer'));
const Reviews = lazy(() => import('./pages/Reviews'));
const Blogs = lazy(() => import('./pages/Blogs'));
const Sponsorship = lazy(() => import('./pages/Sponsorship'));
const NotFound = lazy(() => import('./pages/NotFound'));

// Dashboard Pages
import Profile from './pages/dashboard/Profile';
import Notices from './pages/dashboard/Notices';
import StudentResources from './pages/dashboard/Resources';
import AllResources from './pages/dashboard/AllResources';
import Routines from './pages/dashboard/Routine';
import ZoomClasses from './pages/dashboard/ZoomClasses';
import LiveClassViewer from './pages/dashboard/LiveClassViewer';
import Chapters from './pages/dashboard/Chapters';
import Attendance from './pages/dashboard/Attendance';
import ResultsDashboard from './pages/dashboard/Results';
import Exams from './pages/dashboard/Exams';
import Fees from './pages/dashboard/Fees';
import IDCard from './pages/dashboard/IDCard';
import LiveClasses from './pages/dashboard/LiveClasses';
import MyEnrollments from './pages/dashboard/MyEnrollments';
import VideoLibrary from './pages/dashboard/VideoLibrary';
import ClassSlides from './pages/dashboard/ClassSlides';

const appRoutes = (
  <>
    <Route path="/" element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="login" element={<Login />} />
        <Route path="courses" element={<Courses />} />
        <Route path="online-courses" element={<OnlineCourses />} />
        <Route path="schedule" element={<Schedule />} />
        <Route path="gallery" element={<Gallery />} />
        <Route path="notices" element={<PublicNotices />} />
        <Route path="results" element={<Results />} />
        <Route path="video-library" element={<PublicVideoLibrary />} />
        <Route path="recorded-classes" element={<RecordedClasses />} />
        <Route path="about" element={<About />} />
        <Route path="resources" element={<Resources />} />
        <Route path="contact" element={<Contact />} />
        <Route path="terms" element={<Terms />} />
        <Route path="privacy" element={<Privacy />} />
        <Route path="developer" element={<Developer />} />
        <Route path="reviews" element={<Reviews />} />
        <Route path="blogs" element={<Blogs />} />
        <Route path="sponsorship" element={<Sponsorship />} />
        <Route path="slide" element={<Slide />} />
        <Route path="programs" element={<Programs />} />
      </Route>

      <Route path="/admin" element={
        <ProtectedRoute role={['admin', 'moderator']}>
          <AdminDashboard />
        </ProtectedRoute>
      } />

      <Route path="/dashboard" element={
        <ProtectedRoute role={['student', 'admin', 'moderator']}>
          <DashboardLayout />
        </ProtectedRoute>
      }>
        <Route index element={<Dashboard />} />
        <Route path="profile" element={<Profile />} />
        <Route path="notices" element={<Notices />} />
        <Route path="classes" element={<StudentResources type="video" />} />
        <Route path="materials" element={<StudentResources type="pdf" />} />
        <Route path="all-resources" element={<AllResources />} />
        <Route path="zoom" element={<ZoomClasses />} />
        <Route path="zoom/:id" element={<LiveClassViewer />} />
        <Route path="live-classes" element={<LiveClasses />} />
        <Route path="routines" element={<Routines />} />
        <Route path="programs" element={<Programs />} />
        <Route path="chapters" element={<Chapters />} />
        <Route path="attendance" element={<Attendance />} />
        <Route path="results" element={<ResultsDashboard />} />
        <Route path="exams" element={<Exams />} />
        <Route path="view-results" element={<ResultsDashboard />} />
        <Route path="fees" element={<Fees />} />
        <Route path="enrollments" element={<MyEnrollments />} />
        <Route path="video-library" element={<VideoLibrary />} />
        <Route path="id-card" element={<IDCard />} />
        <Route path="class-slides" element={<ClassSlides />} />
        
        <Route path="*" element={<Dashboard />} />
      </Route>

      <Route path="*" element={<NotFound />} />
  </>
);

import PageTransition from './components/PageTransition';

function App() {
  return (
    <HelmetProvider>
      <AuthProvider>
        <SettingsProvider>
          <ToastProvider>
            <SEO />
            <NotificationManager />
            <Router>
              <ScrollToTop />
              <Suspense fallback={null}>
                <PageTransition>
                  <AnimatedRoutes>
                    {appRoutes}
                  </AnimatedRoutes>
                </PageTransition>
              </Suspense>
            </Router>
          </ToastProvider>
        </SettingsProvider>
      </AuthProvider>
    </HelmetProvider>
  );
}

export default App;
