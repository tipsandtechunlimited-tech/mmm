import { initializeApp, cert } from 'firebase-admin/app';
import { getFirestore } from 'firebase-admin/firestore';
import fs from 'fs';

const firebaseConfig = JSON.parse(fs.readFileSync('./firebase-applet-config.json', 'utf8'));
const serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT || '{}');

if (Object.keys(serviceAccount).length > 0) {
  initializeApp({
    credential: cert(serviceAccount)
  });
} else {
  initializeApp({
    projectId: firebaseConfig.projectId
  });
}

const db = getFirestore();

async function migrate() {
  const resultsSnap = await db.collection('results').get();
  for (const doc of resultsSnap.docs) {
    const data = doc.data();
    if (!data.roll_number || !data.student_name && data.student_id) {
       const studentDoc = await db.collection('users').doc(data.student_id).get();
       if (studentDoc.exists) {
          const studentData = studentDoc.data();
          await doc.ref.update({
            roll_number: studentData.roll_number || '',
            student_name: studentData.name || ''
          });
          console.log(`Updated result ${doc.id} for student ${data.student_id}`);
       }
    }
  }
  console.log("Migration complete");
}

migrate().catch(console.error);
