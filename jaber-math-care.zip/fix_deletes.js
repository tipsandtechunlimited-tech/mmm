const fs = require('fs');

let code = fs.readFileSync('src/pages/AdminDashboard.tsx', 'utf8');

const entities = [
  { func: 'handleDeleteRoutine', coll: 'routines', label: 'routine' },
  { func: 'handleDeleteExamCategory', coll: 'exam_categories', label: 'category' },
  { func: 'handleDeleteProgram', coll: 'programs', label: 'program' },
  { func: 'handleDeleteCourse', coll: 'courses', label: 'course' },
  { func: 'handleDeleteImage', coll: 'gallery', label: 'image' },
  { func: 'handleDeleteNotice', coll: 'notices', label: 'notice' },
  { func: 'handleDeleteResource', coll: 'study_materials', label: 'resource' },
  { func: 'handleDeletePayment', coll: 'payments', label: 'payment record' },
  { func: 'handleDeleteChapter', coll: 'chapters', label: 'chapter' },
  { func: 'handleDeleteExam', coll: 'exams', label: 'exam' },
  { func: 'handleDeleteResult', coll: 'results', label: 'result' },
  { func: 'handleDeleteEnrollment', coll: 'enrollments', label: 'enrollment' }
];

for (const e of entities) {
  const funcRegex = new RegExp(`const ${e.func} = async \\(id: string\\) => \\{([\\s\\S]*?)\\};\\n`, 'g');
  
  code = code.replace(funcRegex, (match, body) => {
    // If it's a student or moderator, don't change it here, wait, I didn't include them in the array!
    
    // We rebuild the function
    return `const ${e.func} = async (id: string) => {
    if (user?.role === "moderator") {
      showAlert("Moderators cannot delete ${e.label}s", "error");
      return;
    }
    if (await showConfirm("Are you sure?")) {
      try {
        await deleteDoc(doc(db, "${e.coll}", id));
        showAlert("${e.label.charAt(0).toUpperCase() + e.label.slice(1)} deleted successfully", "success");
      } catch (error: any) {
        console.error(error);
        showAlert("Failed to delete ${e.label}", "error");
      }
    }
  };
`;
  });
}

// Special case for handleDeleteStudent, which needs server-side deletion from Firebase Auth
const handleS = new RegExp(`const handleDeleteStudent = async \\(id: string\\) => \\{([\\s\\S]*?)\\};\\n`, '');
code = code.replace(handleS, (match) => {
  return `const handleDeleteStudent = async (id: string) => {
    if (user?.role === "moderator") {
      showAlert("Moderators cannot delete students", "error");
      return;
    }
    if (await showConfirm("Are you sure you want to delete this student?")) {
      try {
        const res = await fetch(\`/api/students/\${id}\`, {
          method: "DELETE",
          headers: { Authorization: \`Bearer \${token}\` },
        });
        if (!res.ok) throw new Error("Failed to delete student");
        showAlert("Student deleted successfully", "success");
      } catch (e: any) {
        console.error(e);
        showAlert(e.message || "Error deleting student", "error");
      }
    }
  };
`;
});


fs.writeFileSync('src/pages/AdminDashboard.tsx', code);
console.log('Done rewriting delete handlers!');
