const http = require('http');
const req = http.get('http://0.0.0.0:3000/migrate-results', (res) => {
  let data = '';
  res.on('data', chunk => data += chunk);
  res.on('end', () => console.log('Response:', data));
});
req.on('error', console.error);
