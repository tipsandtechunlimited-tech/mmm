import fs from "fs";
import path from "path";
import admin from "firebase-admin";
import { getFirestore } from "firebase-admin/firestore";

const configPath = path.join(process.cwd(), "firebase-applet-config.json");
const firebaseConfig = JSON.parse(fs.readFileSync(configPath, "utf-8"));

if (!admin.apps.length) {
  admin.initializeApp({
    projectId: firebaseConfig.projectId,
  });
}

const dbId =
  firebaseConfig.firestoreDatabaseId &&
  firebaseConfig.firestoreDatabaseId !== "(default)"
    ? firebaseConfig.firestoreDatabaseId
    : undefined;

const db = dbId ? getFirestore(admin.app(), dbId) : getFirestore(admin.app());

async function check() {
  console.log("Checking database...");
  const settingsSnap = await db.collection("settings").get();
  console.log("Current Settings:");
  settingsSnap.forEach(doc => {
    const data = doc.data();
    if (doc.id.includes("password")) {
      console.log(`- ${doc.id}: ***** (length: ${data?.value?.length || 0})`);
    } else {
      console.log(`- ${doc.id}:`, data);
    }
  });

  console.log("\nLast 20 Message Logs:");
  const logsSnap = await db.collection("message_logs").orderBy("timestamp", "desc").limit(20).get();
  if (logsSnap.empty) {
    console.log("No logs found in message_logs.");
  } else {
    logsSnap.forEach(doc => {
      console.log(doc.id, doc.data());
    });
  }
}

check().catch(console.error);
